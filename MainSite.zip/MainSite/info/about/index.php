<?php
include '../../more/connect.php';
if(!$loggedIn) {
	header("Location: /");
}
?>
<?php
if(empty($error)){
  if(isset($_POST['send']))
{
    $sql = "INSERT INTO wall (username, user_id, message, datee)
    VALUES ('".$username."','".$user->id."','".$_POST["message"]."', '".date("Y/m/d")."')";

    $result = mysqli_query($conn,$sql);
}
}

/*if(strlen($message) < 3 || strlen($message) > 200) {
        $error = '
        <div style="height: 0px;"></div>
       <div class="alert alert-primary" style="margin-bottom: 10px;" role="alert">
            Message needs to be between 3 and 200 characters.
        </div>';
    }*/

?>
<?php require '../../more/Default.php'; ?>
<?php require '../../more/nav.php'; ?>
<div id="Body">

    <h2>
        About Us</h2>
    <p>
        RBXAcer is a startup company based in Silicon Valley, California. We are a team of hardcore engineers with a passion for quality in everything that we do. Our project straddles several rapidly-developing aspects of internet entertainment: virtual worlds, casual gaming, and user-constructed content.
    </p>
    <p>
        RBXAcer is free to play and safe for kids aged 10+ Our product remains under heavy development and is currently in public alpha testing. We deeply value community feedback as we continue to make RBXAcer into a game that will excite the imagination of the young and the young at heart.
    </p>
    <p>
        For more information about RBXAcer, visit the News and Help sections.</p>
    <p>
        RBXAcer is currently hiring, check out our jobs page.</p>
    <p>
        Please contact us discord at <a href="https://discord.gg/vkZQFVxyBJ">RBXAcer Discord</a>.</p>

				</div>
        <div style="clear:both;"></div>
        <?php require '../../more/footer.php'; ?>
