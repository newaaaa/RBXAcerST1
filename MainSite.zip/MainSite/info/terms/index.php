<?php
include '../../more/connect.php';
if(!$loggedIn) {
	header("Location: /");
}
?>
<?php
if(empty($error)){
  if(isset($_POST['send']))
{
    $sql = "INSERT INTO wall (username, user_id, message, datee)
    VALUES ('".$username."','".$user->id."','".$_POST["message"]."', '".date("Y/m/d")."')";

    $result = mysqli_query($conn,$sql);
}
}

/*if(strlen($message) < 3 || strlen($message) > 200) {
        $error = '
        <div style="height: 0px;"></div>
       <div class="alert alert-primary" style="margin-bottom: 10px;" role="alert">
            Message needs to be between 3 and 200 characters.
        </div>';
    }*/

?>
<?php require '../../more/Default.php'; ?>
<?php require '../../more/nav.php'; ?>
<div id="Body">
	<div id="Container">
				<div id="Body">

			It is very important that you review the
			following rules so that you know what you can and cannot do on RBXAcer. By using
			this site, you and your parents agree to abide by the following terms and
			conditions:
<center>
		<div style="border:3px solid black">
			<div style="text-align:left;margin-left:5px">
				    <div style="margin-top:3px;margin-bottom:3px">
				        <li>You must be <strong>13 years of age or older</strong> to use or register for RBXAcer.</li>
				    </div>
				    <div style="margin-top:3px;margin-bottom:3px">
				        <li>RBXAcer is not responsible for user generated content or actions.</li>
				    </div>
				    <div style="margin-top:3px;margin-bottom:3px">
				        <li>Do not scrape, fuzz, or otherwise bruteforce RBXAcer's web services.</li>
				    </div>
				    <div style="margin-top:3px;margin-bottom:3px">
				        <li>You are not allowed to modify, distribute, or take advantage of any code distributed within RBXAcer. (including exploiting).</li>
				    </div>
				<div style="margin-top:3px;margin-bottom:3px">
				<li>You are not allowed to spam or flood the site with requests.</li>
				</div>
				<div style="margin-top:3px;margin-bottom:3px">
				<li>Do not create new accounts to circumvent moderation actions, of any type,  against your account.</li>
				</div>
				<div style="margin-top:3px;margin-bottom:3px">
				<li>You must not engage in, or endorse, unlawful content shared through the RBXAcer service. This namely includes copyright.</li>
				</div>
				<div style="margin-top:3px;margin-bottom:3px">
				<li>You must not share your account details, as compromised accounts will not be compensated for.</li>
				</div>
				<div style="margin-top:3px;margin-bottom:3px">
				<li>All donations are final. If you donate, refunds will not be issued, under any circumstances.</li>
				</div>
				<div style="margin-top:3px;margin-bottom:3px">
				<li>Profanities, expletives ("swear words") and such inappropriate activies are prohibited.</li>
				</div>
				<div style="margin-top:3px;margin-bottom:3px">
				<li>We have a zero tolerance harassment policy. Do not do it.</li>
				</div>
				<div style="margin-top:3px;margin-bottom:3px">
				<li>NSFW content is strictly prohibited. We take this very seriously.</li>
				</div>
				<div style="margin-top:3px;margin-bottom:3px">
				<li>If you would like to send legal requests such as DMCA requests, Cease and Desist &amp; other legal notices, please Discord <a href="https://discord.gg/VnR6pZ3fEJ">Codex#6571</a></li>
				</div>
				<div style="margin-top:3px;margin-bottom:3px">
				<li>All content on-site is property of RBXAcer, and is owned as such unless owned by another identity. You are not allowed to re-use it for your own work.
				</li></div>
			</div>
		</div>
</center>

</div>
<div style="clear:both;"></div>
<?php require '../../more/footer.php'; ?>
    	</div>

<span style="display:none;" id="scriptloadtime">0.067882061004639</span></div>
