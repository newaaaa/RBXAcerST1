<?php
include '../../more/catalogconnect.php';
if(!$loggedIn) {
	header("Location: /");
}
$RefreshRate = rand(0,100000);

include '../../more/filter.php';
$id = trim($conn->real_escape_string($_GET['id']));

if(!$id || !is_numeric($id)) {
    header("Location: /item/Pants?id=1");
    die();
}else{
    $checkExists = $conn->query("SELECT * FROM `shirts` WHERE `id`='$id'");
    $exists = mysqli_num_rows($checkExists);
    if($exists == 0) {
        header("Location: /404");
        die();
    }
}

$select = $conn->query("SELECT * FROM shirts WHERE id='".$id."'");
$fetchuser = mysqli_fetch_object($select);


if ($fetchuser == 0) {
    header("Location: ../");
}

if($fetchuser->username !== $user->username) {
$updateviews = $conn->query("UPDATE `users` SET `profile_views` = `profile_views` + 1 WHERE username = '$fetchuser->username'");
}

$getUviews = $conn->query("SELECT `profile_views` FROM `users` WHERE username = '$fetchuser->username'");

while($row = mysqli_fetch_array($getUviews)) {
    $profileviews = $row['profile_views']; //$db-query("SELECT `profile_views` FROM `users` WHERE username='$fetch_user->username'");
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" id="www-roblox-com">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<title>
	RBXAcer: A FREE Virtual World-Building Game with Avatar Chat, 3D Environments, and Physics
</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script><link id="ctl00_Imports" rel="stylesheet" type="text/css" href="/CSS/AllCSS.ashx.css"/><link id="ctl00_Favicon" rel="Shortcut Icon" type="image/ico" href="/favicon.ico"/><meta name="author" content="RBXAcer Corporation"/><meta name="description" content="RBXAcer is SAFE for kids! RBXAcer is a FREE casual virtual world with fully constructible/desctructible 3D environments and immersive physics. Build, battle, chat, or just hang out."/><meta name="keywords" content="game, video game, building game, construction game, online game, LEGO game, LEGO, MMO, MMORPG, virtual world, avatar chat."/></head>
	<body>
<input type="hidden" name="ctl00_ScriptManager1_HiddenField" id="ctl00_ScriptManager1_HiddenField" value=""/>
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="uxivj21VNo82QCsWazRGzivb/RfNhTUFoLErcHMQFBoP2+Kb5zgVtT8ZxnEJ0UbR3nxtzAnmuGQzzqVy06ounq4Po7I+b9P9Nc0ycnAVe1aojpNp7fFYOFunfldcWROmXqbL3PU26rjGQx2j9oYM2p/8NMvZIRuRosUAXLqHyq+eEB3zIcOoyR8TWfl1JZ98vvD57HkExxDz9MD3g7yMDJq59c7qQyDh6JqW+6AO37f/DOsa2gYS4UtgilQeN6KCCdjC3RN0M5TQJWTPvvKqSbSkCqHKq7a/cGXDoWmDFrpzxvtX/6UoeAteif857Et8e9RGZSsF4JyyQ0n7LgQh+LAyo7JemZndNCJ7eibgBjXsBBzi72OUfaDg2MWhKH/dDGQXkEInR69UUGZ5Cl/c6xnJZuWGzrbhppSnvqX2MtuAuYOnssKK9svB/E1v4ZrFhBFOi2xkFKJfRZJ0WIMuWN//6SjOrb9sMhcCz0wbCyjusUZbJMz/snZ77lnehE6FESP3apnk/EQygEmcdWx5tQK7eXqWihZGsZViLC5M9pIrG3exWj7lsNev93EY59nx9owpGhpJ0lSNJDdw2/HaQMfUOGf0d85relxGX/8Qv1hZdslmWa5D/dNM6XD6OJeOykH0WqNsmAvYSAgh6COUO0oJ7tlG2dxjrs1grSOr1TtjccwaxLR1QhLQVZI9SixJAOrStiqzkda1e0tbYOl7wD5hHRATt7KqfxDoAL/f4sTEsziOl2bj3HAIOoPmodUczJXgkuTKDwegH61qFrCYgRPudY73dect0cyL1PH2w4xwsyNpK1Wgk5rXT6eVIZ4tDsGGAQ4ixrmcQqohyUhauiSxep7gccPS3jMtmV5emewN/86jF/NdUY14WTCQljh5UX5ZsdP9jLT0Mxk7qzLkKyuQ1Wp8kn+dZI0oo09WoPC34PVrs+KXl9v5oxmpoO2EbLKD9HxgBfz5jRahufbzXVAg8fTUIwLBL8cPmwrayFTFvcsBW2zHsg13KsxAR2qMQo44ndua9AsPqbOMUUYrR89l8mo4rOG5fQ1HLf+cYCQk6Ew2I1fZ8ieuL/49KetkmqD6+cI7ASkUjpWOERi3VEWXgvQ3bfC84i3EoRdZ6COgaKUx0XcbihjWEUN0WPh1TSkmQu3/HFxNak5HpOv3E2X5uHLvh8vdHi9tpjeU0+u/I2qZeFPwKiWlnve3dfxhfKKPYLbMTHAWVPyogrhNzumtJF/6NEStgw7633RsHMZFiW7rCSzxOrRwmrcSIVCLTo+JSO29H4v6gU2iJK0HRyQ+WIZNW5gqn2dd56cJLOuvkC3dGVQFyX4Dr258Fq97LYVCNWl9341KRDNQTIYPog=="/>
<script src="http://www.roblox.com/ScriptResource.axd?d=HXgoHdDgvXS1Bm1BtuI8XHGybfmDQcggjOMmxgSyFRBndkpTCGRmk8kbaucugm5drDnCbTb1Liwve-nBa1oq5FRebTqf6YEfIlhmX5i3NKA1&amp;t=633390213312343750" type="text/javascript"></script>
<script src="http://www.roblox.com/CombineScriptsHandler.ashx?_TSM_HiddenField_=ctl00_ScriptManager1_HiddenField&amp;_TSM_CombinedScripts_=%3b%3bRoblox.Controls%3aen-US%3a6b47a5fa-c80f-443d-8cd5-02b4e96c709b%3aRoblox.Controls.IE6Hack.js" type="text/javascript"></script>
			<div id="Container">
<div id="AdvertisingLeaderboard">
</div>
<script>
	var currency;
	var suffTix = true;
	var suffBux = true;
	function getDelete(id,type) {
		$("#VerifyPurchaseTix").hide();
		$("#VerifyPurchaseBux").hide();
		$("#ProcessPurchase").show();
		$.post("https://www.rbxacer.coolblox.net/api/scripts/deleteitem.php", {id:id, type:type, currency:currency, csrf:$("#csrf_token").val()}, function(data) {
			console.log(data);
			$("#PurchaseMessage").html(data.message);
			$("#PurchaseMessage").show();
			$("#ProcessPurchase").hide();
		}, "json");
	}
	function showPurchaseDiag(currencyA) {
		$("#VerifyPurchaseTix").hide();
		$("#VerifyPurchaseBux").hide();
		$("#VerifyPurchaseTixIn").hide();
		$("#VerifyPurchaseBuxIn").hide();
		$("#ProcessPurchase").hide();
		$("#PurchaseMessage").hide();
		currency = currencyA
		$("#itemPurchaseFade").show();
		if(currency == 0) {
			if (suffTix) {
				$("#VerifyPurchaseTix").show();
			} else {
				$("#VerifyPurchaseTixIn").show();
			}
		} else {
			if (suffBux) {
				$("#VerifyPurchaseBux").show();
			} else {
				$("#VerifyPurchaseBuxIn").show();
			}
		}
	}
</script>
<?php require '../../more/nav.php'; ?>
<script>
	var currency;
	var suffTix = true;
	var suffBux = true;
	function getItem() {
		$("#VerifyPurchaseTix").hide();
		$("#VerifyPurchaseBux").hide();
		$("#ProcessPurchase").show();
		$.post("https://www.rbxacer.coolblox.net/more/test.php", {id:id, type:type, currency:currency, csrf:$("#csrf_token").val()}, function(data) {
			console.log(data);
			$("#PurchaseMessage").html(data.message);
			$("#PurchaseMessage").show();
			$("#ProcessPurchase").hide();
		}, "json");
	}
	function showPurchaseDiag(currencyA) {
		$("#VerifyPurchaseTix").hide();
		$("#VerifyPurchaseBux").hide();
		$("#VerifyPurchaseTixIn").hide();
		$("#VerifyPurchaseBuxIn").hide();
		$("#ProcessPurchase").hide();
		$("#PurchaseMessage").hide();
		currency = currencyA
		$("#itemPurchaseFade").show();
		if(currency == 0) {
			if (suffTix) {
				$("#VerifyPurchaseTix").show();
			} else {
				$("#VerifyPurchaseTixIn").show();
			}
		} else {
			if (suffBux) {
				$("#VerifyPurchaseBux").show();
			} else {
				$("#VerifyPurchaseBuxIn").show();
			}
		}
	}
</script>
<div id="Body">
    <style>
    #Item {
    font-family: Verdana, Sans-Serif;
    padding: 10px;
}
#ItemContainer {
    background-color: #eee;
    border: solid 1px #555;
    color: #555;
    margin: 0 auto;
    width: 620px;
}
#Actions {
    background-color: #fff;
    border-bottom: dashed 1px #555;
    border-left: dashed 1px #555;
    border-right: dashed 1px #555;
    clear: left;
    float: left;
    padding: 5px;
    text-align: center;
    min-width: 0;
    position: relative;
}
    </style>
	<div id="ItemContainer" style="float:left;width: 720px;">
	    <script>
	   function getHat() {

	       window.location.href='/api/buy/shirts/?id=<?php echo $badge ; ?>'
	   }
	var currency;
	var suffTix = true;
	var suffBux = true;
	function getAsset(id,type) {
		$("#VerifyPurchaseTix").hide();
		$("#VerifyPurchaseBux").hide();
		$("#ProcessPurchase").show();
		$.post("https://www.rbxacer.coolblox.net/more/test.php", {id:id, type:type, currency:currency, csrf:$("#csrf_token").val()}, function(data) {
			console.log(data);
			$("#PurchaseMessage").html(data.message);
			$("#PurchaseMessage").show();
			$("#ProcessPurchase").hide();
		}, "json");
	}
	function showPurchaseDiag(currencyA) {
		$("#VerifyPurchaseTix").hide();
		$("#VerifyPurchaseBux").hide();
		$("#VerifyPurchaseTixIn").hide();
		$("#VerifyPurchaseBuxIn").hide();
		$("#ProcessPurchase").hide();
		$("#PurchaseMessage").hide();
		currency = currencyA
		$("#itemPurchaseFade").show();
		if(currency == 0) {
			if (suffTix) {
				$("#VerifyPurchaseTix").show();
			} else {
				$("#VerifyPurchaseTixIn").show();
			}
		} else {
			if (suffBux) {
				$("#VerifyPurchaseBux").show();
			} else {
				$("#VerifyPurchaseBuxIn").show();
			}
		}
	}
</script>
	<h2><?php echo "".$fetchuser->username.""; ?></h2>
	<div id="Item">
		<div id="Thumbnail">
			<a title="<?php echo "".$fetchuser->username.""; ?>" style="display:inline-block;height:250px;width:250px;"><img src="/items/shirts/<?php echo "".$fetchuser->id.""; ?>/imgbig2.png" border="0" id="img" alt="<?php echo "".$fetchuser->username.""; ?>" style="display:inline-block;height:250px;width:250px;"></a>
		</div>
		<div id="Summary">
			<h3>RBXAcer Shirt</h3>
						<div id="<?php echo "".$fetchuser->robux.""; ?>Purchase">
				<div id="PriceIn<?php echo "".$fetchuser->robux.""; ?>"><?php echo "".$fetchuser->tixrobuxsell.""; ?></div>
<?php
$check = $conn->query("SELECT * FROM ownedshirts WHERE itemid='$id' AND creatorid='$user->id'");
$CheckEnd = mysqli_num_rows($check);
if ($CheckEnd > 0) {
 $owned = 1;
}
else {
 $owned = 0;
}
?>
<?php
if ($owned == 1) {
  echo "<div id='BuyWith$fetchuser->robux'>
					<a class='Button'>You bought it!</a>
				</div>
			</div>";
  }
else {
  echo "<div id='BuyWith$fetchuser->robux'>
					<a onclick=';showPurchaseDiag(0);' class='Button'>Buy with $fetchuser->test</a>
				</div>
			</div>";
  }
  ?>
			<br><br>
						<div id="Creator"><br><a href="/user/?id=13"><iframe src="/api/getAvatar.php?id=13&amp;size=90" frameborder="0" scrolling="no" width="100" height="110"></iframe></a><br><span style="color:#555;">Creator: </span><a href="/user/?id=13">Codex</a></div>
			<div id="LastUpdate">Updated: 12 months ago</div>
			<div id="Favourites">Favorited: 20 times</div>
						<div>
				<div id="DescriptionLabel">Description:</div>
				<div id="Description"><?php echo "".$fetchuser->description.""; ?></div>
			</div>
						<p>
				</p><div class="ReportAbusePanel">
					<span class="AbuseIcon"><a><img src="../../images/abuse.gif" alt="Report Abuse" style="border-width:0px;"></a></span>
					<span class="AbuseButton"><a>Report Abuse</a></span>
				</div>
			<p></p>
		</div>
		<div id="Actions" style="width:240px;">
            	        <a href="#">Favorite</a>
	                            </div><div style="clear: both;"></div>

	</div>
</div>
<div style="clear:both;"></div>
<?php
if($fetchuser->banned == "0") {
echo"<div id='itemPurchaseFade' style='position: fixed; z-index: 1; left: 0px; top: 0px; width: 100%; height: 100%; overflow: auto; background-color: rgba(100, 100, 100, 0.25); display: none;'>
	<div id='itemPurchase' class='anim' style='max-width: 325px; position: absolute; top: 50%; left: 50%; transform: translateX(-50%) translateY(-50%);'>
		<div style='background-color: #FFFFE0; border:3px solid gray; box-shadow: black 5px 5px;'>";
if($user->coins > $fetchuser->price or $user->coins == $fetchuser->price) {
        echo "<div id='VerifyPurchaseTix' style='margin: 1.5em; display: block;'>
				<h3>Purchase Item:</h3><br>
				<p>Would you like to purchase Hat $fetchuser->username from RBXAcer for $fetchuser->tixrobuxsell?</p>
				<p>Your balance Tix: $tix.</p>
				<p>Your balance Robux: $user->tokens.</p>
				<br>
				<input type='submit' value='Buy Now!' onclick='getHat()' class='MediumButton' style='width:100%;'>
				<br><br>
				<input type='submit' name='oof' value='Cancel' onclick='$(&#39;#itemPurchaseFade&#39;).hide();' class='MediumButton' style='width:100%;'>
			</div>";
        }
        else{
        echo "<div id='VerifyPurchaseTix' style='margin: 1.5em; display:none;'>
				<h3>Insufficient Funds</h3>
				<p>You need more $fetchuser->test to purchase this item.</p>
				<p><input type='submit' name='oof' value='Cancel' onclick='$(&#39;#itemPurchaseFade&#39;).hide();' class='MediumButton' style='width:100%;'></p>
			</div>";
        }
        echo"						<div id='PurchaseMessage' style='margin: 1.5em; display: none;'>
						    Thanks for buy this.
			</div>
		</div>";
}
        ?>
        <?php
if($fetchuser->banned == "1") {
echo"<div id='itemPurchaseFade' style='position: fixed; z-index: 1; left: 0px; top: 0px; width: 100%; height: 100%; overflow: auto; background-color: rgba(100, 100, 100, 0.25); display: none;'>
	<div id='itemPurchase' class='anim' style='max-width: 325px; position: absolute; top: 50%; left: 50%; transform: translateX(-50%) translateY(-50%);'>
		<div style='background-color: #FFFFE0; border:3px solid gray; box-shadow: black 5px 5px;'>";
if($user->tokens > $fetchuser->price or $user->tokens == $fetchuser->price) {
        echo "<div id='VerifyPurchaseTix' style='margin: 1.5em; display: block;'>
				<h3>Purchase Item:</h3><br>
				<p>Would you like to purchase Hat $fetchuser->username from RBXAcer for $fetchuser->tixrobuxsell?</p>
				<p>Your balance Tix: $tix.</p>
				<p>Your balance Robux: $user->tokens.</p>
				<br>
				<input type='submit' value='Buy Now!' onclick='getHat()' class='MediumButton' style='width:100%;'>
				<br><br>
				<input type='submit' name='oof' value='Cancel' onclick='$(&#39;#itemPurchaseFade&#39;).hide();' class='MediumButton' style='width:100%;'>
			</div>";
        }
        else{
        echo "<div id='VerifyPurchaseTix' style='margin: 1.5em; display:none;'>
				<h3>Insufficient Funds</h3>
				<p>You need more $fetchuser->test to purchase this item.</p>
				<p><input type='submit' name='oof' value='Cancel' onclick='$(&#39;#itemPurchaseFade&#39;).hide();' class='MediumButton' style='width:100%;'></p>
			</div>";
        }
        echo"						<div id='PurchaseMessage' style='margin: 1.5em; display: none;'>
						    Thanks for buy this.
			</div>
		</div>";
}
        ?>
	</div>
</div>
<?php require '../../more/footer.php'; ?>
</div>
