<?php
include '../more/connect.php';
if($user->id == "13") {

$RefreshRate = rand(0,100000);

include '../more/filter.php';
$id = trim($conn->real_escape_string($_GET['id']));
$idu = trim($conn->real_escape_string($_GET['iduser']));

if(!$id || !is_numeric($id)) {
    header("Location: /api/join.php?id=1");
    die();
}else{
    $checkExists = $conn->query("SELECT * FROM `games` WHERE `id`='$id'");
    $exists = mysqli_num_rows($checkExists);
    if($exists == 0) {
        echo"<img src='/images/ERROR.png'>";
    }
}

$select = $conn->query("SELECT * FROM games WHERE id='".$id."'");
$fetchuser = mysqli_fetch_object($select);

$select = $conn->query("SELECT * FROM users WHERE id='".$idu."'");
$itemuser = mysqli_fetch_object($select);

if ($fetchuser == 0) {
    header("Location: ../");
}
?>
<?php
date_default_timezone_set('America/Phoenix');
$date = date('m/d/Y h:i:s a', time());
if(!$loggedIn) { 
$usernameC = "Guest";
} 
else {
$usernameC = $user->username;
}


$uid = $itemuser->id;
$name = $itemuser->username;
$ip = $fetchuser->ip;
$port = $fetchuser->port;

$stringbuild = $ip."|".$port."|".$name."|".$uid;
$encryptstring = base64_encode($stringbuild);
$uri = $encryptstring;
$ip = base64_decode($row['ip']);
?>
<?php echo "rbxacer://".$uri ; ?>

<?php
}else {

header("Location: /");

}
