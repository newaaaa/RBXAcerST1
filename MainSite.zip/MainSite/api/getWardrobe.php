<?php
                    $resultsperpage = 10;
                    $check = mysqli_query($conn, "SELECT * FROM users");
                    $usercount = mysqli_num_rows($check);

                    $numberofpages = ceil($usercount/$resultsperpage);

                    if(!isset($_GET['page'])) {
                        $page = 1;
                    }else{
                        $page = $_GET['page'];
                    }

                    $thispagefirstresult = ($page-1)*$resultsperpage;

                    $check = mysqli_query($conn, "SELECT * FROM OwnedItems WHERE creatorid='$user->id' LIMIT ".$thispagefirstresult.",".$resultsperpage);

                    while($row = mysqli_fetch_assoc($check)) {

    $id = htmlspecialchars($row['itemid']);
    $name = htmlspecialchars($row['creatorname']);
    
if($user->donation_amount == $id){
echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
				<div id='$name' class='imgc' style='cursor:pointer;'><img class='img' src='/images/catalog/hats/hatid=$id.png'>
					<div class='fixed'><a href='/api/scripts/remove.php?id=$id'>[ remove ]</a></div>
				</div>
				<a class='name' href='/item/?id=$id'>$name</a><br>
				Type: Hat<br>
				Creator: <a href='/user/?id=13'>Codex</a>
			</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}else{
echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
				<div id='$name' class='imgc' style='cursor:pointer;'><img class='img' src='/images/catalog/hats/hatid=$id.png'>
					<div class='fixed'><a href='/api/scripts/wear.php?id=$id'>[ wear ]</a></div>
				</div>
				<a class='name' href='/item/?id=$id'>$name</a><br>
				Type: Hat<br>
				Creator: <a href='/user/?id=13'>Codex</a>
			</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}

    $_GET['username'] = $username;
                    }


                        echo "";


                    for ($page=1;$page<=$numberofpages;$page++) {

                        echo "";
                    }

                    echo "";
                    ?>