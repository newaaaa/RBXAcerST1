<?php
include '../../more/catalogconnect.php';
if(!$loggedIn) {
	header("Location: /");
}
$RefreshRate = rand(0,100000);

include '../more/filter.php';
$id = trim($conn->real_escape_string($_GET['id']));

if(!$id || !is_numeric($id)) {
    header("Location: /my/character");
    die();
}else{
    $checkExists = $conn->query("SELECT * FROM `shirts` WHERE `id`='$id'");
    $exists = mysqli_num_rows($checkExists);
    if($exists == 0) {
        header("Location: /404");
        die();
    }
}

$select = $conn->query("SELECT * FROM shirts WHERE id='".$id."'");
$fetchuser = mysqli_fetch_object($select);


if ($fetchuser == 0) {
    header("Location: ../");
}

if($fetchuser->username !== $user->username) {
$updateviews = $conn->query("UPDATE `users` SET `profile_views` = `profile_views` + 1 WHERE username = '$fetchuser->username'");
}

$getUviews = $conn->query("SELECT `profile_views` FROM `users` WHERE username = '$fetchuser->username'");

while($row = mysqli_fetch_array($getUviews)) {
    $profileviews = $row['profile_views']; //$db-query("SELECT `profile_views` FROM `users` WHERE username='$fetch_user->username'");
}

?>
<?php
if($user->shirt == 1 < 2){
$delete = time();
if ($delete) {
	$test = $delete - 86400;
	if($user->membership == 'Admin') {
		$inven2 = 0;
		$ToDel = $badge;
	}else{
		$inven2 = 0;
		$ToDel = $badge;
	}
	$conn->query("UPDATE `users` SET `shirt` = shirt - ".$ToDel." WHERE `id` = '$user->id'");
  }
}
header("Location: /my/character/Shirts");
?>
