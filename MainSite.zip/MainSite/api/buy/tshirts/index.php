<?php
// $user->id this is current loggined use id
include '../../../more/connect.php';
if(!$loggedIn) {
    header("Location: /");
}
$id = trim($conn->real_escape_string($_GET['id']));

$select = $conn->query("SELECT * FROM tshirts WHERE id='$id'");
$item = mysqli_fetch_object($select);

// Strange, this is work
$check = $conn->query("SELECT * FROM ownedtshirts WHERE itemid='$id' AND creatorid='$user->id'");
$CheckEnd = mysqli_num_rows($check);
if ($CheckEnd > 0) {
 $owned = 1;
}
else {
 $owned = 0;
}

if(!$id || !is_numeric($id)) {
    header("Location: /item/?id=1");
    die();
}else{
    $checkExists = $conn->query("SELECT * FROM tshirts WHERE id='$id'");
    $exists = mysqli_num_rows($checkExists);
    if($exists == 0) {
        header("Location: /404");
        die();
    }
}
// Test, buy script is easy, i need only make working check owned script. Help
if($owned == 1) {
echo"Owned";
}
else {
$tixnow = $user->coins;
$robuxnow = $user->tokens;
if($item->robux = "Tickets") {
if($user->coins > $item->price or $user->coins == $item->price) {
$conn->query("UPDATE users SET $item->valute = $item->valute - ".$item->value." WHERE id = '$user->id'");
if (mysqli_connect_errno())
{
    printf("Connect failed: %s\n", mysqli_connect_error());
}

$namefixed = mysqli_real_escape_string($conn,$_POST['name']);
$player = mysqli_real_escape_string($conn,$user->id);
$playername = mysqli_real_escape_string($conn,$item->username);
$sql="INSERT INTO ownedtshirts (itemid, creatorname, creatorid)

VALUES

('$id', '$playername', '$player')";

if (!$conn->query($sql))
{
  printf("Error: %s\n", $con->error);
}

$conn->close();
}
else {
echo"Insufficient Funds";
}
}
else {
if($user->tokens > $item->price or $user->tokens == $item->price) {
$conn->query("UPDATE users SET $item->valute = $item->valute - ".$item->value." WHERE id = '$user->id'");
if (mysqli_connect_errno())
{
    printf("Connect failed: %s\n", mysqli_connect_error());
}

$namefixed = mysqli_real_escape_string($conn,$_POST['name']);
$player = mysqli_real_escape_string($conn,$user->id);
$playername = mysqli_real_escape_string($conn,$item->username);
$ipcrypt = base64_encode($_POST['ip']);
$sql="INSERT INTO ownedtshirts (itemid, creatorname, creatorid)

VALUES

('$id', '$playername', '$player')";

if (!$conn->query($sql))
{
  printf("Error: %s\n", $con->error);
}

$conn->close();
}
else {
echo"Insufficient Funds";
}
}
}
?>
<script>window.location.href='/item/TShirts/?id=<?php echo $id ; ?>'</script>
