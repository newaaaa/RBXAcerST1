<?php
include('../more/connect.php');
if(!$loggedIn) {
	header("Location: /");
}

$query = "select * from users";
$fetch_users = $conn->query("SELECT * FROM users");
$res = mysqli_query($conn,$query);
$total_users = mysqli_num_rows($fetch_users);
?>
<?php
echo "$total_users";
?>