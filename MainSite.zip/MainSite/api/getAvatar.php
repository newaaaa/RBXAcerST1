<?php
$size = $_GET['size'];
include '../more/connect.php';
if(!$loggedIn) {
	header("Location: /");
}
$RefreshRate = rand(0,100000);

include '../more/filter.php';
$id = trim($conn->real_escape_string($_GET['id']));

if(!$id || !is_numeric($id)) {
    header("Location: /api/getAvatar.php?id=1");
    die();
}else{
    $checkExists = $conn->query("SELECT * FROM `users` WHERE `id`='$id'");
    $exists = mysqli_num_rows($checkExists);
    if($exists == 0) {
        echo"<img src='/images/ERROR.png'>";
    }
}

$select = $conn->query("SELECT * FROM users WHERE id='".$id."'");
$fetchuser = mysqli_fetch_object($select);


if ($fetchuser == 0) {
    header("Location: ../");
}

if($fetchuser->username !== $user->username) {
$updateviews = $conn->query("UPDATE `users` SET `profile_views` = `profile_views` + 1 WHERE username = '$fetchuser->username'");
}

$getUviews = $conn->query("SELECT `profile_views` FROM `users` WHERE username = '$fetchuser->username'");

while($row = mysqli_fetch_array($getUviews)) {
    $profileviews = $row['profile_views']; //$db-query("SELECT `profile_views` FROM `users` WHERE username='$fetch_user->username'");
}
?>
				<body>
				       <?php
				        if($fetchuser->Hat == "1"){
				        echo"<div style='position:absolute; width:200; height:200; z-index:4;'><img width='$size' src='/items/hats/1.png'></div>";
				        }
								?>
								<?php
								if($fetchuser->Hat == "2"){
				        echo"<div style='position:absolute; width:200; height:200; z-index:4;'><img width='$size' src='/items/hats/2.png'></div>";
				        }
								?>
								<?php
								if($fetchuser->Hat == "3"){
				        echo"<div style='position:absolute; width:200; height:200; z-index:4;'><img width='$size' src='/items/hats/3.png'></div>";
				        }
								?>
								<?php
								if($fetchuser->Hat == "4"){
				        echo"<div style='position:absolute; width:200; height:200; z-index:4;'><img width='$size' src='/items/hats/4.png'></div>";
				        }
								?>
								<?php
								if($fetchuser->Hat == "5"){
				        echo"<div style='position:absolute; width:200; height:200; z-index:4;'><img width='$size' src='/items/hats/5.png'></div>";
				        }
								?>
								<?php
								if($fetchuser->Hat == "6"){
				        echo"<div style='position:absolute; width:200; height:200; z-index:4;'><img width='$size' src='/items/hats/6fix.png'></div>";
				        }
								?>
								<?php
								if($fetchuser->Hat == "7"){
				        echo"<div style='position:absolute; width:200; height:200; z-index:4;'><img width='$size' src='/items/hats/7.png'></div>";
				        }
								?>
								<?php
								if($fetchuser->Hat == "8"){
				        echo"<div style='position:absolute; width:200; height:200; z-index:4;'><img width='$size' src='/items/hats/8.png'></div>";
				        }
								?>
								<?php
								if($fetchuser->shirt == "1"){
				        echo"<div style='position:absolute; width:200; height:200; z-index:2;'><img width='$size' src='/items/shirts/1/7.png'></div>";
				        }
								?>
								<?php
								if($fetchuser->shirt == "2"){
				        echo"<div style='position:absolute; width:200; height:200; z-index:2;'><img width='$size' src='/items/shirts/2/3.png'></div>";
				        }
								?>
								<?php
								if($fetchuser->shirt == "3"){
				        echo"<div style='position:absolute; width:200; height:200; z-index:2;'><img width='$size' src='/items/shirts/3/3.png'></div>";
				        }
								?>
								<?php
								if($fetchuser->tshirt == "1"){
				        echo"<div style='position:absolute; width:200; height:200; z-index:2;'><img width='$size' src='/items/tshirts/1/1.png'></div>";
				        }
								?>
								<?php
								if($fetchuser->power == "1"){
				        echo"<div style='position:absolute; width:200; height:200; z-index:3;'><img width='$size' src='/items/pants/1/3.png'></div>";
				        }
								?>
								<?php
								if($fetchuser->power == "2"){
				        echo"<div style='position:absolute; width:200; height:200; z-index:3;'><img width='$size' src='/items/pants/2/4.png'></div>";
				        }
								?>
								<?php
								if($fetchuser->power == "3"){
				        echo"<div style='position:absolute; width:200; height:200; z-index:3;'><img width='$size' src='/items/pants/3/3.png'></div>";
				        }
								?>
								<?php
								echo"<div style='width:200; height:200; z-index:0;'><img width='$size' src='/images/Avatar.png'></div>"
				        ?>
				</body>
