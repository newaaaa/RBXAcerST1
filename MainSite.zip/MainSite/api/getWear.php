<?php
if($user->Hat == "1") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/images/catalog/hats/id=1.png'>
    <div class='fixed'><a href='/api/scripts/remove.php?id=1'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/?id=1'>Lampshade</a><br>
  Type: Hat<br>
  Creator: <a href='/user/?id=13'>Codex</a>
  </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->Hat == "2") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/images/catalog/hats/id=2.png'>
    <div class='fixed'><a href='/api/scripts/remove.php?id=2'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/?id=2'>Red Baseball Cap</a><br>
  Type: Hat<br>
  Creator: <a href='/user/?id=13'>Codex</a>
  </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->Hat == "3") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/images/catalog/hats/id=3.png'>
    <div class='fixed'><a href='/api/scripts/remove.php?id=3'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/?id=3'>Bighead</a><br>
  Type: Hat<br>
  Creator: <a href='/user/?id=13'>Codex</a>
  </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->Hat == "4") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/images/catalog/hats/id=4.png'>
    <div class='fixed'><a href='/api/scripts/remove.php?id=4'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/?id=4'>Sparkle Time Fedora</a><br>
  Type: Hat<br>
  Creator: <a href='/user/?id=13'>Codex</a>
  </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->Hat == "5") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/images/catalog/hats/id=5.png'>
    <div class='fixed'><a href='/api/scripts/remove.php?id=5'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/?id=5'>Bluesteel Viking Helm of Infinite Pillage</a><br>
  Type: Hat<br>
  Creator: <a href='/user/?id=13'>Codex</a>
  </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->Hat == "6") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/images/catalog/hats/id=6.png'>
    <div class='fixed'><a href='/api/scripts/remove.php?id=6'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/?id=6'>Astronaut Helmet</a><br>
  Type: Hat<br>
  Creator: <a href='/user/?id=13'>Codex</a>
  </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->Hat == "7") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/images/catalog/hats/id=7.png'>
    <div class='fixed'><a href='/api/scripts/remove.php?id=7'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/?id=7'>Fedora</a><br>
  Type: Hat<br>
  Creator: <a href='/user/?id=13'>Codex</a>
  </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->Hat == "8") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/images/catalog/hats/id=8.png'>
    <div class='fixed'><a href='/api/scripts/remove.php?id=8'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/?id=8'>Builders Club Hard Hat</a><br>
  Type: Hat<br>
  Creator: <a href='/user/?id=13'>Codex</a>
  </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->Hat == "9") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/images/catalog/hats/id=9.png'>
    <div class='fixed'><a href='/api/scripts/remove.php?id=9'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/?id=10'>Pal Hair</a><br>
  Type: Hat<br>
  Creator: <a href='/user/?id=6'>Ktrain</a>
  </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->shirt == "1") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/items/shirts/1/image2.png'>
    <div class='fixed'><a href='/api/scripts/removeshirt.php?id=1'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/Shirts/?id=1'>Blue Flame Jacket</a><br>
  Type: Shirt<br>
  Creator: <a href='/user/?id=13'>Codex</a>
  </div>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->shirt == "2") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/items/shirts/2/image2.png'>
    <div class='fixed'><a href='/api/scripts/removeshirt.php?id=2'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/Shirts/?id=2'>White Tuxedo</a><br>
  Type: Shirt<br>
  Creator: <a href='/user/?id=13'>Codex</a>
  </div>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->shirt == "3") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/items/shirts/3/image2.png'>
    <div class='fixed'><a href='/api/scripts/removeshirt.php?id=3'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/Shirts/?id=3'>Indiana Jones Jacket</a><br>
  Type: Shirt<br>
  Creator: <a href='/user/?id=13'>Codex</a>
  </div>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->shirt == "4") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/items/shirts/4/image4.png'>
    <div class='fixed'><a href='/api/scripts/removeshirt.php?id=4'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/Shirts/?id=4'>bacon hair shirt</a><br>
  Type: Shirt<br>
  Creator: <a href='/user/?id=6'>Ktrain</a>
  </div>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->tshirt == "1") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/items/tshirts/1/image.png'>
    <div class='fixed'><a href='/api/scripts/removetshirt.php?id=1'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/T-Shirts/?id=1'>Bloxxer</a><br>
  Type: T-Shirt<br>
  Creator: <a href='/user/?id=13'>Codex</a>
  </div>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->power == "1") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/items/pants/1/imagef.png'>
    <div class='fixed'><a href='/api/scripts/removepants.php?id=1'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/Pants/?id=1'>Flame Pants</a><br>
  Type: Pants<br>
  Creator: <a href='/user/?id=13'>Codex</a>
  </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->power == "2") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/items/pants/2/imagef.png'>
    <div class='fixed'><a href='/api/scripts/removepants.php?id=2'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/Pants/?id=2'>PaintBall pants</a><br>
  Type: Pants<br>
  Creator: <a href='/user/?id=13'>Codex</a>
  </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->power == "3") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/items/pants/3/imagef.png'>
    <div class='fixed'><a href='/api/scripts/removepants.php?id=3'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/Pants/?id=3'>White Tuxedo Pants</a><br>
  Type: Pants<br>
  Creator: <a href='/user/?id=13'>Codex</a>
  </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->power == "4") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/items/pants/4/imagef.png'>
    <div class='fixed'><a href='/api/scripts/removepants.php?id=4'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/Pants/?id=4'>bacon hair pants</a><br>
  Type: Pants<br>
  Creator: <a href='/user/?id=6'>Ktrain</a>
  </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->bodyp == "1") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/items/bodyp/1/imagef.png'>
    <div class='fixed'><a href='/api/scripts/removebodyp.php?id=1'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/bodyp/?id=1'>Robloxian 2.0</a><br>
  Type: Pants<br>
  Creator: <a href='/user/?id=21'>Ktrain</a>
  </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>
<?php
if($user->bodyp == "2") {
  echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
  <div id='w557' class='imgc' style='cursor:pointer;'><img class='img' src='/items/bodyp/2/imagef.png'>
    <div class='fixed'><a href='/api/scripts/removebodyp.php?id=2'>[ remove ]</a></div>
  </div>
  <a class='name' href='/item/bodyp/?id=1'>Man Package</a><br>
  Type: Pants<br>
  Creator: <a href='/user/?id=21'>Ktrain</a>
  </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}
?>