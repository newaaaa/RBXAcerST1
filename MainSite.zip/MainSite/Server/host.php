<?php 
$port = $_GET['port'];
?>
%OefXKO3Q6a32cxQ9WfPGjG8OPxF5PjGv3IxuHkHGqM9MhJ8g77mz2D8+h1VfTC7J+EE95UlIbwEB7tb78b+dbWgyk/GvJKzSnjMQT7tSAlKS2jljKzoP8VI+lcL8/KILv1uLGn675OX//TkdHiOhfrlGS4AcEc/bX8bJf4UQqwk=%game:Load('rbxasset://place.rbxl')
local scriptContext = game:GetService('ScriptContext')
pcall(function() scriptContext:AddStarterScript(libraryRegistrationScriptAssetID) end)
scriptContext.ScriptsDisabled = false
game:SetPlaceID(1, false)
game:GetService("ChangeHistoryService"):SetEnabled(false)
pcall(function() settings().Network.UseInstancePacketCache = true end)
pcall(function() settings().Network.UsePhysicsPacketCache = true end)
--pcall(function() settings()["Task Scheduler"].PriorityMethod = Enum.PriorityMethod.FIFO end)
pcall(function() settings()["Task Scheduler"].PriorityMethod = Enum.PriorityMethod.AccumulatedError end)
--settings().Network.PhysicsSend = 1 -- 1==RoundRobin
settings().Network.PhysicsSend = Enum.PhysicsSendMethod.ErrorComputation2
settings().Network.ExperimentalPhysicsEnabled = true
settings().Network.WaitingForCharacterLogRate = 100
pcall(function() settings().Diagnostics:LegacyScriptMode() end)
game:GetService("RunService"):Run()
game:GetService("NetworkServer"):Start(<?php echo $port ; ?>)
pcall(function() game:GetService("Players"):SetChatStyle(Enum.ChatStyle.Both) end)
pcall(function() game:GetService("ScriptContext"):AddStarterScript(1) end)
