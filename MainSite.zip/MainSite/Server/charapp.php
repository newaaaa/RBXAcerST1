<?php 
$shirt = $_GET['shirt'];
?>
http://beta.coolblox.net/<?php echo $shirt ; ?>.png;