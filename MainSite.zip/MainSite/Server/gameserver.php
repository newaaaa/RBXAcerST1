<?php 
$PlayerLimit = $_GET['PlayerLimit'];
$Map = $_GET['Place'];
?>
dofile('http://coolblox.net/Game/host.php?port=53640&PlayerLimit=<?php echo $PlayerLimit ; ?> ') 
game:Load('rbxasset://C:\RBXAcer\content\maps\<?php echo $Map ; ?>.rbxl') 
