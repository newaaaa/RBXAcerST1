<?php
$test = $_GET['tr']
?>
<?php
$m = $_GET['m']
?>
<div id="ctl00_cphRoblox_rbxCatalog_Timespan">
  <ul>
    <?php
    echo"
    <li>";
    if($m == "Most Popular") {
      echo"<img id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekBullet' class='GamesBullet' src='/images/bullet.png' border='0'>
      <a id='ctl00_cphRoblox_rbxCatalog_TimespanPastDaySelector' href='?m=Most Popular&tr=$test'><b>Most Popular</b></a></li>
    ";
    }
    else {
    echo"<a id='ctl00_cphRoblox_rbxCatalog_TimespanPastDaySelector' href='?m=Most Popular&tr=$test'>Most Popular</a></li>
    ";
    }
    echo"
    <li>
    ";
    echo"
    <li>";
    if($m == "Top Favorites") {
      echo"<img id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekBullet' class='GamesBullet' src='/images/bullet.png' border='0'>
      <a id='ctl00_cphRoblox_rbxCatalog_TimespanPastDaySelector' href='?m=Top Favorites&tr=$test'><b>Top Favorites</b></a></li>
    ";
    }
    else {
    echo"<a id='ctl00_cphRoblox_rbxCatalog_TimespanPastDaySelector' href='?m=Top Favorites&tr=$test'>Top Favorites</a></li>
    ";
    }
    echo"
    <li>
    ";
    if($m == "Recently Updated") {
      echo"<img id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekBullet' class='GamesBullet' src='/images/bullet.png' border='0'>
      <a id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekSelector' href='?m=Recently Updated&tr=$test'><b>Recently Updated</b></a></li";
    }
    else {
        echo"<a id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekSelector' href='?m=Recently Updated&tr=$test'>Recently Updated</a></li>";
    }
    echo"
    <li>
    ";
    if($m == "Featured Games") {
      echo"<img id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekBullet' class='GamesBullet' src='/images/bullet.png' border='0'>
      <a id='ctl00_cphRoblox_rbxCatalog_TimespanPastMonthSelector' href='?m=Featured Games&tr=$test'><b>Featured Games</b></a></li>";
    }
    else {
        echo"<a id='ctl00_cphRoblox_rbxCatalog_TimespanPastMonthSelector' href='?m=Featured Games&tr=$test'>Featured Games</a></li>";
    }
    ?>
  </ul>
</div>
