<?php
include('../more/connect.php');
if(!$loggedIn) {
	header("Location: /");
}
?>
<style>
#GamesContainer .Game {
    margin: 0 10px 15px;
    vertical-align: top;
    width: 162px;
}
#GamesContainer .Game .GameThumbnail {
    border: solid 1px #000;
    width: 160px;
    height: 100px;
    text-align: center;
}
#GamesContainer .Game .GameDetails {
    font-family: Verdana,Sans-Serif;
    overflow: hidden;
    padding: 2px 0 6px;
    width: 152px;
}
</style>
<?php
                    $resultsperpage = 3;
                    $check = mysqli_query($conn, "SELECT * FROM games");
                    $usercount = mysqli_num_rows($check);

                    $numberofpages = ceil($usercount/$resultsperpage);

                    if(!isset($_GET['page'])) {
                        $page = 1;
                    }else{
                        $page = $_GET['page'];
                    }

                    $thispagefirstresult = ($page-1)*$resultsperpage;

                    $check = mysqli_query($conn, "SELECT * FROM games LIMIT ".$thispagefirstresult.",".$resultsperpage);

                    while($row = mysqli_fetch_assoc($check)) {

    $id = htmlspecialchars($row['id']);
    $name = htmlspecialchars($row['name']);

        echo "<td class='Game' valign='top'>
	        <div style='padding-bottom:5px'>
		        <div class='GameThumbnail'>
			        <a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_ciGame' title='Run From Your Family and make it to the hang out' style='display:inline-block;cursor:pointer;'><img src='https://web.archive.org/web/20080723044136im_/http://t1.roblox.com:80/f0c8f5f8318ed4caf57b7f3829deb5d6' border='0' alt='Run From Your Family and make it to the hang out'></a>
		        </div>
		        <div class='GameDetails'>
			        <div class='GameName'><a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_hlGameName' href='Item.aspx?ID=2307461'>$name</a></div>
			        <div class='GameLastUpdate'><span class='Label'>Updated:</span> <span class='Detail'>42 minutes ago</span></div>
			        <div class='GameCreator'><span class='Label'>Creator:</span> <span class='Detail'><a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_hlGameCreator' href='User.aspx?ID=484867'>weeeeeee721</a></span></div>
			        <div class='AssetFavorites'><span class='Label'>Favorited:</span> <span class='Detail'>105 times</span></div>
			        <div class='GamePlays'><span class='Label'>Played:</span> <span class='Detail'>1,167 times</span></div>
			        <div id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_pGameCurrentPlayers'>
				
				        <div class='GameCurrentPlayers'><span class='DetailHighlighted'>126 players online</span></div>
			        
			</div>
		        </div>
		    </div>
	        </td>";

    $_GET['username'] = $username;
                    }
                    ?>