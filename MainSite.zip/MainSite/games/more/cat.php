<?php
$test = $_GET['tr']
?>
<?php
$m = $_GET['m']
?>
<div id="ctl00_cphRoblox_rbxCatalog_Timespan">
  <h4>Time</h4>
  <ul>
    <?php
    echo"
    <li>";
    if($test == "Now") {
      echo"<img id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekBullet' class='GamesBullet' src='/images/bullet.png' border='0'>
      <a id='ctl00_cphRoblox_rbxCatalog_TimespanPastDaySelector' href='?tr=Now&m=$m'><b>Now</b></a></li>
    ";
    }
    else {
    echo"<a id='ctl00_cphRoblox_rbxCatalog_TimespanPastDaySelector' href='?tr=Now&m=$m'>Now</a></li>
    ";
    }
    echo"
    <li>
    ";
    echo"
    <li>";
    if($test == "Past Day") {
      echo"<img id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekBullet' class='GamesBullet' src='/images/bullet.png' border='0'>
      <a id='ctl00_cphRoblox_rbxCatalog_TimespanPastDaySelector' href='?tr=Past Day&m=$m'><b>Past Day</b></a></li>
    ";
    }
    else {
    echo"<a id='ctl00_cphRoblox_rbxCatalog_TimespanPastDaySelector' href='?tr=Past Day&m=$m'>Past Day</a></li>
    ";
    }
    echo"
    <li>
    ";
    if($test == "Past Week") {
      echo"<img id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekBullet' class='GamesBullet' src='/images/bullet.png' border='0'>
      <a id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekSelector' href='?tr=Past Week&m=$m'><b>Past Week</b></a></li";
    }
    else {
        echo"<a id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekSelector' href='?tr=Past Week&m=$m'>Past Week</a></li>";
    }
    echo"
    <li>
    ";
    if($test == "Past Month") {
      echo"<img id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekBullet' class='GamesBullet' src='/images/bullet.png' border='0'>
      <a id='ctl00_cphRoblox_rbxCatalog_TimespanPastMonthSelector' href='?tr=Past Month&m=$m'><b>Past Month</b></a></li>";
    }
    else {
        echo"<a id='ctl00_cphRoblox_rbxCatalog_TimespanPastMonthSelector' href='?tr=Past Month&m=$m'>Past Month</a></li>";
    }
    echo"
    <li>
    ";
    if($test == "All-time") {
      echo"<img id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekBullet' class='GamesBullet' src='/images/bullet.png' border='0'>
      <a id='ctl00_cphRoblox_rbxCatalog_TimespanAllTimeSelector' href='?tr=All-time&m=$m'><b>All-time</b></a></li>";
    }
    else {
        echo"<a id='ctl00_cphRoblox_rbxCatalog_TimespanAllTimeSelector' href='?tr=All-time&m=$m'>All-time</a></li>";
    }
    echo"
    ";
    ?>
  </ul>
</div>
