<?php require '../more/Default.php'; ?>
				<div id="Header">
					<div id="Banner">
						<div id="Options">
				</div>
						<div id="Logo"><a id="ctl00_Image1" title="RBXAcer" href="/" style="display:inline-block;cursor:hand;"><img src="/images/RBXAcer_Logo.png" border="0" id="img" blankurl="http://t2.roblox.com:80/blank-267x70.gif"></a></div>
					</div>
				</div>
				<div id="Body">
<center>
<h1>
RBXAcer Moderation
<p>
    <b>You have been permanently banned from RBXAcer.</b>
</p>
</p> <p>You will not be able to create new account.</p></div>
</div>
</h1>
</center>