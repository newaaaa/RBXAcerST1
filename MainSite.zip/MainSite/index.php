<?php
include 'more/connect.php';
if($loggedIn) {
	header("Location: my/home");
}
if(isset($_POST['sign_in'])){

$username = strip_tags($_POST['username']);
$username = trim($conn->real_escape_string($username));
$username = htmlentities($username);

$password = strip_tags($_POST['password']);
$password = trim($conn->real_escape_string($password));
$password = htmlentities($password);

    $checkUsernameQ = "SELECT * FROM users WHERE username = '$username'";
    $checkUsername = $conn->query($checkUsernameQ);

    $username = mysqli_real_escape_string($conn, $username);
	$userRow = (object) $checkUsername->fetch_assoc();
    $pass = $userRow->{'password'};

 if($checkUsername->num_rows > 0){
	 if (password_verify($password, $pass)) { //logged in
			$_SESSION['id'] = $userRow->{'id'};
			$userID = $_SESSION['id'];
			header('Location: my/home');
			die();
		}else{
 	     $error = '
           <div style="color:red; text-align:center;"><center>Username or password incorrect</center></div>
        ';
 	 }
    }else{
        $error = '
           <div style="color:red; text-align:center;"><center>Username or password incorrect</center></div>
        ';
   }
}

?>
<?php require 'more/Default.php'; ?>
				<div id="Header">
					<div id="Banner">
						<div id="Options">
					<div style="top: 0px; left: 0px; padding: 4px; position: absolute;">
						<span><a href="/Login">Login</a></span>
					</div>
				</div>
						<div id="Logo"><a id="ctl00_Image1" title="RBXAcer" href="/" style="display:inline-block;cursor:hand;"><img src="../images/RBXAcer_Logo.png" border="0" id="img" blankurl="http://t2.roblox.com:80/blank-267x70.gif"></a></div>
					</div>
				</div>
				<div id="Body">
	<div id="SplashContainer">
		<div id="SignInPane">
<div id="LoginViewContainer">
			<div id="LoginView">
				<h5>Member Login</h5>
<div class="AspNet-Login">
	<?php
        if(!empty($error)){
            echo $error;
        }
        ?>
    <form method="POST" action="">
						<div class="AspNet-Login">
							<div class="AspNet-Login-UserPanel">
								<label for="password" class="Label">Character Name</label>
								<input type="text" name="username" placeholder="" tabindex="1" class="Text"/>
							</div>
							<div class="AspNet-Login-PasswordPanel">
								<label for="password" class="Label">Password</label>
								<input type="password" name="password" placeholder="" tabindex="2" class="Text"/>
							</div>
							<!--div class="AspNet-Login-RememberMePanel"-->
							<!--/div-->
							<div class="AspNet-Login-SubmitPanel">
								<input href="#" type="submit" class="Button" name="sign_in" value="Login">
							</div>
							<div class="AspNet-Login-SubmitPanel">
						        <button name="lb" tabindex="4" class="Button" formaction="/register/">Register</button>
							</div>
<div class="AspNet-Login-PasswordRecoveryPanel">
								<a id="ctl00_cphRoblox_rbxLoginView_lvLoginView_lSignIn_hlPasswordRecovery" tabindex="5" href="Login/ResetPasswordRequest.aspx">Forgot your password?</a>
							</div>
							</div>
					</form>
</div>
			</div>
</div>
			<div id="ctl00_cphRoblox_pFigure">
				<div id="Figure"><a id="ctl00_cphRoblox_ImageFigure" disabled="disabled" title="Figure" onclick="return false" style="display:inline-block;"><img src="images/NewFrontPageGuy.png" border="0" id="img" alt="Figure" blankurl="http://t1.roblox.com:80/blank-115x130.gif"/></a></div>
</div>
		</div>
		<div id="RobloxAtAGlance">
			<h2>RBXAcer Virtual Playworld</h2>
			<h3>RBXAcer is Free!</h3>
			<ul id="ThingsToDo">
				<li id="Point1">
					<h3>Build your personal Place</h3>
					<div>Create buildings, vehicles, scenery, and traps with thousands of virtual bricks.</div>
				</li>
				<li id="Point2">
					<h3>Meet new friends online</h3>
					<div>Visit your friend's place, chat in 3D, and build together.</div>
				</li>
				<li id="Point3">
					<h3>Battle in the Brick Arenas</h3>
					<div>Play with the slingshot, rocket, or other brick battle tools.  Be careful not to get "bloxxed".</div>
				</li>
			</ul>
			<iframe allowfullscreen src="/vids/wtf.mp4" frameborder="0" width="400" height="326"></iframe>
			<div id="Install">
				<div id="CompatibilityNote"><div id="ctl00_cphRoblox_pCompatibilityNote">
	Works with your<br/>Windows PC!
</div></div>
				<div id="DownloadAndPlay"><a id="ctl00_cphRoblox_hlDownloadAndPlay" href="/install/RBXAcer.exe"><img src="images/DownloadAndPlay.png" alt="FREE - Download and Play!" border="0"/></a></div>
			</div>
			<div id="ctl00_cphRoblox_pForParents">
				<div id="ForParents">
					<a id="ctl00_cphRoblox_hl" title="Look at this badge, it's a badge" style="display:inline-block;"><img title="Look at this badge, it's a badge" src="images/BadgeCool.png" border="0"/></a>
				</div>
</div>
		</div>
		<div id="UserPlacesPane">
			<div id="UserPlaces_Content">
				<table id="ctl00_cphRoblox_CoolPlacesDataList" cellspacing="0" border="0" width="100%">
	<tr>
	    <center>
		<td class="UserPlace">
						<a id="ctl00_cphRoblox_CoolPlacesDataList_ctl01_rbxContentImage" title="Codex’s Place" style="display:inline-block;cursor:pointer;"><img src="/images/games/Minitid=1.jpg" alt="Codex’s Place"/></a>
					</td><td class="UserPlace">
						<a id="ctl00_cphRoblox_CoolPlacesDataList_ctl02_rbxContentImage" title="ktrain's epic place" style="display:inline-block;cursor:pointer;"><img src="/images/games/Minitid=2.jpg" alt="ktrain's epic place"/></a>
					</td>
	    </center>
	</tr>
</table>
			</div>
			<div id="UserPlaces_Header">
				<h3>Cool Places</h3>
				<p>Check out some of our favorite RBXAcer places!</p>
			</div>
			<div id="ctl00_cphRoblox_ie6_peekaboo" style="clear: both"></div>
		</div>
	</div>
				</div>
				<?php require 'more/footer.php'; ?>
			</div>
        <script src="urchin.js" type="text/javascript"></script></body>
</html>
