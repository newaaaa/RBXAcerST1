<?php require '../../more/Default.php'; ?>
				<div id="Header">
					<div id="Banner">
						<div id="Options">
					<div style="top: 0px; left: 0px; padding: 4px; position: absolute;">
						<span><a href="/Login">Login</a></span>
					</div>
				</div>
						<div id="Logo"><a id="ctl00_Image1" title="RBXAcer" href="/" style="display:inline-block;cursor:hand;"><img src="/images/RBXAcer_Logo.png" border="0" id="img" blankurl="http://t2.roblox.com:80/blank-267x70.gif"></a></div>
					</div>
				</div>
				<div id="Body">
          <center>
<a href="#"><img width="600" src="/images/RBXAcerimg.png" title="Codex image!"></a>
          </center>
        </div>
