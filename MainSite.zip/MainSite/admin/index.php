<?php
include '../more/connect.php';
if(!$loggedIn) {
	header("Location: /");
}
if($user->id !== "6") {
	header("Location: /404");
}
?>
<?php require '../more/Default.php'; ?>
<style>
codex {
    font: normal 8pt/normal 'Comic Sans MS',Verdana,sans-serif;
    margin-top: 0;
    text-transform: none;
    text-decoration: none;
}
</style>
<link id="ctl00_Favicon" rel="Shortcut Icon" type="image/ico" href="/favicon.ico"/>
<?php require '../more/nav.php'; ?>
<div id="Body">
<codex>
    
    <center><h1>Welcome to Admin Panel!</h1></center>
    	<div id="BrowseContainer" style="text-align:center">
  <br>
  <div>
  	    <table class="Grid" cellspacing="0" cellpadding="4" border="0" style="border-collapse:collapse;">
      <tbody>
        <tr class="GridHeader">
                    <th scope="col">Avatar</th>
          <th scope="col">Name</th>
          <th scope="col">Status</th>
          <th scope="col">Location / Last Seen</th>
      	          </tr>
                <?php
                    $resultsperpage = 10;
                    $check = mysqli_query($conn, "SELECT * FROM users");
                    $usercount = mysqli_num_rows($check);

                    $numberofpages = ceil($usercount/$resultsperpage);

                    if(!isset($_GET['page'])) {
                        $page = 1;
                    }else{
                        $page = $_GET['page'];
                    }

                    $thispagefirstresult = ($page-1)*$resultsperpage;

                    $check = mysqli_query($conn, "SELECT * FROM users LIMIT ".$thispagefirstresult.",".$resultsperpage);

                    while($row = mysqli_fetch_assoc($check)) {

    $id = htmlspecialchars($row['id']);
    $name = htmlspecialchars($row['username']);
		$descriptionn = htmlspecialchars($row['description']);

        echo "
		<tr class='GridItem'>
    <td>
    <iframe height='60' width='60' src='/api/getAvatar.php?id=$id&size=50' frameborder='0' scrolling='no'></iframe>
    </td>
    <td href='/user/?id=$id' style='word-break: break-all;'>
    <a href='/user/?id=$id'>$name</a><br>
		<span>$descriptionn</span>
    </td>
    <td><span><a href='/admin/delete.php?id=$id'>BAN</a></span><br></td>
    <td><span>?</span></td>
    </tr>";

    $_GET['username'] = $username;
                    }


                        echo "
                        <tr class='GridPager'>
                            <td colspan='4'>
                                <table border='0'>
                                    <tbody>
                        ";
                     
                    if($page <= $page) {  
                    $pagefix = $page + 9;
                    }
                    if($pagefix > $numberofpages) {
                    $pagefix = $numberofpages;
                    }
                    $page2 = $page - 1;
                    $page3 = $page - 2;
                    $page4 = $page - 3;
                    $page5 = $page - 4;
                    $page6 = $page - 5;
                    
                    
                    if($page == 1 OR $page == 2 OR $page == 3 OR $page == 4 OR $page == 5) {
                    }else{
                    echo"<td>
                            <a href='/admin/?page=".$page6."'>".$page6." </a>
                        </td>
                    <td>
                            <a href='/admin/?page=".$page5."'>".$page5." </a>
                        </td>
                    <td>
                            <a href='/admin/?page=".$page4."'>".$page4." </a>
                        </td>
                    <td>
                            <a href='/admin/?page=".$page3."'>".$page3." </a>
                        </td>
                    <td>
                            <a href='/admin/?page=".$page2."'>".$page2." </a>
                        </td>
                    ";
                    }
                    
                    $pager = $page - 1;
                    $pager1 = $page - 2;
                    $pager2 = $page - 3;
                    $pager3 = $page - 4;
                    if($page == 5) {
                    echo"<td>
                            <a href='/admin/?page=".$pager3."'>".$pager3." </a>
                        </td>
                    <td>
                            <a href='/admin/?page=".$pager2."'>".$pager2." </a>
                        </td>
                    <td>
                            <a href='/admin/?page=".$pager1."'>".$pager1." </a>
                        </td>
                    <td>
                            <a href='/admin/?page=".$pager."'>".$pager." </a>
                        </td>
                    ";
                    }else{
                    }
                    
                    $pagej = $page - 1;
                    $pagej1 = $page - 2;
                    $pagej2 = $page - 3;
                    if($page == 4) {
                    echo"<td>
                            <a href='/admin/?page=".$pagej2."'>".$pagej2." </a>
                        </td>
                    <td>
                            <a href='/admin/?page=".$pagej1."'>".$pagej1." </a>
                        </td>
                    <td>
                            <a href='/admin/?page=".$pagej."'>".$pagej." </a>
                        </td>
                    ";
                    }else{
                    }
                    
                    $pagey = $page - 1;
                    $pagey1 = $page - 2;
                    if($page == 3) {
                    echo"<td>
                            <a href='/admin/?page=".$pagey1."'>".$pagey1." </a>
                        </td>
                    <td>
                            <a href='/admin/?page=".$pagey."'>".$pagey." </a>
                        </td>
                    ";
                    }else{
                    }
                    
                    $paget = $page - 1;
                    if($page == 2) {
                    echo"<td>
                            <a href='/admin/?page=".$paget."'>".$paget." </a>
                        </td>
                    ";
                    }else{
                    }
                    

                    for ($page<=$pagefix;$page<=$pagefix;$page++) {

                        echo "
                        <td>
                            <a href='/admin/?page=".$page."'>".$page." </a>
                        </td>
                        ";
                    }

                    echo "
<td><a href='/admin/?page=$numberofpages'>...</a></td>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    ";
                    ?>
      </tbody>
    </table>
    <style>
    table {
    display: table;
    border-collapse: separate;
    box-sizing: border-box;
    border-spacing: 2px;
    border-color: grey;
}
.GridPager {
    color: White;
    background-color: #b0c4de;
    text-align: center;
    font-weight: bold;
}
    </style>
		<?php require '../more/footer.php'; ?>
	  </div>
</div>
</codex>
</div>