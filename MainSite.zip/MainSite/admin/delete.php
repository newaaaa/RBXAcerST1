<?php
include '../more/connect.php';
$RefreshRate = rand(0,100000);

$select = $conn->query("SELECT * FROM users WHERE id='".$id."'");
$fetchuser = mysqli_fetch_object($select);

$id = trim($conn->real_escape_string($_GET['id']));
?>

<?php
if($user->id == "13") {
if (mysqli_connect_errno())
{
    printf("Connect failed: %s\n", mysqli_connect_error());
}

echo"done";

$ban = 1;

$conn->query("UPDATE users SET banned='$ban' WHERE id='$id'");

$conn->close();
}else{
echo"nope";
}
?>