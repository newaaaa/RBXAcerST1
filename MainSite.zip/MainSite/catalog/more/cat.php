<?php
$test = $_GET['tr']
?>
<div id="ctl00_cphRoblox_rbxCatalog_Timespan">
  <h4>Time</h4>
  <ul>
    <?php
    echo"
    <li>";
    if($test == "Past Day") {
      echo"<img id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekBullet' class='GamesBullet' src='/images/bullet.png' border='0'>
      <a id='ctl00_cphRoblox_rbxCatalog_TimespanPastDaySelector' href='?tr=Past Day'><b>Past Day</b></a></li>";
    }
    else {
    echo"
    <a id='ctl00_cphRoblox_rbxCatalog_TimespanPastDaySelector' href='?tr=Past Day'>Past Day</a></li>
    ";
    }
    echo"
    <li>
    ";
    if($test == "Past Week") {
      echo"<img id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekBullet' class='GamesBullet' src='/images/bullet.png' border='0'>
      <a id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekSelector' href='?tr=Past Week'><b>Past Week</b></a></li>";
    }
    else {
    echo"<a id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekSelector' href='?tr=Past Week'>Past Week</a></li>";
    }
    echo"
    <li>
    ";
    if($test == "Past Month") {
      echo"<img id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekBullet' class='GamesBullet' src='/images/bullet.png' border='0'>
      <a id='ctl00_cphRoblox_rbxCatalog_TimespanPastMonthSelector' href='?tr=Past Month'><b>Past Month</b></a></li>";
    }
    else {
    echo"<a id='ctl00_cphRoblox_rbxCatalog_TimespanPastMonthSelector' href='?tr=Past Month'>Past Month</a></li>";
    }
    echo"
    <li>
    ";
    if($test == "All-time") {
      echo"<img id='ctl00_cphRoblox_rbxCatalog_TimespanPastWeekBullet' class='GamesBullet' src='/images/bullet.png' border='0'>
      <a id='ctl00_cphRoblox_rbxCatalog_TimespanAllTimeSelector' href='?tr=All-time'><b>All-time</b></a></li>";
    }
    else {
    echo"<a id='ctl00_cphRoblox_rbxCatalog_TimespanAllTimeSelector' href='?tr=All-time'>All-time</a></li>
    ";
    }
    ?>
  </ul>
</div>
