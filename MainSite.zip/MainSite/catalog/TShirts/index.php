<?php
$test = $_GET['tr']
?>
<?php
include('../../more/connect.php');
if(!$loggedIn) {
	header("Location: /");
}

$query = "select * from tshirts";
$fetch_users = $conn->query("SELECT * FROM tshirts");
$res = mysqli_query($conn,$query);
$total_users = mysqli_num_rows($fetch_users);
?>
<?php require '../../more/Default.php'; ?>
<?php require '../../more/nav.php'; ?>
<div id="Body">




<div id="CatalogContainer">

	<div class="DisplayFilters">
	  <h2>Catalog</h2>
	  <div id="Category">
	    <h4>Category</h4>

	        <ul>

	        <li>
		 <img id="ctl00_cphRoblox_rbxCatalog_AssetCategoryRepeater_ctl04_SelectedCategoryBullet" class="GamesBullet" src="/images/bullet.png" border="0">
	          <a id="ctl00_cphRoblox_rbxCatalog_AssetCategoryRepeater_ctl01_AssetCategorySelector" href="../TShirts/?tr=<?php echo $test ; ?>"><b>T-Shirts</b></a>
	        </li>

	        <li>

	          <a id="ctl00_cphRoblox_rbxCatalog_AssetCategoryRepeater_ctl02_AssetCategorySelector" href="../Shirts/?tr=<?php echo $test ; ?>">Shirts</a>
	        </li>
	        
	        <li>

	          <a id="ctl00_cphRoblox_rbxCatalog_AssetCategoryRepeater_ctl04_AssetCategorySelector" href="../bodyp/?tr=<?php echo $test ; ?>">Body Packages</a>
	        </li>
	        
	        <li>
		 <a id="ctl00_cphRoblox_rbxCatalog_AssetCategoryRepeater_ctl03_AssetCategorySelector" href="../necka/?tr=<?php echo $test ; ?>">Neck Accessory</a></a>
	        </li>

	        <li>

	          <a id="ctl00_cphRoblox_rbxCatalog_AssetCategoryRepeater_ctl03_AssetCategorySelector" href="../Pants/?tr=<?php echo $test ; ?>">Pants</a>
	        </li>

	        <li>

	          <a id="ctl00_cphRoblox_rbxCatalog_AssetCategoryRepeater_ctl04_AssetCategorySelector" href="../Hats/?tr=<?php echo $test ; ?>">Hats</a>
	        </li>

	        </ul>

	  </div>

<?php require '../more/cat.php'; ?>
	</div>

    <div class="Assets">
        <span id="ctl00_cphRoblox_rbxCatalog_AssetsDisplaySetLabel" class="AssetsDisplaySet">Favorite T-Shirts, <?php echo $test ; ?></span>
	    <div id="ctl00_cphRoblox_rbxCatalog_HeaderPagerPanel" class="HeaderPager">

		    <span id="ctl00_cphRoblox_rbxCatalog_HeaderPagerLabel">Page 1 of 1</span>

	    </div>
	    <table id="ctl00_cphRoblox_rbxCatalog_AssetsDataList" cellspacing="0" align="Center" border="0" width="735">
	<tbody><tr><div><?php
$filter = trim($conn->real_escape_string($_GET['filter']));

while($row = mysqli_fetch_array($res)){

    $id = htmlspecialchars($row['id']);
    $price = htmlspecialchars($row['price']);
    $robux = htmlspecialchars($row['robux']);
    $name = htmlspecialchars($row['username']);

		 echo "<td valign='top'>
		        <div class='Asset'>
			        <div class='AssetThumbnail'>
				        <a id='ctl00_cphRoblox_rbxCatalog_AssetsDataList_ctl00_AssetThumbnailHyperLink' title='$name' href='/item/TShirts/?id=$id' style='display:inline-block;cursor:pointer;'><img src='/items/tshirts/$id/image.png' height='120' width='120' border='0' alt='$name' blankurl='http://t6.roblox.com:80/blank-120x120.gif'></a>
			        </div>
			        <div class='AssetDetails'>
				        <div class='AssetName'><a id='ctl00_cphRoblox_rbxCatalog_AssetsDataList_ctl00_AssetNameHyperLink' href='/item/TShirts/?id=$id'>$name</a></div>
				        <div class='AssetLastUpdate'><span class='Label'>Updated:</span> <span class='Detail'>6 days ago</span></div>
				        <div class='AssetCreator'><span class='Label'>Creator:</span> <span class='Detail'><a id='ctl00_cphRoblox_rbxCatalog_AssetsDataList_ctl00_CreatorHyperLink' href='/user/?id=13'>Codex</a></span></div>
				        <div class='AssetsSold'><span class='Label'>Number Sold:</span> <span class='Detail'>0</span></div>
				        <div class='AssetFavorites'><span class='Label'>Favorited:</span> <span class='Detail'>569 times</span></div>
";
				        if($robux == "Tickets") {
				        echo"
				        <div class='AssetPrice'><span class='PriceInTickets'>Tx: $price</span></div>
				        ";
                        }else{
				        echo"
				        <div class='AssetPrice'><span class='PriceInRobux'>R$: $price</span></div>
				        ";
                        }
				        echo"

			        </div>
			    </div>
		    </td>";

    $_GET['username'] = $username;
}
?></div></tr></tbody></table>
        <div id="ctl00_cphRoblox_rbxCatalog_FooterPagerPanel" class="HeaderPager">

            <span id="ctl00_cphRoblox_rbxCatalog_FooterPagerLabel">Page 1 of 1</span>

        </div>
    </div>
    <div style="clear: both;">
</div>

				</div>


<?php require '../../more/footer.php'; ?>
			</div>
<div>
	<script>
		function getInventory(type, page)
		{
			if(page == undefined){ page = 1; }
			$.post("https://error", {uid:5657,type:type,page:page}, function(data)
			{
				$("#AssetsContent").empty();
				$("#AssetsContent").html(data);
			})
			.fail(function()
			{
				$("#AssetsContent").text("An error occurred while fetching your inventory");
			});

			$('*[data-id]').removeClass().addClass("AssetsMenuItem");
			$('*[data-id]').children().removeClass().addClass("AssetsMenuButton");

			$('*[data-id="'+type+'"]').removeClass().addClass("AssetsMenuItem_Selected");
			$('*[data-id="'+type+'"]').children().removeClass().addClass("AssetsMenuButton_Selected");
		}

		$(document).ready(function()
		{
			$('.AssetsMenuItem').on('click', this, function()
			{
				getInventory($(this).attr("data-id"));
			});
			getInventory(1);
		});
	</script>
</div>
</div>
<div style="clear:both;"></div>

</div>
