<?php
include '../more/connect.php';
$RefreshRate = rand(0,100000);

include '../more/filter.php';
$id = trim($conn->real_escape_string($_GET['of']));

$selectu = $conn->query("SELECT * FROM users WHERE id='".$id."'");
$user = mysqli_fetch_object($selectu);

$select = $conn->query("SELECT * FROM friends WHERE uid='".$id."' OR friendid='".$id."'");
$fetchuser = mysqli_fetch_object($select);
?>
<?php require '../more/Default.php'; ?>
<?php require '../more/nav.php'; ?>
<div id='Body'>
<div id='FriendsContainer'>
	<div id='Friend'>
		<style>
		body {
    font: normal 8pt/normal 'Comic Sans MS',Verdana,sans-serif;
    margin-top: 0;
    text-transform: none;
    text-decoration: none;
}
		h4 {
    font-size: 10pt;
    font-weight: bold;
    line-height: 1em;
    margin-bottom: 5px;
    margin-top: 5px;
}
</style>
		<?php $check = $conn->query("SELECT * FROM friends WHERE uid='$id' OR friendid='$id'");
$CheckEnd = mysqli_num_rows($check);
?>
		<h4><?php echo $user->username ; ?>'s friends (<?php echo"$CheckEnd" ; ?>)</h4>
		<div align='center'>
		    		<?php $check = $conn->query("SELECT * FROM friends WHERE uid='$id' OR friendid='$id'");
		$CheckEnd = mysqli_num_rows($check);
		if($CheckEnd == 0) {
		echo"<p style='padding: 10px 10px 10px 10px;'>This person doesn't have any RBXAcer Friends.</p>";
		}else{
		}
		?>
					</div>
		<table cellspacing='0' border='0' align='Center'>
			<tbody>
				<tr>
<?php
															                    $resultsperpage = 5;
															                    $check = mysqli_query($conn, "SELECT * FROM friends");
															                    $usercount = mysqli_num_rows($check);

															                    $numberofpages = ceil($usercount/$resultsperpage);

															                    if(!isset($_GET['page'])) {
															                        $page = 1;
															                    }else{
															                        $page = $_GET['page'];
															                    }

															                    $thispagefirstresult = ($page-1)*$resultsperpage;

															                    $check = mysqli_query($conn, "SELECT * FROM friends WHERE uid='$id' OR friendid='$id' LIMIT ".$thispagefirstresult.",".$resultsperpage);

															                    while($result = mysqli_fetch_array($check)) {

															        if($result['uid'] == $id){
															            $FriendId = $result['friendid'];
															            $FriendName = $result['friendname'];
															        } else {
															            $FriendId = $result['uid'];
															            $FriendName = $result['uname'];
															        }
															        if(!empty($FriendId)){
															        echo"<td><div class='Friend'>
															                                        <div class='Avatar'>
															                                            <a title='$FriendName' href='/user/?id=$FriendId' style='display:inline-block;max-height:100px;max-width:100px;cursor:pointer;'>
															<iframe height='100' width='100' src='/api/getAvatar.php?id=$FriendId&amp;size=85' frameborder='0' scrolling='no'></iframe>
															                                            </a>
															                                        </div>
															                                        <div class='Summary'>
															                                                                                        <span class='OnlineStatus'>
															                                                <img src='/images/OnlineStatusIndicator_IsOffline.gif' alt='$FriendName' style='border-width:0px;'></span>
															                                                                                        <span class='Name'><a href='/user/?id=$FriendId'>$FriendName</a></span>
															                                        </div>
															                                    </div></td>";
															                    }
															    else{

															                    }
															                    }
															?>
                			    </tr><tr>
									                    						<?php
																								                    $resultsperpage = 5;
																								                    $check = mysqli_query($conn, "SELECT * FROM friends");
																								                    $usercount = mysqli_num_rows($check);

																								                    $numberofpages = ceil($usercount/$resultsperpage);

																								                    if(!isset($_GET['page'])) {
																								                        $page = 2;
																								                    }else{
																								                        $page = $_GET['page'];
																								                    }

																								                    $thispagefirstresult = ($page-1)*$resultsperpage;

																								                    $check = mysqli_query($conn, "SELECT * FROM friends WHERE uid='$id' OR friendid='$id' LIMIT ".$thispagefirstresult.",".$resultsperpage);

																								                    while($result = mysqli_fetch_array($check)) {

																								        if($result['uid'] == $id){
																								            $FriendId = $result['friendid'];
																								            $FriendName = $result['friendname'];
																								        } else {
																								            $FriendId = $result['uid'];
																								            $FriendName = $result['uname'];
																								        }
																								        if(!empty($FriendId)){
																								        echo"<td><div class='Friend'>
															                                        <div class='Avatar'>
															                                            <a title='$FriendName' href='/user/?id=$FriendId' style='display:inline-block;max-height:100px;max-width:100px;cursor:pointer;'>
															<iframe height='100' width='100' src='/api/getAvatar.php?id=$FriendId&amp;size=85' frameborder='0' scrolling='no'></iframe>
															                                            </a>
															                                        </div>
															                                        <div class='Summary'>
															                                                                                        <span class='OnlineStatus'>
															                                                <img src='/images/OnlineStatusIndicator_IsOffline.gif' alt='$FriendName' style='border-width:0px;'></span>
															                                                                                        <span class='Name'><a href='/user/?id=$FriendId'>$FriendName</a></span>
															                                        </div>
															                                    </div></td>";
																								                    }
																								    else{

																								                    }
																								                    }
																								?>
									                			    </tr><tr>
																	<?php
																																	                    $resultsperpage = 5;
																																	                    $check = mysqli_query($conn, "SELECT * FROM friends");
																																	                    $usercount = mysqli_num_rows($check);

																																	                    $numberofpages = ceil($usercount/$resultsperpage);

																																	                    if(!isset($_GET['page'])) {
																																	                        $page = 3;
																																	                    }else{
																																	                        $page = $_GET['page'];
																																	                    }

																																	                    $thispagefirstresult = ($page-1)*$resultsperpage;

																																	                    $check = mysqli_query($conn, "SELECT * FROM friends WHERE uid='$id' OR friendid='$id' LIMIT ".$thispagefirstresult.",".$resultsperpage);

																																	                    while($result = mysqli_fetch_array($check)) {

																																	        if($result['uid'] == $id){
																																	            $FriendId = $result['friendid'];
																																	            $FriendName = $result['friendname'];
																																	        } else {
																																	            $FriendId = $result['uid'];
																																	            $FriendName = $result['uname'];
																																	        }
																																	        if(!empty($FriendId)){
																																	        echo"<td><div class='Friend'>
															                                        <div class='Avatar'>
															                                            <a title='$FriendName' href='/user/?id=$FriendId' style='display:inline-block;max-height:100px;max-width:100px;cursor:pointer;'>
															<iframe height='100' width='100' src='/api/getAvatar.php?id=$FriendId&amp;size=85' frameborder='0' scrolling='no'></iframe>
															                                            </a>
															                                        </div>
															                                        <div class='Summary'>
															                                                                                        <span class='OnlineStatus'>
															                                                <img src='/images/OnlineStatusIndicator_IsOffline.gif' alt='$FriendName' style='border-width:0px;'></span>
															                                                                                        <span class='Name'><a href='/user/?id=$FriendId'>$FriendName</a></span>
															                                        </div>
															                                    </div></td>";
																																	                    }
																																	    else{

																																	                    }
																																	                    }
																																	?>			                			    </tr><tr>						<?php
																																										                    $resultsperpage = 5;
																																										                    $check = mysqli_query($conn, "SELECT * FROM friends");
																																										                    $usercount = mysqli_num_rows($check);

																																										                    $numberofpages = ceil($usercount/$resultsperpage);

																																										                    if(!isset($_GET['page'])) {
																																										                        $page = 4;
																																										                    }else{
																																										                        $page = $_GET['page'];
																																										                    }

																																										                    $thispagefirstresult = ($page-1)*$resultsperpage;

																																										                    $check = mysqli_query($conn, "SELECT * FROM friends WHERE uid='$id' OR friendid='$id' LIMIT ".$thispagefirstresult.",".$resultsperpage);

																																										                    while($result = mysqli_fetch_array($check)) {

																																										        if($result['uid'] == $id){
																																										            $FriendId = $result['friendid'];
																																										            $FriendName = $result['friendname'];
																																										        } else {
																																										            $FriendId = $result['uid'];
																																										            $FriendName = $result['uname'];
																																										        }
																																										        if(!empty($FriendId)){
																																										        echo"<td><div class='Friend'>
															                                        <div class='Avatar'>
															                                            <a title='$FriendName' href='/user/?id=$FriendId' style='display:inline-block;max-height:100px;max-width:100px;cursor:pointer;'>
															<iframe height='100' width='100' src='/api/getAvatar.php?id=$FriendId&amp;size=85' frameborder='0' scrolling='no'></iframe>
															                                            </a>
															                                        </div>
															                                        <div class='Summary'>
															                                                                                        <span class='OnlineStatus'>
															                                                <img src='/images/OnlineStatusIndicator_IsOffline.gif' alt='$FriendName' style='border-width:0px;'></span>
															                                                                                        <span class='Name'><a href='/user/?id=$FriendId'>$FriendName</a></span>
															                                        </div>
															                                    </div></td>";
																																										                    }
																																										    else{

																																										                    }
																																										                    }
																																										?></tr><tr>						<?php
																																																			                    $resultsperpage = 5;
																																																			                    $check = mysqli_query($conn, "SELECT * FROM friends");
																																																			                    $usercount = mysqli_num_rows($check);

																																																			                    $numberofpages = ceil($usercount/$resultsperpage);

																																																			                    if(!isset($_GET['page'])) {
																																																			                        $page = 5;
																																																			                    }else{
																																																			                        $page = $_GET['page'];
																																																			                    }

																																																			                    $thispagefirstresult = ($page-1)*$resultsperpage;

																																																			                    $check = mysqli_query($conn, "SELECT * FROM friends WHERE uid='$id' OR friendid='$id' LIMIT ".$thispagefirstresult.",".$resultsperpage);

																																																			                    while($result = mysqli_fetch_array($check)) {

																																																			        if($result['uid'] == $id){
																																																			            $FriendId = $result['friendid'];
																																																			            $FriendName = $result['friendname'];
																																																			        } else {
																																																			            $FriendId = $result['uid'];
																																																			            $FriendName = $result['uname'];
																																																			        }
																																																			        if(!empty($FriendId)){
																																																			        echo"<td><div class='Friend'>
															                                        <div class='Avatar'>
															                                            <a title='$FriendName' href='/user/?id=$FriendId' style='display:inline-block;max-height:100px;max-width:100px;cursor:pointer;'>
															<iframe height='100' width='100' src='/api/getAvatar.php?id=$FriendId&amp;size=85' frameborder='0' scrolling='no'></iframe>
															                                            </a>
															                                        </div>
															                                        <div class='Summary'>
															                                                                                        <span class='OnlineStatus'>
															                                                <img src='/images/OnlineStatusIndicator_IsOffline.gif' alt='$FriendName' style='border-width:0px;'></span>
															                                                                                        <span class='Name'><a href='/user/?id=$FriendId'>$FriendName</a></span>
															                                        </div>
															                                    </div></td>";
																																																			                    }
																																																			    else{

																																																			                    }
																																																			                    }
																																																			?>													                			    </tr>
			</tbody>
		</table>
	</div>
</div>
<?php require '../more/footer.php'; ?>
</div>
