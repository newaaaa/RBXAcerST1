<?php
include('../more/connect.php');
if(!$loggedIn) {
	header("Location: /");
}
?>
<?php require '../more/Default.php'; ?>
<div id="Container">
				<div id="Header">
					<div id="Banner">
						<div id="Options">
							<div id="Settings"></div>
						</div>
						<div id="Logo"><a id="ctl00_Image1" title="RBXAcer" href="/" style="display:inline-block;cursor:pointer;"><img src="/images/RBXAcer_Logo.png" border="0" id="img" alt="RBXAcer" blankurl="http://t2.roblox.com:80/blank-267x70.gif"></a></div>
					</div>
				</div>
				<div id="Body">
					
    <p id="ctl00_cphRoblox_SystemRequirements1_OS" align="center" style="color: red">Currently, RBXAcer is only available on PCs running the Windows® operating system</p>

    <div style="margin-top: 12px; margin-bottom: 12px">
         <div id="AlreadyInstalled" style="display: none">
                 <p>RBXAcer is already installed on this computer. If you want to try installing it again then
                 follow the instructions below. Otherwise, you can just <a href="javascript:goBack()">continue</a>.</p></div>
                 <img id="ctl00_cphRoblox_Image3" class="Bullet" src="/images/bullet1.png" border="0">
         <div id="InstallStep1" style="padding-left: 60px">
           <h2>Download RBXAcer</h2>
             
            <p><input type="submit" value="Install RBXAcer" onclick="Install()" class="BigButton"></p>
            <p><input type="submit" value="Install RBXAcer16" onclick="Install2()" class="BigButton"></p>
            <p><input type="submit" value="Install RBXAcer16 URI (required)" onclick="Install3()" class="BigButton"></p>
        </div>
        <script>
	function Install()
	{
		window.location = 'download/RBXAcer.exe';
	}
	function Install2()
	{
		window.location = 'https://www.mediafire.com/file/fu2lbi2u2buu99w/2016ST1v2.exe/file';
	}
	function Install3()
	{
		window.location = 'https://cdn.discordapp.com/attachments/829466565262311424/833125570547154985/rst12016.reg';
	}
</script>
        <img id="ctl00_cphRoblox_Image4" class="Bullet" src="/images/bullet2.png" border="0">
        <div id="InstallStep2" style="padding-left: 60px">
            <h2>
                Run
                the Installer</h2>
            <p>
                Click on the downloaded file called RBXAcer.exe.
            </p>
            <p>
                <img id="ctl00_cphRoblox_Image1" src="/images/DownloadPrompt.png" border="0">
            </p>
        </div>
        <img id="ctl00_cphRoblox_Image5" class="Bullet" src="/images/bullet3.png" border="0">
        <div id="InstallStep3" style="padding-left: 60px">
            <h2>
                Follow
                the Setup</h2>
            <p>
                Click 'Run'. You might see a confirmation message, asking if you're sure you want to run this software.
            </p>
            <p>
                <img id="ctl00_cphRoblox_Image2" src="/images/Wizard.png" border="0">
            </p>
        </div>
    </div>


				</div>
				<?php require '../more/footer.php'; ?>
			</div>