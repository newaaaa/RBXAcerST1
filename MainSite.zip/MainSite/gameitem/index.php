<?php
include '../more/connect.php';
if(!$loggedIn) {
	header("Location: /");
}
$RefreshRate = rand(0,100000);

include '../more/filter.php';
$id = trim($conn->real_escape_string($_GET['id']));

if(!$id || !is_numeric($id)) {
    header("Location: /user/?id=1");
    die();
}else{
    $checkExists = $conn->query("SELECT * FROM `games` WHERE `id`='$id'");
    $exists = mysqli_num_rows($checkExists);
    if($exists == 0) {
        header("Location: /404");
        die();
    }
}

$select = $conn->query("SELECT * FROM games WHERE id='".$id."'");
$fetchuser = mysqli_fetch_object($select);


if ($fetchuser == 0) {
    header("Location: ../");
}

if($fetchuser->username !== $user->username) {
$updateviews = $conn->query("UPDATE `games` SET `views` = `views` + 1 WHERE id = '$id'");
}

$getUviews = $conn->query("SELECT `views` FROM `games` WHERE id = '$id'");

while($row = mysqli_fetch_array($getUviews)) {
    $profileviews = $row['profile_views']; //$db-query("SELECT `profile_views` FROM `users` WHERE username='$fetch_user->username'");
}

?>
<?php require '../more/Default.php'; ?>
<script>
  function getGame() {
    document.location = ""
  }
</script>
<?php require '../more/nav.php'; ?>
		<style>
	.Tab {
		background-color: #f8f8f8;
		border-left: 2px solid #bfc1c0!important;
		border-right: 2px solid #bfc1c0!important;
		border-top: 1px solid #bfc1c0;
		padding: 1px 5px 0 5px;
		display: inline-table;
		border-top-left-radius: 3px;
		border-top-right-radius: 3px;
		margin: 0px;
        bottom: -2px;
        position: relative;
	}
	.Tab:hover {
		background-color: #f2f2f2;
		cursor:pointer;
	}
	.Tab.Active {
		background-color: #fff;
        border-top: 3px solid #f6b93c;
		padding-top: 1px!important;
		margin: 0px!important;
        position: relative;
        padding-bottom: 2px;
	}
	.TabContent {
		background:#fff;
		padding:15px;
        padding-top:3px;
		margin:0px;
		border:2px solid #bfc1c0;
	}
    .Tab h3{
        margin: 0 0 0.1em 0!important;
    }
</style>
<?php
date_default_timezone_set('America/Phoenix');
$date = date('m/d/Y h:i:s a', time());
if(!$loggedIn) { 
$usernameC = "Guest";
} 
else {
$usernameC = $user->username;
}

$stringbuild = $fetchuser->ip."|".$fetchuser->port."|".$usernameC."|".$user->id;
$encryptstring = base64_encode($stringbuild);
$uri = "RBXAcer14://".$encryptstring;
$ip = base64_decode($row['ip']);
?>
<script>
	var sid;
	var token;
	var sid2;
	var activeTab = 1;
	function showTab(num) 
    {
		$("#tab" + activeTab).removeClass("Active");
		$("#tabb" + activeTab).hide();
		activeTab = num;
		$("#tab" + num).addClass("Active");
		$("#tabb" + num).show();
	}
	function JoinGame(serverid = 0) 
    {
		$("#joiningGameDiag").show();
		$.post("", {placeId:1, serverId:serverid}, function(data) {
			if(isNaN(data) == false) 
            {
				sid = data;
				setTimeout(function() { checkifProgressChanged(); }, 1500);
			}
            else if (data.startsWith("")) 
            {
				$("#Requesting").html("The server is ready. Joining the game... ");
				token = data;
				location.href= "<?php echo $uri ; ?>";
				setTimeout(function() { closeModal(); }, 2000);
			} 
            else 
            {
				$("#Spinner").hide();
				$("#Requesting").html(data);
			}
		});
	}
	function checkifProgressChanged() 
    {
		$.getJSON("" + sid, function(result) {
			$("#Requesting").html(result.msg);
			if(result.token == null) 
            {
				if(result.check == true) 
                {
					setTimeout(function() { checkifProgressChanged() }, 750);
				} 
                else 
                {
					$("#Spinner").hide();
				}
			} 
            else 
            {
				token = result.token;
				location.href="" + token;
				setTimeout(function() { closeModal(); }, 2000);
			}
		});
	}
	function joinServer() 
    {
		$.getJSON("" + sid2, function(result) 
        {
			$("#Requesting").html(result.msg);
			if(result.token != null) 
            {
				token = result.token;
				location.href="" + token;
				setTimeout(function() { closeModal(); }, 2000);
			}
		});
	}
	function closeModal() 
    {
		$("#joiningGameDiag").hide();
		$("#Spinner").show();
		$("#Requesting").html("Requesting a server");
	}
    </script>
    <div id="Body">
	
<style>
  #ItemContainer #Thumbnail_Place {
  height: 230px;
  width: 420px;
  }
  .PlayGames {
  background-color: #ccc;
  border: dashed 1px Green;
  clear: left;
  color: Green;
  float: left;
  margin-top: 10px;
  padding: 10px 5px;
  text-align: center;
  width: 410px;
  }
  #ItemContainer #Actions, #ItemContainer #Actions_Place {
  background-color: #fff;
  border-bottom: dashed 1px #555;
  border-left: dashed 1px #555;
  border-right: dashed 1px #555;
  clear: left;
  float: left;
  padding: 5px;
  text-align: center;
  min-width: 0;
  position: relative;
  }
</style>
<div id="joiningGameDiag" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(100,100,100,0.25);">
  <div class="modalPopup" style="width: 27em; position: absolute; top: 50%; left: 50%; transform: translateX(-50%) translateY(-50%);">
    <div style="margin: 1.5em">
      <div id="Spinner" style="float:left;margin:0 1em 1em 0">
        <img src="/images/ProgressIndicator2.gif" style="border-width:0px;">
      </div>
      <div id="Requesting" style="display: inline">
        Requesting a server
      </div>
      <div style="text-align: center; margin-top: 1em">
        <input id="Cancel" onclick="closeModal()" type="button" class="Button" value="Cancel">
      </div>
    </div>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<style>
#ItemContainer {
    background-color: #eee;
    border: solid 1px #555;
    color: #555;
    margin: 0 auto;
    width: 620px;
}
#Item {
    font-family: Verdana, Sans-Serif;
    padding: 10px;
}
</style>
<div id="ItemContainer" style="width:725px; margin:unset;float:left;">
  <h2><?php echo "".$fetchuser->name.""; ?></h2>
  <div id="Item">
    <div id="Summary" style="width:251px;">
      <h3>RBXAcer Place</h3>
      <div id="Creator" class="Creator">
        <div class="Avatar">
<iframe src="/api/getAvatar.php?id=<?php echo "".$fetchuser->creatorid.""; ?>&size=90" frameborder="0" scrolling="no" width="100" height="110"></iframe>
          <a title="<?php echo "".$fetchuser->creatorname.""; ?>" href="/user/?id=1" style="display:inline-block;cursor:pointer;"></a>
        </div>
        Creator: <a href="/user/?id=<?php echo "".$fetchuser->creatorid.""; ?>"><?php echo "".$fetchuser->creatorname.""; ?></a>
      </div>
      <div id="LastUpdate">Updated: <?php echo "".$fetchuser->date.""; ?></div>
      <div class="Visited">Visited: <?php echo "".$fetchuser->views.""; ?></div>
            <div>
        <div id="DescriptionLabel">Description:</div>
        <div id="Description" style="width:auto;"><?php echo "".$fetchuser->map.""; ?></div>
      </div>
            <div id="ReportAbuse">
        <div class="ReportAbusePanel">
          <center>
              <br>
            <span class="AbuseIcon"><a><img src="/images/abuse.gif" alt="Report Abuse" border="0"></a></span>
            <span class="AbuseButton"><a>Report Abuse</a></span>
                      </center>
        </div>
      </div>
    </div>
    <div id="Details">
      <div id="Thumbnail_Place">
        <a title="<?php echo "".$fetchuser->name.""; ?>" style="display:inline-block;cursor:pointer;"><img src="/images/gamesimg/<?php echo "".$fetchuser->id.""; ?>big" border="0" alt="<?php echo "".$fetchuser->name.""; ?>"></a>
      </div>
      <div id="Actions_Place" style="width: 408px;">
<a href='#'>Favorite</a>
              </div>
            <div class="PlayGames">
        <div style="text-align: center; margin: 1em 5px;">
                    <span style="display:inline;"><img src="/images/gameimg/public.png" style="border-width:0px;">&nbsp;Public</span>
                    <img src="/images/gameimg/CopyLocked.png" style="border-width:0px;"> Copy Protection: CopyLocked
                  </div>
        <div>
          <div style="display: inline; width: 10px; ">
            <input type="image" class="ImageButton" src="/images/gameimg/Play.png" alt="Visit Online" onclick="JoinGame()">
          </div>
        </div>
      </div>
      <div style="clear: both;"></div>
    </div>
  </div>
</div>
<div style="clear: both;"></div>
      <?php require '../more/footer.php'; ?>


</div>
    	</div>