<?php
include '../more/connect.php';
if($loggedIn) {
	header("Location: ../my/home");
}
if(isset($_POST['sign_in'])){

$username = strip_tags($_POST['username']);
$username = trim($conn->real_escape_string($username));
$username = htmlentities($username);

$password = strip_tags($_POST['password']);
$password = trim($conn->real_escape_string($password));
$password = htmlentities($password);

    $checkUsernameQ = "SELECT * FROM users WHERE username = '$username'";
    $checkUsername = $conn->query($checkUsernameQ);

    $username = mysqli_real_escape_string($conn, $username);
	$userRow = (object) $checkUsername->fetch_assoc();
    $pass = $userRow->{'password'};

 if($checkUsername->num_rows > 0){
	 if (password_verify($password, $pass)) { //logged in
			$_SESSION['id'] = $userRow->{'id'};
			$userID = $_SESSION['id'];
			header('Location: ../my/home');
			die();
	 }else{
	     $error = '
          <div style="color:red; text-align:center;"><center>Wrong password!</center></div>
       ';
	 }
   }else{
       $error = '
          <div style="color:red; text-align:center;"><center>No accounts with this username. Create one!</center></div>
       ';
   }
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php require '../more/Default.php'; ?>
<style type="text/css">
body {
  margin-top:0 !important;
  padding-top:0 !important;
  /*min-width:800px !important;*/
}
</style>
<script>__wm.rw(0);</script>
<div id="wm-ipp-base" lang="en" style="display: block; direction: ltr;">
</div>
			<div id="Container">
				<div id="Header">
					<div id="Banner">
						<div id="Options">
					<div style="top: 0px; left: 0px; padding: 4px; position: absolute;">
						<span><a href="/Login">Login</a></span>
					</div>
				</div>
						<div id="Logo"><a id="ctl00_Image1" title="RBXAcer" href="/" style="display:inline-block;cursor:hand;"><img src="../images/RBXAcer_Logo.png" border="0" id="img" blankurl="http://t2.roblox.com:80/blank-267x70.gif"></a></div>
					</div>
				</div>
				<div id="Body">
				    
<br>
  <?php
        if(!empty($error)){
            echo $error;
        }
        ?>
        <br>
	<div id="FrameLogin" style="margin: 150px auto 150px auto; width: 500px; border: black thin solid; padding: 22px;">
		<div id="PaneNewUser">
			<h3>New User?</h3>
			<p>You need an account to play RBXAcer.</p>
			<p>If you aren't a RBXAcer member then <a id="ctl00_cphRoblox_HyperLink1" href="/register">register</a>. It's easy and we do <em>not</em> share your personal information with anybody.</p>
		</div>
		<div id="PaneLogin">
			<h3>Log In</h3>
          <form method="POST" action="">
<div class="AspNet-Login">
	<div class="AspNet-Login-UserPanel">
		<label for="username" class="TextboxLabel"><em>U</em>ser Name:</label>
		<input type="text" name="username" value="" accesskey="u">&nbsp;
	</div>
	<div class="AspNet-Login-PasswordPanel">
		<label for="password" class="TextboxLabel"><em>P</em>assword:</label>
		<input type="password" name="password" value="" accesskey="p">&nbsp;
	</div>
	<div class="AspNet-Login-SubmitPanel">
		<input href="#" type="submit" name="sign_in" value="Log In">
	</div>
</div>
</form>
		</div>
	</div>

				</div></body></html>
