<?php
include '../../more/connect.php';
include '../../more/filter.php';
if(!$loggedIn) {
	header("Location: /");
}                             

$update = trim($conn->real_escape_string($_POST['update']));
if ($update) {
    $passwordOld = strip_tags($_POST['passwordOld']);
    $passwordOld = trim($conn->real_escape_string($passwordOld));
    $passwordOld = htmlentities($passwordOld);
    
    $password = strip_tags($_POST['password']);
    $password = trim($conn->real_escape_string($password));
    $password = htmlentities($password);

    $passwordCon = strip_tags($_POST['passwordCon']);
    $passwordCon = trim($conn->real_escape_string($passwordCon));
    $passwordCon = htmlentities($passwordCon);
    
    $pass = $user->password;
    
    if (password_verify($passwordOld, $pass)) { 
    
	}else{
	     $error = '
          <div style="color:red; text-align:center;"><center>The old password you entered is incorrect.</center></div>
       ';
	}

    if($password !== $passwordCon){
        $error = '
            <div style="color:red; text-align:center;"><center>
          Two passwords do not match. They must be the same.
        </center></div>
        ';
    }

$NewpasswordOld = password_hash($passwordOld, PASSWORD_DEFAULT);

$hashed_password = password_hash($password, PASSWORD_DEFAULT);

    if(empty($error)){
    $conn->query("UPDATE users SET password='$hashed_password' WHERE id='$user->id'");
        $error = '
            <div style="color:red; text-align:center;"><center>
          Password Changed!
          </center></div>
        ';
    }
}
?>
<?php require '../../more/Default.php'; ?>
<?php require '../../more/nav.php'; ?>
<div id="Body">
	<style>
	#EditProfileContainer {
    background-color: #eeeeee;
    border: 1px solid #000;
    color: #555;
    margin: 0 auto;
    width: 620px;
}
fieldset {
    font-size: 1.2em;
    margin: 15px 0 0 0;
}
</style>
	<div id="EditProfileContainer">
		<h2>Change Your Password</h2>
		<div><span id="WrongOldPW" style="color:Red;"><br><?php
        if(!empty($error)){
            echo $error;
        }
        ?></span></div>
		<div id="Blurb">
<form method="post">
    <style>
.brfix {
    margin: 10px;
}</style>
	<div style="margin-left: 30px; width: 313px;" align="right">
	    <div class="brfix">
	    <label for="Password">Password:</label>
	    <input name="passwordOld" type="password" id="Password" class="TextBox">
	    <br>
	    </div>
	    <div class="brfix">
	    <label for="NewPassword">New Password:</label>
	    <input name="password" type="password" id="NewPassword" class="TextBox">
	    <br></div>
	    <div class="brfix">
	    <label for="ConfirmNewPassword">Confirm New Password:</label>
	    <input name="passwordCon" type="password" id="ConfirmNewPassword" class="TextBox">
	    </div>
	</div>
			</fieldset>
		</div>
		<div class="Buttons">
			<input id="Submit" tabindex="4" class="Button" type="submit" name="update" value="Update">
			&nbsp;
			<a id="Cancel" tabindex="5" class="Button" href="/my/settings">Cancel</a>
		</div>
	</div>
</form>
<?php require '../../more/footer.php'; ?>
</div>
