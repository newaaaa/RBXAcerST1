<style type="text/css">
body {
  margin-top:0 !important;
  padding-top:0 !important;
  /*min-width:800px !important;*/
}
</style>
<?php require 'more/Default.php'; ?>
				<div id="Header">
					<div id="Banner">
						<div id="Options">
							<div id="Settings"></div>
						</div>
						<div id="Logo"><a id="ctl00_Image1" title="RBXAcer" href="/" style="display:inline-block;cursor:hand;"><img src="/images/Logo.png" border="0" id="img" blankurl="http://t2.roblox.com:80/blank-267x70.gif"></a></div>
					</div>
				</div>
<div id="Body">

    <p>
        &nbsp;</p>
    <p>
        &nbsp;</p>
    <center>
<font size="4">
    <b> An Error occured! We're sorry. </b>
</font>
</center>

    <p>
        &nbsp;</p>
    <p>
        &nbsp;</p>
<?php require 'more/footer.php'; ?>
				</div>
