(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_P_", frames: [[0,407,300,52],[705,341,120,126],[0,0,400,217],[704,155,236,125],[0,219,301,186],[303,219,70,65],[705,282,271,57],[303,286,400,132],[402,0,300,284],[827,341,119,96],[704,0,300,153]]},
		{name:"index_atlas_NP_", frames: [[0,0,1000,359]]}
];


// symbols:



(lib.bg970 = function() {
	this.initialize(ss["index_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.bnt = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.boom = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.car_main_ = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.car_three = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.car_two = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.fireflash = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.flash = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.logo = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.logo1 = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.smoke11 = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.smoke = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.wsmoke = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.smoke11();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.6126,0.6126);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,72.9,58.8);


(lib.Symbol29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_copy
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#F769CB").ss(1,1,1).p("APJjQIAACnIAVAAIAAi6IhMAAIgFCNQAAAJgCAGQgBAGgFADQgEADgJAAIAAATIAEAAQAOgBAIgFQAIgGADgKQAEgKAAgPIAEh5gAQ5i9IAACUIATAAIAAi6IgXAAIguCLIAAiLIgTAAIAAC6IAWAAgAK8iWIAAg6IA5AAIAAgTIhOAAIAAC6IArAAQAWAAALgLQAKgMAAgWIAAgUQAAgXgLgKQgLgLgWAAgAK8g8IAAhHIAVAAQAMgBAGAGQAFAFAAANIAAAXQAAANgFAGQgFAHgMgBgANWi9IAACUIATAAIAAi6IgXAAIguCLIAAiLIgTAAIAAC6IAWAAgAIYi+IAACVIATAAIAAi6IgcAAIgeCVIgeiVIgdAAIAAC6IASAAIAAiUIAeCUIAUAAgAI+hVQAAAVAKAMQALANAVAAQAWAAAKgNQALgMAAgVIAAhhQAAgVgLgNQgKgMgWgBQgVABgLAMQgKANAAAVgAJSi3QAAgNAGgHQAFgHALAAQALAAAGAHQAFAHAAANIAABjQAAAMgFAHQgGAHgLAAQgLAAgFgHQgGgHAAgMgAFriQIAAhAIA4AAIAAgTIhNAAIAAC6IBNAAIAAgTIg4AAIAAhCIAtAAIAAgSgAEsh8IAABTIAVAAIAAi6IgVAAIAABUIgtAAIAAhUIgVAAIAAC6IAVAAIAAhTgACAhVQAAAVALAMQAKANAWAAQAVAAALgNQAKgMAAgVIAAhhQAAgVgKgNQgLgMgVgBQgWABgKAMQgLANAAAVgAAfjjIAAC6IAVAAIAAhJIASAAQAWAAALgLQAKgMAAgWIAAgWQAAgWgKgLQgKgMgWgBgACVi3QAAgNAFgHQAGgHALAAQALAAAFAHQAGAHAAANIAABjQAAAMgGAHQgFAHgLAAQgLAAgGgHQgFgHAAgMgACeBRIAACUIATAAIAAi6IgYAAIguCKIAAiKIgSAAIAAC6IAVAAgAEQA+IAAgTIhKAAIAAC6IAVAAIAAingAE5CJIAAhLIATAAQAMAAAFAGQAFAGAAANIAAAZQAAANgGAGQgGAGgLAAgAEkArIAAC6IAVAAIAAhJIASAAQAWAAALgMQAKgLAAgWIAAgXQAAgVgKgMQgKgMgWAAgAGcB9IAAg/IA3AAIAAgTIhMAAIAAC6IBMAAIAAgTIg3AAIAAhCIAtAAIAAgTgAg1iWIAAg6IA4AAIAAgTIhNAAIAAC6IArAAQAWAAAKgLQAKgMAAgWIAAgUQAAgXgLgKQgKgLgWAAgAg1g8IAAhHIAVAAQAMgBAGAGQAFAFAAANIAAAXQAAANgFAGQgFAHgMgBgAA0iFIAAhLIATAAQAMAAAFAHQAFAGAAANIAAAYQAAAOgGAGQgGAGgLgBgAi0gpIAVAAIgxhlIAwhVIgVAAIgyBaIAAhaIgVAAIAAC6IAVAAIAAg+IALgTgAiQh8IAzAAIAAgTIgzAAgAjkDlIAWAAIgrhsIAphOIgUAAIgtBVIAAhVIgVAAIAABVIgshVIgVAAIAqBPIgrBrIAVAAIAkhYIAJASIAABGIAVAAIAAhGIAKgSgAiqB9IAAg/IA3AAIAAgTIhMAAIAAC6IBMAAIAAgTIg3AAIAAhCIAtAAIAAgTgAgiB6IAAg8IAVAAQALAAADAGQAFAGAAAMIAAALQAAAOgGAGQgGAFgMAAgAgiDSIAAhFIASAAQANgBAGAHQAGAGAAAPIAAARQAAANgFAGQgFAGgLAAgAg3ArIAAC6IArAAQAVAAAKgMQALgLAAgVIAAgPQAAgQgGgKQgGgKgNgEQAMgEAFgJQAFgJgBgPIAAgJQABgVgKgKQgJgKgVAAgAkmh8IAABTIAVAAIAAi6IgVAAIAABUIgtAAIAAhUIgVAAIAAC6IAVAAIAAhTgAmUhOIAHAlIAVAAIgki6IgeAAIgjC6IATAAIAHglgAmsjLIAVBrIgqAAgAqojjIAAC6IAVAAIAAhJIASAAQAWAAALgLQAKgMAAgWIAAgWQAAgWgKgLQgKgMgWgBgAqTiFIAAhLIATAAQAMAAAFAHQAFAGAAANIAAAYQAAAOgGAGQgGAGgLgBgAoDjQIAACnIAVAAIAAi6IhXAAIAAC6IAVAAIAAingAlyArIgVAAIgcBvIgfhvIgVAAIArCJIgEAMQgDALgGAEQgGAEgMgBIAAATQARABAJgFQAKgEAFgKQAGgJADgOgAryiQIAAhAIA3AAIAAgTIhMAAIAAC6IBMAAIAAgTIg3AAIAAhCIAtAAIAAgSgAtdiWIAAg6IA6AAIAAgTIhOAAIAAC6IArAAQAWAAAKgLQALgMAAgWIAAgUQAAgXgLgKQgMgLgVAAgAtdg8IAAhHIAWAAQALgBAGAGQAGAFAAANIAAAXQAAANgFAGQgGAHgLgBgAwEgpIAWAAIgxhlIAvhVIgVAAIgxBaIAAhaIgVAAIAAC6IAVAAIAAg+IALgTgAuZi9IAACUIASAAIAAi6IgXAAIguCLIAAiLIgSAAIAAC6IAVAAg");
	this.shape.setTransform(110.45,34.2025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F7A1DA").s().p("AnLDlIAAgTQALABAHgEQAGgEADgLIAEgMIgriJIAVAAIAfBvIAbhvIAWAAIgoCRQgDAOgFAJQgFAKgKAEQgJAFgOAAIgDgBgAGGDlIAAi6IBNAAIAAATIg4AAIAAA/IAtAAIAAATIgtAAIAABCIA4AAIAAATgAEjDlIAAi6IApAAQAWAAAKAMQAKAMAAAVIAAAXQAAAWgLALQgLAMgWAAIgSAAIAABJgAE4CJIASAAQAMAAAGgGQAFgGABgNIAAgZQAAgNgGgGQgEgGgMAAIgUAAgADGDlIAAi6IBKAAIAAATIg1AAIAACngACdDlIAAiUIgvCUIgVAAIAAi6IASAAIAACKIAuiKIAXAAIAAC6gAg3DlIAAi6IAqAAQAUAAAKAKQAKAKgBAVIAAAJQAAAPgFAJQgEAJgNAEQAOAEAFAKQAHAKAAAQIAAAPQgBAVgKALQgKAMgVAAgAgiDSIAWAAQALAAAEgGQAGgGAAgNIAAgRQAAgPgHgGQgFgHgNABIgSAAgAgiB6IAQAAQAMAAAGgFQAFgGAAgOIAAgLQABgMgFgGQgDgGgMAAIgUAAgAjADlIAAi6IBNAAIAAATIg3AAIAAA/IAtAAIAAATIgtAAIAABCIA3AAIAAATgAjkDlIgkhYIgKASIAABGIgUAAIAAhGIgJgSIgkBYIgVAAIAqhrIgphPIAVAAIAsBVIAAhVIAUAAIAABVIAthVIAVAAIgpBOIArBsgAJIg0QgLgMAAgVIAAhhQAAgVALgNQAKgMAWgBQAVABALAMQALANAAAVIAABhQAAAVgLAMQgLANgVAAQgWAAgKgNgAJXjLQgFAHAAANIAABjQAAAMAFAHQAGAHALAAQALAAAFgHQAGgHAAgMIAAhjQAAgNgGgHQgFgHgLAAQgLAAgGAHgACKg0QgKgMAAgVIAAhhQAAgVAKgNQALgMAWgBQAVABAKAMQALANAAAVIAABhQAAAVgLAMQgKANgVAAQgWAAgLgNgACajLQgFAHgBANIAABjQABAMAFAHQAGAHALAAQAKAAAGgHQAFgHAAgMIAAhjQAAgNgFgHQgGgHgKAAQgLAAgGAHgAN4goIAAgTQAJAAAEgDQAFgDABgGIACgPIAFiNIBMAAIAAC6IgWAAIAAinIgjAAIgEB5QgBAPgDAKQgDAKgJAGQgHAFgOABgAQ5gpIAAiUIgvCUIgWAAIAAi6IASAAIAACLIAuiLIAYAAIAAC6gANWgpIAAiUIgwCUIgVAAIAAi6IATAAIAACLIAtiLIAYAAIAAC6gAKngpIAAi6IBOAAIAAATIg6AAIAAA6IAWAAQAWAAALALQALAKAAAXIAAAUQAAAWgKAMQgLALgWAAgAK7g8IAXAAQAMABAFgHQAFgGAAgNIAAgXQAAgNgFgFQgHgGgLABIgWAAgAIXgpIAAiVIgdCVIgUAAIgfiUIAACUIgSAAIAAi6IAeAAIAeCVIAdiVIAdAAIAAC6gAFWgpIAAi6IBMAAIAAATIg3AAIAABAIAtAAIAAASIgtAAIAABCIA3AAIAAATgAEsgpIAAhTIguAAIAABTIgUAAIAAi6IAUAAIAABUIAuAAIAAhUIAUAAIAAC6gAAegpIAAi6IApAAQAWABAKAMQAKALAAAWIAAAWQAAAWgLAMQgLALgWAAIgSAAIAABJgAAziFIASAAQAMABAGgGQAFgGAAgOIAAgYQABgNgGgGQgEgHgMAAIgUAAgAhKgpIAAi6IBNAAIAAATIg4AAIAAA6IAVAAQAWAAAKALQALAKAAAXIAAAUQAAAWgKAMQgKALgWAAgAg1g8IAWAAQAMABAFgHQAFgGAAgNIAAgXQAAgNgFgFQgHgGgLABIgVAAgAi0gpIgohRIgLATIAAA+IgVAAIAAi6IAVAAIAABaIAxhaIAWAAIgwBVIAxBlgAkmgpIAAhTIgtAAIAABTIgVAAIAAi6IAVAAIAABUIAtAAIAAhUIAUAAIAAC6gAmOgpIgGglIgwAAIgGAlIgTAAIAji6IAeAAIAkC6gAmYhgIgUhrIgVBrIApAAgAoDgpIAAinIguAAIAACnIgUAAIAAi6IBXAAIAAC6gAqpgpIAAi6IApAAQAWABAKAMQAKALAAAWIAAAWQAAAWgKAMQgMALgWAAIgSAAIAABJgAqUiFIASAAQAMABAGgGQAFgGABgOIAAgYQAAgNgGgGQgEgHgMAAIgUAAgAsIgpIAAi6IBNAAIAAATIg3AAIAABAIAtAAIAAASIgtAAIAABCIA3AAIAAATgAtxgpIAAi6IBNAAIAAATIg5AAIAAA6IAVAAQAWAAALALQAMAKgBAXIAAAUQAAAWgKAMQgKALgXAAgAtdg8IAWAAQAMABAFgHQAGgGAAgNIAAgXQgBgNgFgFQgGgGgMABIgVAAgAuagpIAAiUIgvCUIgVAAIAAi6IASAAIAACLIAuiLIAXAAIAAC6gAwEgpIgnhRIgLATIAAA+IgVAAIAAi6IAVAAIAABaIAxhaIAWAAIgwBVIAxBlgAiQh8IAAgTIAyAAIAAATg");
	this.shape_1.setTransform(110.45,34.2025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,10.3,222,47.900000000000006);


(lib.Symbol28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_copy
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#F769CB").ss(1,1,1).p("AO6hQIAAhSIAUAAQAMAAAHAGQAGAGAAAPIAAAbQAAAOgGAHQgFAHgMAAgAO6i2IAAhRIgXAAIAADLIAtAAQAXAAALgNQALgNAAgXIAAgZQAAgYgLgMQgMgMgYAAgAMGhlIAIApIAWAAIgmjLIghAAIgnDLIAVAAIAIgpgANhkJQgXAAgLAOQgLAOAAAXIAABpQAAAYALANQALAOAXAAQAXAAAMgOQALgNAAgYIAAgZIgWAAIAAAbQABANgGAIQgGAIgMAAQgNAAgFgIQgGgIAAgNIAAhsQAAgOAGgHQAFgIANAAQAMAAAGAIQAGAHgBAOIAAAUIAWAAIAAgTQAAgXgLgOQgMgOgXAAgAIljyIAAgVIhRAAIAADLIAWAAIAAi2gAKMjyIAAC2IAXAAIAAjLIhTAAIgFCaQAAAKgCAGQgCAHgFADQgEADgKAAIAAAVIAEAAQAPgBAJgGQAJgFAEgMQADgLABgQIAEiEgAJcBNIAACiIAUAAIAAjLIgZAAIgzCXIAAiXIgUAAIAADLIAYAAgALLA4IAABMIgRAAQgOAAgHgGQgIgGAAgQIAAgUQAAgNAGgHQAFgIANAAgALLCYIAABXIAWAAIAAjLIgtAAQgYAAgKAMQgLAMAAAWIAAARQAAARAGAKQAGAKANAEQgOAFgGALQgGAKABARIAAAfQAAAHgBAGQgBAHgCAFIAWAAQACgEABgGQABgFAAgKIAAggQAAgRAIgGQAIgHAOAAgALsjtIAXB1IgtAAgAFokHIAADLIAXAAIAAhQIAUAAQAYAAAMgMQALgMAAgZIAAgYQAAgXgLgNQgLgNgXgBgAD3htQAAAYALANQAMAOAXAAQAXAAAMgOQAMgNAAgYIAAhpQAAgXgMgOQgMgOgXAAQgXAAgMAOQgLAOAAAXgAF/igIAAhSIAWAAQAMAAAFAHQAGAHAAAOIAAAbQAAAOgGAHQgHAGgMAAgAAbkHIAADLIAvAAQAXAAAMgMQALgMAAgXIAAgRQAAgRgGgLQgGgMgPgEQANgEAGgKQAFgKAAgQIAAgKQAAgWgKgLQgLgMgXAAgADCg8IAAi2IAmAAIAAgVIhiAAIAAAVIAmAAIAAC2gAENjXQAAgOAGgHQAGgIAMAAQAMAAAGAIQAGAHAAAOIAABsQAAAOgGAHQgGAIgMAAQgMAAgGgIQgGgHAAgOgABICLIAAhTIAWAAQAMAAAFAHQAGAHAAAOIAAAbQAAAPgGAGQgHAHgMAAgAAxAkIAADLIAXAAIAAhQIAUAAQAYAAAMgNQALgMAAgYIAAgZQAAgXgLgNQgLgNgXAAgAFkDvIAXAAIg1hvIA0hcIgXAAIg2BiIAAhiIgXAAIAADLIAXAAIAAhEIAMgUgADmDGIAIApIAXAAIgnjLIghAAIgmDLIAUAAIAIgpgAH9EKIAAgvIgPAAIAAi3IgXAAIAAC2IgyAAIAAi2IgWAAIAADLIBYAAIAAAbgAhohQIAAhSIAUAAQANAAAGAGQAGAGAAAPIAAAbQAAAOgFAHQgGAHgMAAgAhoi2IAAhRIgWAAIAADLIAsAAQAYAAALgNQALgNAAgXIAAgZQAAgYgMgMQgMgMgYAAgAAyiwIAAhCIAWAAQAMAAAFAHQAGAGAAAOIAAAMQAAAPgHAGQgHAGgOAAgAAyhQIAAhMIAUAAQAOAAAHAHQAHAHAAAQIAAASQAAAOgGAHQgGAHgMAAgAkmkHIAADLICRAAIAAjLIgWAAIAAC3IgnAAIAAi3IgWAAIAAC3IgnAAIAAi3gAjOA4IAABMIgRAAQgOAAgHgGQgIgGAAgQIAAgUQAAgNAGgHQAFgIANAAgAjOCYIAABXIAWAAIAAjLIgtAAQgYAAgKAMQgLAMAAAWIAAARQAAARAGAKQAGAKANAEQgOAFgGALQgGAKABARIAAAfQAAAHgBAGQgBAHgCAFIAWAAQACgEABgGQABgFAAgKIAAggQAAgRAIgGQAIgHAOAAgAgiA8IABgYIgXAAIAAAYIgOAAQgYAAgMANQgLANAAAYIAAA4QAAAYALANQAMANAYAAIAOAAIAAAXIAXAAIAAgXIAOAAQAXAAALgNQAMgNAAgYIAAg4QAAgYgMgNQgLgNgXAAgAg4BQIAAB1IgOAAQgNAAgGgIQgGgHAAgPIAAg6QAAgPAGgHQAGgHANAAgAghDFIAAh1IAOAAQANAAAGAHQAFAHAAAPIAAA6QAAAPgFAHQgHAIgMAAgADMA9IAXB2IgtAAgAmYhtQAAAYAMANQALAOAXAAQAYAAALgOQAMgNAAgYIAAhpQAAgXgMgOQgLgOgYAAQgXAAgLAOQgMAOAAAXgAnMg8IAAi2IAmAAIAAgVIhiAAIAAAVIAmAAIAAC2gAmCjXQAAgOAGgHQAGgIAMAAQANAAAGAIQAFAHAAAOIAABsQAAAOgFAHQgGAIgNAAQgMAAgGgIQgGgHAAgOgAp/kHIgYAAIgeB6Igih6IgXAAIAvCWIgFANQgDAMgGAEQgHAFgNgBIAAAVQASAAALgFQAKgFAGgKQAGgKADgPgApDkJQgYAAgLAOQgLAOAAAXIAABpQAAAYALANQALAOAYAAQAXAAALgOQALgNAAgYIAAgZIgVAAIAAAbQAAANgGAIQgGAIgMAAQgMAAgGgIQgGgIAAgNIAAhsQAAgOAGgHQAGgIAMAAQAMAAAGAIQAGAHAAAOIAAAUIAVAAIAAgTQAAgXgLgOQgLgOgXAAgAqcCUIAABbIAXAAIAAjLIgXAAIAABbIgyAAIAAhbIgWAAIAADLIAWAAIAAhbgApwC+QAAAXAMAOQALAOAXAAQAYAAALgOQAMgOAAgXIAAhpQAAgYgMgNQgLgOgYAAQgXAAgLAOQgMANAAAYgApaBUQAAgOAGgIQAGgIAMAAQANAAAGAIQAFAIAAAOIAABrQAAAOgFAIQgGAHgNAAQgMAAgGgHQgGgIAAgOgAn+AkIAADLIAvAAQAXAAAMgNQALgMAAgXIAAgRQAAgRgGgLQgGgLgPgEQANgEAGgKQAFgKAAgRIAAgJQAAgXgKgLQgLgLgXAAgAnnB6IAAhCIAWAAQAMAAAFAHQAGAHAAANIAAAMQAAAQgHAGQgHAFgOAAgAlCDGIAIApIAWAAIgmjLIghAAIgnDLIAVAAIAIgpgAsWjyIAAC2IAXAAIAAjLIhfAAIAADLIAWAAIAAi2gAv8kHIAADLIAvAAQAXAAALgMQAMgMAAgXIAAgRQAAgRgGgLQgHgMgPgEQAOgEAFgKQAGgKgBgQIAAgKQABgWgLgLQgKgMgYAAgAvmiwIAAhCIAXAAQAMAAAFAHQAFAGAAAOIAAAMQAAAPgHAGQgHAGgNAAgAvmhQIAAhMIAUAAQAPAAAGAHQAHAHAAAQIAAASQAAAOgFAHQgGAHgMAAgAlcA9IAXB2IgtAAgAnnDaIAAhLIAUAAQAOgBAHAHQAHAHAAARIAAASQAAAOgGAHQgGAGgMAAg");
	this.shape.setTransform(110.525,38.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F7A1DA").s().p("AHnEJIAAgbIhYAAIAAjKIAWAAIAAC2IAyAAIAAi2IAXAAIAAC2IAPAAIAAAwgApkDjQgMgOAAgXIAAhqQAAgXAMgNQALgOAXgBQAYABALAOQAMANAAAXIAABqQAAAXgMAOQgLANgYAAQgXAAgLgNgApUA+QgGAIAAANIAABsQAAAOAGAHQAGAIAMAAQANAAAGgIQAFgHAAgOIAAhsQAAgNgFgIQgGgIgNAAQgMAAgGAIgALLDuIAAhWIgQAAQgOAAgIAGQgIAHAAARIAAAgIgBAPIgDAJIgWAAQACgEABgHIABgNIAAgfQgBgRAGgKQAGgMAOgEQgNgEgGgKQgGgLAAgQIAAgRQAAgWALgMQAKgMAYAAIAtAAIAADKgAKjBAQgGAGAAAOIAAATQAAAQAIAHQAHAFAOAAIARAAIAAhLIgWAAQgNAAgFAIgAJcDuIAAihIg0ChIgYAAIAAjKIAUAAIAACXIAziXIAZAAIAADKgAFkDuIgrhYIgMAVIAABDIgXAAIAAjKIAXAAIAABiIA2hiIAXAAIg0BcIA1BugADuDuIgIgoIgzAAIgIAoIgUAAIAmjKIAhAAIAnDKgADjCzIgXh2IgWB2IAtAAgAAxDuIAAjKIAtAAQAXAAALANQALANAAAXIAAAZQAAAYgLAMQgMAMgYAAIgUAAIAABQgABICKIAUAAQAMAAAHgGQAGgHAAgOIAAgbQAAgOgGgHQgFgHgMAAIgWAAgAg4DuIAAgWIgOAAQgYAAgMgNQgLgNAAgZIAAg3QAAgYALgNQAMgOAYAAIAOAAIAAgXIAXAAIgBAXIAPAAQAXAAALAOQAMANAAAYIAAA3QAAAZgMANQgLANgXAAIgOAAIAAAWgAghDFIAOAAQAMAAAHgIQAFgHAAgPIAAg6QAAgPgFgHQgGgIgNABIgOAAgAhZBXQgGAHAAAPIAAA6QAAAPAGAHQAGAIANAAIAOAAIAAh1IgOAAQgNgBgGAIgAjODuIAAhWIgQAAQgOAAgIAGQgIAHAAARIAAAgIgBAPIgDAJIgWAAQACgEABgHIABgNIAAgfQgBgRAGgKQAGgMAOgEQgNgEgGgKQgGgLAAgQIAAgRQAAgWALgMQAKgMAYAAIAtAAIAADKgAj2BAQgGAGAAAOIAAATQAAAQAIAHQAHAFAOAAIARAAIAAhLIgWAAQgNAAgFAIgAk6DuIgIgoIgzAAIgIAoIgVAAIAnjKIAhAAIAmDKgAlFCzIgXh2IgWB2IAtAAgAn+DuIAAjKIAuAAQAXAAALALQAKALAAAXIAAAJQAAAQgFALQgGAJgNAEQAPAFAGALQAGALAAARIAAARQAAAXgLAMQgMAMgXAAgAnnDaIAYAAQAMAAAGgHQAGgGAAgOIAAgSQAAgRgHgHQgHgHgOABIgUAAgAnnB6IARAAQAOAAAHgFQAHgHAAgPIAAgMQAAgNgGgHQgFgHgMAAIgWAAgAqcDuIAAhbIgyAAIAABbIgWAAIAAjKIAWAAIAABbIAyAAIAAhbIAXAAIAADKgAM/hIQgLgNAAgYIAAhpQAAgXALgOQALgNAXgBQAXABAMANQALAOAAAXIAAATIgWAAIAAgUQABgOgGgIQgGgHgMgBQgNABgFAHQgGAIAAAOIAABsQAAANAGAIQAFAHANABQAMgBAGgHQAGgIgBgNIAAgbIAWAAIAAAZQAAAYgLANQgMAOgXAAQgXAAgLgOgAEChIQgLgNAAgYIAAhpQAAgXALgOQAMgNAXgBQAXABAMANQAMAOAAAXIAABpQAAAYgMANQgMAOgXAAQgXAAgMgOgAETjtQgGAIAAAOIAABsQAAAOAGAHQAGAHAMABQAMgBAGgHQAGgHAAgOIAAhsQAAgOgGgIQgGgHgMgBQgMABgGAHgAmMhIQgMgNAAgYIAAhpQAAgXAMgOQALgNAXgBQAYABALANQAMAOAAAXIAABpQAAAYgMANQgLAOgYAAQgXAAgLgOgAl8jtQgGAIAAAOIAABsQAAAOAGAHQAGAHAMABQANgBAGgHQAFgHAAgOIAAhsQAAgOgFgIQgGgHgNgBQgMABgGAHgApmhIQgLgNAAgYIAAhpQAAgXALgOQALgNAYgBQAXABALANQALAOAAAXIAAATIgVAAIAAgUQAAgOgGgIQgGgHgMgBQgMABgGAHQgGAIAAAOIAABsQAAANAGAIQAGAHAMABQAMgBAGgHQAGgIAAgNIAAgbIAVAAIAAAZQAAAYgLANQgLAOgXAAQgYAAgLgOgArhg8IAAgUQANABAHgFQAGgFADgLIAFgNIgviWIAXAAIAiB6IAeh6IAYAAIgsCeQgDAQgGAKQgGAKgKAFQgKAFgQAAIgDgBgAI0g8IAAgUQAKAAAEgEQAFgDACgGQACgHAAgJIAFiaIBTAAIAADLIgXAAIAAi2IgnAAIgECDQgBARgDALQgEALgJAGQgJAGgPAAgAOjg8IAAjLIAXAAIAABQIAUAAQAYAAAMANQALAMAAAYIAAAYQAAAXgLANQgLANgXABgAO6hQIAWAAQAMgBAFgGQAGgIAAgNIAAgbQAAgPgGgHQgHgFgMAAIgUAAgAMOg8IgIgpIgzAAIgIApIgVAAIAnjLIAhAAIAmDLgAMDh4IgXh2IgWB2IAtAAgAHUg8IAAjLIBRAAIAAAVIg7AAIAAC2gAFog8IAAjLIAtAAQAXABALANQALAMAAAYIAAAYQAAAZgLAMQgMAMgYAAIgUAAIAABQgAF/igIAUAAQAMAAAHgHQAGgGAAgOIAAgbQAAgOgGgIQgFgGgMAAIgWAAgACsg8IAAi2IgmAAIAAgVIBiAAIAAAVIgmAAIAAC2gAAbg8IAAjLIAuAAQAXAAALAMQAKAKAAAXIAAAJQAAARgFAKQgGAKgNAEQAPAEAGAMQAGAKAAASIAAARQAAAWgLANQgMAMgXAAgAAyhQIAYAAQAMAAAGgHQAGgHAAgOIAAgSQAAgQgHgIQgHgHgOABIgUAAgAAyixIARAAQAOAAAHgFQAHgGAAgPIAAgMQAAgOgGgHQgFgGgMAAIgWAAgAh+g8IAAjLIAWAAIAABQIAUAAQAYAAAMANQAMAMAAAYIAAAYQAAAXgLANQgLANgYABgAhohQIAWAAQAMgBAGgGQAFgIAAgNIAAgbQAAgPgGgHQgGgFgNAAIgUAAgAkmg8IAAjLIAXAAIAAC3IAnAAIAAi3IAWAAIAAC3IAnAAIAAi3IAWAAIAADLgAnig8IAAi2IgmAAIAAgVIBiAAIAAAVIgmAAIAAC2gAsWg8IAAi2IgyAAIAAC2IgWAAIAAjLIBfAAIAADLgAv8g8IAAjLIAtAAQAYAAAKAMQALAKgBAXIAAAJQABARgGAKQgFAKgOAEQAPAEAHAMQAGAKAAASIAAARQAAAWgMANQgLAMgXAAgAvmhQIAZAAQAMAAAGgHQAFgHAAgOIAAgSQAAgQgHgIQgGgHgPABIgUAAgAvmixIASAAQANAAAHgFQAHgGAAgPIAAgMQAAgOgFgHQgFgGgMAAIgXAAg");
	this.shape_1.setTransform(110.525,38.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(7.4,10.9,206.29999999999998,55.199999999999996);


(lib.Symbol25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.logo1();
	this.instance.parent = this;
	this.instance.setTransform(-21.1,-73.45,0.9446,0.9447,14.4295);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-87.9,-73.4,341.3,330.4);


(lib.Symbol22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.bnt();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,52);


(lib.Symbol21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#000000","rgba(0,0,0,0)"],[0,1],0,-97.1,0,96.9).s().p("A5iPLIAA+VMAzFAAAIAAeVg");
	this.shape.setTransform(186.8,102.4146,1,1.1714);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(23.3,-11.2,327,227.29999999999998);


(lib.Symbol20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.logo();
	this.instance.parent = this;
	this.instance.setTransform(-3,0,0.5896,0.5896);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3,0,235.9,77.9);


(lib.Symbol18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag5LhQgIgKjpglQjpgmgGgIQgcgkgghHQgwhpAVgxQATgrAfgwQAZgnAAgFQAAgNgdiHIgNgwQgKhaAQhbQAgi3B+AAQgJgXgDgcQgEg3Ajg9QAjg+A5gtQAcgWAWgKIOBh2IhDLNQiXDBiaDAQkoFzgTAAIgBAAg");
	mask.setTransform(172.9531,71.5932);

	// Layer_1
	this.instance = new lib.boom();
	this.instance.parent = this;
	this.instance.setTransform(109,0);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AsPigIECo+IMkAdIGCBEIANFDIBhEBIAIAgQAEArgWBFQgWBEgHBhQgEAxABAiIAgBxIANDBItIBdg");
	mask_1.setTransform(66.1558,58.35);

	// boom_png
	this.instance_1 = new lib.boom();
	this.instance_1.parent = this;
	this.instance_1.setTransform(145,0,1,1,0,0,180);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(25,0,204,126);


(lib.Symbol16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.car_two();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,301,186);


(lib.Symbol13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.flash();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,271,57);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#222222").s().p("EhMhARcMgAYgi4MCZbAAAMAAYAi4g");
	this.shape.setTransform(343.825,282.9512,1,1.1469);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-148.4,154.9,984.5,256.1);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.smoke();
	this.instance.parent = this;
	this.instance.setTransform(-128,22,1.3469,0.8842);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-128,22,404.1,135.3);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.fireflash();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,70,65);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.bg970();
	this.instance.parent = this;
	this.instance.setTransform(-240,-32,1.5933,1.5934);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-32,1593.4,572);


(lib.p12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJApIAAgfIgfAAIAAgTIAfAAIAAgfIATAAIAAAfIAfAAIAAATIgfAAIAAAfg");
	this.shape.setTransform(21.975,8.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgmA6QACgLAGgLQAGgKATgSQAOgNADgFQAEgHAAgGQAAgIgDgEQgFgEgHAAQgFAAgFAEQgEAFAAAJIgXgCQACgSALgIQALgIAOAAQARAAAKAJQAKAJAAAOQAAAIgDAHQgDAHgGAHIgOAPIgNAMIgEAHIArAAIAAAUg");
	this.shape_1.setTransform(12.85,8.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AADA6IAAhTQgLAMgQAFIAAgUQAIgDAKgIQAKgIADgKIASAAIAABzg");
	this.shape_2.setTransform(3.725,8.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.3,-3.9,33.199999999999996,25);


(lib.Symbol27copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol29("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(106.7,24.8,1,1,0,0,0,110.4,37.1);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},4).to({alpha:0},3).to({alpha:1},4).wait(37).to({startPosition:0},0).to({startPosition:0},16).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.2,-2,222,47.9);


(lib.Symbol27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol28("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(106.7,24.8,1,1,0,0,0,110.4,37.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({alpha:1},3).to({alpha:0},2).to({alpha:1},3).wait(45).to({startPosition:0},0).to({alpha:0.7891},3).to({alpha:0.6406},2).to({alpha:0},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-1.4,210,55.199999999999996);


(lib.Symbol24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol25("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(87.35,82.9,0.8545,0.8545,0,0,0,87,83.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.8879,scaleY:0.8879,alpha:1},13).to({scaleX:0.9291,scaleY:0.9291,x:87.4,y:82.95},16).to({scaleX:1.0089,scaleY:1.0089,x:87.45,y:82.85},31).to({scaleX:1.0475,scaleY:1.0475,x:87.5,y:82.9,alpha:0},15).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-95.8,-81.4,357.6,346.20000000000005);


(lib.Symbol23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol22("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(106.55,118.5,0.7095,0.7095,0,0,0,150.2,26.1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(48).to({_off:false},0).to({y:18.5},17,cjs.Ease.quadOut).wait(52));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,212.9,136.9);


(lib.Symbol19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol20("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(118,-69.6,1,1,0,0,0,113,37.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(48).to({_off:false},0).to({y:31.2},14,cjs.Ease.quadOut).wait(28));

	// Layer_2
	this.instance_1 = new lib.Symbol21("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(3.6,-20.85,1.9297,2.07,-90,0,0,163.2,82.6);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(46).to({_off:false},0).to({alpha:1},14).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-190.7,-382,470.7,631.1);


(lib.Symbol17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_copy
	this.instance = new lib.Symbol18("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-4.75,115.95,0.314,0.314,0,0,0,114.3,114.7);
	this.instance.alpha = 0.0898;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(47).to({_off:false},0).to({regX:114.4,scaleX:0.3541,scaleY:0.3541,x:-6.8,y:116.2,alpha:1},9).to({regX:114.5,regY:114.6,scaleX:1.0174,scaleY:1.0174,x:7.1,y:114.45},125).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84,-2.1,207.6,128.2);


(lib.Symbol10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_copy_copy_copy
	this.instance = new lib.Symbol4("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(477.4,85.65,1.5361,1.5361,0,0,0,149.5,65.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(84).to({_off:false},0).to({regY:65.5,scaleX:1.536,scaleY:1.536,x:444.55,y:85.75,alpha:0.9414},16).to({regY:65.6,scaleX:1.5361,scaleY:1.5361,x:442.55,y:85.8,alpha:1},1).to({regY:65.5,x:386.85,y:85.6},25).to({regY:65.6,x:355.6,y:85.65,alpha:0},22).wait(31));

	// Layer_1_copy_copy
	this.instance_1 = new lib.Symbol4("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(188.55,82.6,1.2613,1.2613,0,0,0,149.5,65.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(84).to({_off:false},0).to({x:141.35,y:82.7,alpha:1},27).to({x:114.2,y:82.65},15).to({x:88.55,y:82.6,alpha:0},22).wait(31));

	// Layer_1_copy_copy
	this.instance_2 = new lib.Symbol4("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(477.4,85.65,1.5361,1.5361,0,0,0,149.5,65.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(42).to({_off:false},0).to({x:442.55,y:85.8,alpha:1},17).to({x:402.5},18).to({regY:65.5,x:386.85,y:85.6},7).to({regY:65.6,x:355.6,y:85.65,alpha:0},22).to({_off:true},31).wait(42));

	// Layer_1_copy
	this.instance_3 = new lib.Symbol4("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(188.55,82.6,1.2613,1.2613,0,0,0,149.5,65.5);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(42).to({_off:false},0).to({x:141.35,y:82.7,alpha:1},27).to({x:114.2,y:82.65},15).to({x:88.55,y:82.6,alpha:0},22).to({_off:true},31).wait(42));

	// Layer_1_copy
	this.instance_4 = new lib.Symbol4("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(477.4,85.65,1.5361,1.5361,0,0,0,149.5,65.6);
	this.instance_4.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({x:442.55,y:85.8,alpha:1},17).to({regY:65.5,x:386.85,y:85.6},25).to({regY:65.6,x:355.6,y:85.65,alpha:0},22).to({_off:true},31).wait(84));

	// Layer_1
	this.instance_5 = new lib.Symbol4("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(188.55,82.6,1.2613,1.2613,0,0,0,149.5,65.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({x:141.35,y:82.7},27).to({x:114.2,y:82.65},15).to({x:88.55,y:82.6,alpha:0},22).to({_off:true},31).wait(84));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-313.7,18.7,985.5,277.7);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol13("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(147.5,28.3,1,1,0,0,0,135.5,28.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(139));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(12,-0.2,271,57);


(lib.sssmoke = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.wsmoke("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(36.5,29.45,0.7177,0.7177,0,0,0,36.5,29.4);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:36.4,scaleX:0.9897,scaleY:0.9897,x:29.35,y:13.45,alpha:0.75},9).to({scaleX:1.0804,scaleY:1.0804,x:27,y:8.05,alpha:1},3).to({scaleX:1.13,scaleY:1.13,x:18.95,y:-10.95},9).to({scaleX:1.1355,scaleY:1.1355,x:18.05,y:-13},1).to({regX:36.3,regY:29.2,scaleX:1.1465,scaleY:1.1465,x:16.1,y:-17.4},2).to({scaleX:1.1062,scaleY:1.1062,x:15.1,y:-19.95,alpha:0.8789},1).to({regX:36.5,regY:29.4,scaleX:0.8244,scaleY:0.8244,x:7.7,y:-37.75,alpha:0},7).wait(22));

	// Слой_1___копия___копия
	this.instance_1 = new lib.wsmoke("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(24.85,3.3,1.161,1.161,0,0,0,36.4,29.4);
	this.instance_1.alpha = 0.7305;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:36.3,regY:29.2,scaleX:1.3223,scaleY:1.3223,x:20.65,y:-6.35,alpha:1},5).to({scaleX:1.0582,scaleY:1.0582,x:13.85,y:-23,alpha:0.4688},10).to({regX:36.2,scaleX:1.0318,scaleY:1.0318,x:13.05,y:-24.6,alpha:0.4219},1).to({regX:36.5,regY:29.4,scaleX:0.8244,scaleY:0.8244,x:7.7,y:-37.75,alpha:0},8).wait(30));

	// Слой_1___копия___копия
	this.instance_2 = new lib.wsmoke("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(17.55,-13.7,1.2051,1.2051,0,0,0,36.2,29.2);
	this.instance_2.alpha = 0.7695;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:36.5,regY:29.4,scaleX:0.8244,scaleY:0.8244,x:7.7,y:-37.75,alpha:0},15).wait(39));

	// Слой_1___копия
	this.instance_3 = new lib.wsmoke("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(10.7,-30.4,0.9415,0.9415,0,0,0,36.2,29.2);
	this.instance_3.alpha = 0.2305;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:36.5,regY:29.4,scaleX:0.8244,scaleY:0.8244,x:7.7,y:-37.75,alpha:0},5).wait(49));

	// Слой_1___копия___копия___копия
	this.instance_4 = new lib.wsmoke("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(36.5,29.45,0.7177,0.7177,0,0,0,36.5,29.4);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(51).to({_off:false},0).wait(3));

	// Слой_1___копия___копия
	this.instance_5 = new lib.wsmoke("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(36.5,29.45,0.7177,0.7177,0,0,0,36.5,29.4);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(41).to({_off:false},0).to({regX:36.4,scaleX:1.0132,scaleY:1.0132,x:28.7,y:12.05,alpha:0.4883},8).to({scaleX:1.161,scaleY:1.161,x:24.85,y:3.3,alpha:0.7305},4).wait(1));

	// Слой_1___копия___копия
	this.instance_6 = new lib.wsmoke("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(36.5,29.45,0.7177,0.7177,0,0,0,36.5,29.4);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(33).to({_off:false},0).to({regX:36.3,regY:29.2,scaleX:1.3223,scaleY:1.3223,x:20.65,y:-6.35,alpha:1},15).to({regX:36.2,scaleX:1.2051,scaleY:1.2051,x:17.55,y:-13.7,alpha:0.7695},5).wait(1));

	// Слой_1___копия
	this.instance_7 = new lib.wsmoke("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(36.5,29.45,0.7177,0.7177,0,0,0,36.5,29.4);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(26).to({_off:false},0).to({regX:36.3,regY:29.2,scaleX:1.3223,scaleY:1.3223,x:20.65,y:-6.35,alpha:1},13).to({regX:36.2,scaleX:0.9415,scaleY:0.9415,x:10.7,y:-30.4,alpha:0.2305},14).wait(1));

	// Слой_1___копия___копия
	this.instance_8 = new lib.wsmoke("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(36.5,29.45,0.7177,0.7177,0,0,0,36.5,29.4);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(21).to({_off:false},0).to({regX:36.4,scaleX:1.1207,scaleY:1.1207,x:25.9,y:5.65,alpha:1},8).to({regX:36.3,regY:29.2,scaleX:1.1465,scaleY:1.1465,x:16.1,y:-17.4},9).to({regX:36.5,regY:29.4,scaleX:0.8244,scaleY:0.8244,x:7.7,y:-37.75,alpha:0},10).wait(6));

	// Слой_1___копия
	this.instance_9 = new lib.wsmoke("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(36.5,29.45,0.7177,0.7177,0,0,0,36.5,29.4);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(14).to({_off:false},0).to({scaleX:0.9192,scaleY:0.9192,x:31.3,y:17.55,alpha:0.3281},4).to({regX:36.3,regY:29.2,scaleX:1.3223,scaleY:1.3223,x:20.65,y:-6.35,alpha:1},8).to({regX:36.5,regY:29.4,scaleX:0.8244,scaleY:0.8244,x:7.7,y:-37.75,alpha:0},15).wait(13));

	// Слой_1___копия
	this.instance_10 = new lib.wsmoke("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(36.5,29.45,0.7177,0.7177,0,0,0,36.5,29.4);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(8).to({_off:false},0).to({regX:36.3,regY:29.2,scaleX:1.3223,scaleY:1.3223,x:20.65,y:-6.35,alpha:1},13).to({regX:36.5,regY:29.4,scaleX:0.8244,scaleY:0.8244,x:7.7,y:-37.75,alpha:0},13).wait(20));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.3,-62,96.39999999999999,112.6);


(lib.Symbol15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.sssmoke("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(209.55,114.4,0.6318,1.0609,0,-80.8704,-78.2271,33.6,31.1);
	this.instance.alpha = 0.6484;

	this.instance_1 = new lib.sssmoke("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(339.6,116.15,0.2787,0.7489,0,-89.8249,-87.1789,34,30.9);
	this.instance_1.alpha = 0.8008;

	this.instance_2 = new lib.sssmoke("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(336.45,112.2,0.4414,1.406,0,-89.824,-87.1765,34,30.9);
	this.instance_2.alpha = 0.8008;

	this.instance_3 = new lib.sssmoke("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(350.25,118.6,0.9728,0.8342,0,-41.9185,-40.0605,36.1,30.4);
	this.instance_3.alpha = 0.8008;

	this.instance_4 = new lib.sssmoke("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(168.8,117.5,1.5144,1.2986,0,-42.3432,-40.4846,36.1,30.4);
	this.instance_4.alpha = 0.25;

	this.instance_5 = new lib.sssmoke("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(209.25,94.6,0.9024,0.7738,0,-72.3425,-70.4826,36.2,30.4);
	this.instance_5.alpha = 0.6992;

	this.instance_6 = new lib.sssmoke("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(197.6,123.65,0.3985,0.7738,0,-80.3774,-78.521,36,30.4);
	this.instance_6.alpha = 0.8008;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(154));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(20.6,12.7,360.59999999999997,169.5);


(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.sssmoke("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(153.4,99.1,0.5754,1.0201,0,-68.9094,-67.0546,35.6,30.9);
	this.instance.alpha = 0.3203;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(145));

	// Layer_1
	this.instance_1 = new lib.car_three();
	this.instance_1.parent = this;
	this.instance_1.setTransform(8,18,0.8585,0.8585);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(145));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(8,18,202.6,115.1);


(lib.Symbol11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.sssmoke("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(111.7,148.6,0.3305,0.5506,0,-72.8761,-71.0214,35.9,30.7);
	this.instance.alpha = 0.3984;

	this.instance_1 = new lib.sssmoke("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(183.5,145,0.4448,0.741,0,-72.8751,-71.0194,36,30.7);
	this.instance_1.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(155));

	// Layer_1
	this.instance_2 = new lib.Symbol16("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(150.5,93,1,1,0,0,0,150.5,93);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(155));

	// Layer_2_copy
	this.instance_3 = new lib.sssmoke("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(268.15,129.25,0.7858,1.2116,0,-57.8755,-56.0193,35.9,30.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(155));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,301,186);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_5
	this.instance = new lib.Symbol15("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(77.15,150.7,1,1,0,0,0,179.6,113.9);
	this.instance.alpha = 0.3984;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:77.2,alpha:0.8008,startPosition:13},13).to({regY:114,y:150.75,startPosition:22},9).to({regY:113.9,skewY:-0.1915,x:77.15,y:150.7,startPosition:26,loop:false},4).wait(141));

	// Layer_4
	this.instance_1 = new lib.Symbol7("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(210.7,123.2,1.0025,1.0025,0,0,0,135.6,28.6);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(21).to({x:189.4,y:125,alpha:0.4102,startPosition:47,loop:false},0).to({alpha:1},21).wait(125));

	// Layer_2_copy
	this.instance_2 = new lib.Symbol2("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(72.3,95.9,0.3444,0.3444,0,0,0,70.1,65);
	this.instance_2.alpha = 0.5;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(13).to({_off:false},0).to({regX:70,regY:65.1,scaleX:0.6946,scaleY:0.6946,x:72.25,y:95.95,alpha:1},3).to({regY:65,scaleX:0.4534,scaleY:0.4534,x:72.3,y:95.85,alpha:0.3008},3).to({regY:65.1,scaleX:0.7076,scaleY:0.7076,y:95.95,alpha:0.8984},4).to({regX:70.1,regY:65,scaleX:0.6406,scaleY:0.6406,y:95.9,alpha:0.5},3).wait(141));

	// Layer_2
	this.instance_3 = new lib.Symbol2("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(72.3,95.95,0.4307,0.4307,0,0,0,70,65.2);
	this.instance_3.alpha = 0.5;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(13).to({_off:false},0).to({regY:65.1,scaleX:0.9469,scaleY:0.9469,y:96,alpha:1},4).to({regY:65,scaleX:0.6181,scaleY:0.6181,y:95.9,alpha:0.3008},5).to({scaleX:0.9646,scaleY:0.9646,x:72.25,alpha:0.8984},6).to({scaleX:0.8733,scaleY:0.8733,x:72.3,y:95.85,alpha:0.5},5).wait(5).to({startPosition:0},0).to({regY:65.1,scaleX:0.9469,scaleY:0.9469,y:96,alpha:1},4).to({regY:65,scaleX:0.6181,scaleY:0.6181,y:95.9,alpha:0.3008},5).to({scaleX:0.9646,scaleY:0.9646,x:72.25,alpha:0.8984},6).to({scaleX:0.8733,scaleY:0.8733,x:72.3,y:95.85,alpha:0.5},5).wait(6).to({startPosition:0},0).to({regY:65.1,scaleX:0.9469,scaleY:0.9469,y:96,alpha:1},4).to({regY:65,scaleX:0.6181,scaleY:0.6181,y:95.9,alpha:0.3008},5).to({scaleX:0.9646,scaleY:0.9646,x:72.25,alpha:0.8984},6).to({scaleX:0.8733,scaleY:0.8733,x:72.3,y:95.85,alpha:0.5},5).wait(83));

	// Layer_1
	this.instance_4 = new lib.car_main_();
	this.instance_4.parent = this;
	this.instance_4.setTransform(21,30,0.797,0.797);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(167));

	// Layer_6
	this.instance_5 = new lib.sssmoke("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(260.8,106.05,1.1862,1.3301,0,-77.1212,-75.2641,36.1,30.5);

	this.instance_6 = new lib.sssmoke("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(122.15,132.45,1.4333,1.2291,0,-53.8096,-51.9508,36.1,30.4);

	this.instance_7 = new lib.sssmoke("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(89.85,136.25,1.4333,1.2291,0,-53.8096,-51.9508,36.1,30.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5}]}).wait(167));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-81.8,30,440.3,189.2);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol12("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-455.15,174.05,0.8619,0.8619,0,0,0,133.9,91.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({regX:134,scaleX:1,scaleY:1,x:134,y:95.9},66,cjs.Ease.quadOut).to({y:97.35,startPosition:36},36).to({y:98.5,startPosition:0},29).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-563.6,0,774.2,206.8);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol11("synched",24,false);
	this.instance.parent = this;
	this.instance.setTransform(-292.5,150.8,0.7075,0.7075,0,0,0,150.5,93);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(17).to({_off:false},0).to({scaleX:1,scaleY:1,x:184.9,y:84.45,startPosition:56},41,cjs.Ease.quadOut).wait(1).to({regX:151.6,x:185.95,y:84.5,startPosition:57},0).wait(1).to({startPosition:58},0).wait(1).to({startPosition:59},0).wait(1).to({startPosition:60},0).wait(1).to({startPosition:61},0).wait(1).to({y:84.55,startPosition:62},0).wait(1).to({startPosition:63},0).wait(1).to({startPosition:64},0).wait(1).to({y:84.6,startPosition:65},0).wait(1).to({startPosition:66},0).wait(1).to({x:185.9,startPosition:67},0).wait(1).to({y:84.65,startPosition:68},0).wait(1).to({startPosition:69},0).wait(1).to({startPosition:70},0).wait(1).to({y:84.7,startPosition:71},0).wait(1).to({startPosition:72},0).wait(1).to({x:185.85,y:84.75,startPosition:73},0).wait(1).to({startPosition:74},0).wait(1).to({y:84.8,startPosition:75},0).wait(1).to({startPosition:76},0).wait(1).to({x:185.8,y:84.85,startPosition:77},0).wait(1).to({y:84.9,startPosition:78},0).wait(1).to({startPosition:79},0).wait(1).to({y:84.95,startPosition:80},0).wait(1).to({x:185.75,startPosition:81},0).wait(1).to({y:85,startPosition:82},0).wait(1).to({y:85.05,startPosition:83},0).wait(1).to({x:185.7,y:85.1,startPosition:84},0).wait(1).to({startPosition:85},0).wait(1).to({y:85.15,startPosition:86},0).wait(1).to({x:185.65,y:85.2,startPosition:87},0).wait(1).to({y:85.25,startPosition:88},0).wait(1).to({y:85.3,startPosition:89},0).wait(1).to({x:185.6,y:85.35,startPosition:90},0).wait(1).to({startPosition:91},0).wait(1).to({y:85.4,startPosition:92},0).wait(1).to({x:185.55,y:85.45,startPosition:93},0).wait(1).to({y:85.5,startPosition:94},0).wait(1).to({x:185.5,y:85.55,startPosition:95},0).wait(1).to({y:85.6,startPosition:96},0).wait(1).to({regX:150.5,x:184.4,y:85.65,startPosition:97},0).wait(1).to({regX:151.6,x:185.45,y:85.7,startPosition:98},0).wait(1).to({y:85.75,startPosition:99},0).wait(1).to({x:185.4,y:85.8,startPosition:100},0).wait(1).to({regX:150.5,x:184.3,y:85.85,startPosition:101},0).wait(1).to({regX:151.6,x:185.35,y:85.95,startPosition:102},0).wait(1).to({y:86,startPosition:103},0).wait(1).to({x:185.3,y:86.05,startPosition:104},0).wait(1).to({y:86.1,startPosition:105},0).wait(1).to({x:185.25,y:86.2,startPosition:106},0).wait(1).to({y:86.25,startPosition:107},0).wait(1).to({x:185.2,y:86.35,startPosition:108},0).wait(1).to({y:86.4,startPosition:109},0).wait(1).to({x:185.15,y:86.45,startPosition:110},0).wait(1).to({x:185.1,y:86.55,startPosition:111},0).wait(1).to({y:86.6,startPosition:112},0).wait(1).to({x:185.05,y:86.7,startPosition:113},0).wait(1).to({y:86.75,startPosition:114},0).wait(1).to({x:185,y:86.85,startPosition:115},0).wait(1).to({regX:150.5,x:183.9,y:86.9,startPosition:116},0).wait(1).to({regX:151.6,x:184.95,y:87,startPosition:117},0).wait(1).to({x:184.9,y:87.1,startPosition:118},0).wait(1).to({y:87.15,startPosition:119},0).wait(1).to({x:184.85,y:87.25,startPosition:120},0).wait(1).to({x:184.8,y:87.35,startPosition:121},0).wait(1).to({regX:150.5,x:183.7,y:87.4,startPosition:105},0).wait(1).to({regX:151.6,x:184.85,y:87.45,startPosition:106},0).wait(1).to({x:184.9,y:87.5,startPosition:107},0).wait(1).to({x:184.95,y:87.6,startPosition:108},0).wait(1).to({x:185,y:87.65,startPosition:109},0).wait(1).to({x:185.05,y:87.7,startPosition:110},0).wait(1).to({x:185.1,y:87.75,startPosition:111},0).wait(1).to({x:185.2,y:87.8,startPosition:112},0).wait(1).to({x:185.25,y:87.85,startPosition:113},0).wait(1).to({x:185.3,y:87.9,startPosition:114},0).wait(1).to({x:185.35,y:87.95,startPosition:115},0).wait(1).to({x:185.45,y:88,startPosition:116},0).wait(1).to({x:185.5,y:88.1,startPosition:117},0).wait(1).to({x:185.55,y:88.15,startPosition:118},0).wait(1).to({x:185.6,y:88.2,startPosition:119},0).wait(1).to({x:185.7,y:88.25,startPosition:120},0).wait(1).to({x:185.75,y:88.3,startPosition:121},0).wait(1).to({x:185.8,y:88.35,startPosition:122},0).wait(1).to({x:185.9,y:88.45,startPosition:123},0).wait(1).to({x:185.95,y:88.5,startPosition:124},0).wait(1).to({x:186,y:88.55,startPosition:125},0).wait(1).to({x:186.1,y:88.6,startPosition:126},0).wait(1).to({x:186.15,y:88.65,startPosition:127},0).wait(1).to({x:186.2,y:88.7,startPosition:128},0).wait(1).to({x:186.25,y:88.75,startPosition:129},0).wait(1).to({x:186.35,y:88.85,startPosition:130},0).wait(1).to({x:186.4,y:88.9,startPosition:131},0).wait(1).to({x:186.45,y:88.95,startPosition:132},0).wait(1).to({x:186.5,y:89,startPosition:133},0).wait(1).to({x:186.55,y:89.05,startPosition:134},0).wait(1).to({x:186.6,y:89.1,startPosition:135},0).wait(1).to({x:186.7,y:89.15,startPosition:136},0).wait(1).to({x:186.75,y:89.2,startPosition:137},0).wait(1).to({x:186.8,y:89.25,startPosition:138},0).wait(1).to({x:186.85,y:89.3,startPosition:139},0).wait(1).to({x:186.9,y:89.35,startPosition:140},0).wait(1).to({x:186.95,y:89.4,startPosition:141},0).wait(1).to({x:187,startPosition:142},0).wait(1).to({x:187.05,y:89.45,startPosition:143},0).wait(1).to({x:187.1,y:89.5,startPosition:144},0).wait(1).to({y:89.55,startPosition:145},0).wait(1).to({x:187.15,y:89.6,startPosition:146},0).wait(1).to({x:187.2,y:89.65,startPosition:147},0).wait(1).to({x:187.25,startPosition:148},0).wait(1).to({x:187.3,y:89.7,startPosition:149},0).wait(1).to({y:89.75,startPosition:150},0).wait(1).to({x:187.35,startPosition:151},0).wait(1).to({x:187.4,y:89.8,startPosition:152},0).wait(1).to({x:187.45,y:89.85,startPosition:153},0).wait(1).to({startPosition:154},0).wait(1).to({x:187.5,y:89.9,startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({x:187.55,y:89.95,startPosition:2},0).wait(1).to({x:187.6,startPosition:3},0).wait(1).to({y:90,startPosition:4},0).wait(1).to({x:187.65,startPosition:5},0).wait(1).to({y:90.05,startPosition:6},0).wait(1).to({x:187.7,startPosition:7},0).wait(1).to({startPosition:8},0).wait(1).to({y:90.1,startPosition:9},0).wait(1).to({x:187.75,startPosition:10},0).wait(1).to({y:90.15,startPosition:11},0).wait(1).to({x:187.8,startPosition:12},0).wait(1).to({startPosition:13},0).wait(1).to({startPosition:14},0).wait(1).to({y:90.2,startPosition:15},0).wait(1).to({x:187.85,startPosition:16},0).wait(1).to({startPosition:17},0).wait(1).to({startPosition:18},0).wait(1).to({y:90.25,startPosition:19},0).wait(1).to({x:187.9,startPosition:20},0).wait(1).to({startPosition:21},0).wait(1).to({startPosition:22},0).wait(1).to({startPosition:23},0).wait(1).to({startPosition:24},0).wait(1).to({startPosition:25},0).wait(1).to({startPosition:26},0).wait(1).to({regX:150.5,x:186.85,startPosition:144},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-399,-8.5,736.4,225.1);


(lib.Symbol14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol9("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(191.4,108.2,1,1,0,0,0,179.6,96);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).wait(1).to({regX:135.4,regY:132.4,scaleX:1.0109,scaleY:1.0109,x:147.3,y:145.15,startPosition:1},0).wait(1).to({scaleX:1.0218,scaleY:1.0218,x:147.45,y:145.7,startPosition:2},0).wait(1).to({scaleX:1.0327,scaleY:1.0327,x:147.6,y:146.25,startPosition:3},0).wait(1).to({scaleX:1.0436,scaleY:1.0436,x:147.75,y:146.8,startPosition:4},0).wait(1).to({scaleX:1.0545,scaleY:1.0545,x:147.9,y:147.35,startPosition:5},0).wait(1).to({scaleX:1.0655,scaleY:1.0655,x:148,y:147.9,startPosition:6},0).wait(1).to({scaleX:1.0764,scaleY:1.0764,x:148.15,y:148.45,startPosition:7},0).wait(1).to({scaleX:1.0874,scaleY:1.0874,x:148.35,y:149.05,startPosition:8},0).wait(1).to({scaleX:1.0983,scaleY:1.0983,x:148.5,y:149.6,startPosition:9},0).wait(1).to({scaleX:1.1093,scaleY:1.1093,x:148.65,y:150.15,startPosition:10},0).wait(1).to({scaleX:1.1203,scaleY:1.1203,x:148.8,y:150.75,startPosition:11},0).wait(1).to({scaleX:1.1313,scaleY:1.1313,x:148.95,y:151.3,startPosition:12},0).wait(1).to({scaleX:1.1423,scaleY:1.1423,x:149.05,y:151.85,startPosition:13},0).wait(1).to({scaleX:1.1533,scaleY:1.1533,x:149.2,y:152.45,startPosition:14},0).wait(1).to({scaleX:1.1644,scaleY:1.1644,x:149.35,y:153,startPosition:15},0).wait(1).to({scaleX:1.1754,scaleY:1.1754,x:149.5,y:153.6,startPosition:16},0).wait(1).to({scaleX:1.1864,scaleY:1.1864,x:149.65,y:154.2,startPosition:17},0).wait(1).to({scaleX:1.1975,scaleY:1.1975,x:149.8,y:154.75,startPosition:18},0).wait(1).to({scaleX:1.2086,scaleY:1.2086,x:149.95,y:155.3,startPosition:19},0).wait(1).to({scaleX:1.2196,scaleY:1.2196,x:150.1,y:155.9,startPosition:20},0).wait(1).to({scaleX:1.2307,scaleY:1.2307,x:150.25,y:156.45,startPosition:21},0).wait(1).to({scaleX:1.2418,scaleY:1.2418,x:150.4,y:157,startPosition:22},0).wait(1).to({scaleX:1.2529,scaleY:1.2529,x:150.55,y:157.6,startPosition:23},0).wait(1).to({scaleX:1.2639,scaleY:1.2639,x:150.65,y:158.15,startPosition:24},0).wait(1).to({scaleX:1.275,scaleY:1.275,x:150.8,y:158.7,startPosition:25},0).wait(1).to({scaleX:1.2861,scaleY:1.2861,x:150.95,y:159.3,startPosition:26},0).wait(1).to({scaleX:1.2972,scaleY:1.2972,x:151.1,y:159.85,startPosition:27},0).wait(1).to({scaleX:1.3083,scaleY:1.3083,x:151.25,y:160.4,startPosition:28},0).wait(1).to({regX:179.6,regY:96,scaleX:1.3195,scaleY:1.3195,x:209.65,y:112.9},0).wait(155));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135.3,0,580.9000000000001,275.5);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.Symbol14("synched",4,false);
	this.instance.parent = this;
	this.instance.setTransform(153.45,103.2,0.9095,1.117,3.5142,0,0,131.1,100.7);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({regX:130.9,scaleX:0.9971,scaleY:1.0711,rotation:3.5029,x:130.1,y:105.1,startPosition:43},39,cjs.Ease.quadOut).to({regX:130.8,regY:100.8,scaleX:0.9995,scaleY:1.0528,rotation:3.5034,x:154.45,y:113.9,startPosition:129},86).to({regY:100.7,scaleX:0.9996,scaleY:1.0529,rotation:3.5037,x:154.1,y:112.3,startPosition:155},26).to({rotation:3.503,x:154.05,y:112,startPosition:161},6).to({regY:100.8,scaleX:1,scaleY:1.0534,rotation:3.5164,x:153.95,y:111.55,startPosition:80},6).wait(76));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-137.9,0,586.7,292.7);


// stage content:
(lib._970x250 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});
        this.framer = function() {
		if(!this.loopsPlayed) {
		this.loopsPlayed = 0;
		}
		this.loopsPlayed++; console.log(this.loopsPlayed);
		
		if (this.loopsPlayed >= 3) {
		 this.stop();
		 stage.getChildAt(0).stop();
    for (var i = 0; i < stage.getChildAt(0).numChildren; i++){
        if(typeof stage.getChildAt(0).getChildAt(i).stop === 'function'){
            stage.getChildAt(0).getChildAt(i).stop();
            } 
		
		}} else {
		this.play();
		}
	}
	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(205).call(this.framer));
	

	// TEXT
	this.instance = new lib.Symbol27("synched",0,false);
	this.instance.parent = this;
	this.instance.setTransform(637.95,128.75,1.4,1.3987,0,0,0,107.2,28.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(240));

	// logo1
	this.instance_1 = new lib.Symbol24("synched",0,false);
	this.instance_1.parent = this;
	this.instance_1.setTransform(156.6,24.65,1.0588,1.0588,5.7205,0,0,0.6,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(240));

	// Layer_1
	this.instance_2 = new lib.p12("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(950.75,22.55,1.2184,1.2184,0,0,0,14.7,14.7);
	this.instance_2.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(240));

	// black
	this.instance_3 = new lib.Symbol8("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(383.05,86.45,1.0351,1.0351,0,0,0,245.3,245.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(63).to({startPosition:0},0).to({alpha:0},17).wait(137).to({startPosition:0},0).to({alpha:1},11).wait(12));

	// TEXT_copy
	this.instance_4 = new lib.Symbol27copy("synched",0,false);
	this.instance_4.parent = this;
	this.instance_4.setTransform(217,196.4,1.4383,1.4337,0,0,0,106.8,28.2);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(111).to({_off:false},0).wait(129));

	// btn
	this.instance_5 = new lib.Symbol23("synched",0,false);
	this.instance_5.parent = this;
	this.instance_5.setTransform(652.6,172.1,1.2973,1.2959);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(59).to({_off:false},0).wait(181));

	// logo
	this.instance_6 = new lib.Symbol19("synched",0,false);
	this.instance_6.parent = this;
	this.instance_6.setTransform(220.65,86.5,1.4504,1.4504,0,0,0,119.2,34.6);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(59).to({_off:false},0).wait(181));

	// car_main_png
	this.instance_7 = new lib.Symbol3("synched",0,false);
	this.instance_7.parent = this;
	this.instance_7.setTransform(772.9,93.95,0.7785,0.7785,0,0,0,210.2,113.2);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(59).to({_off:false},0).wait(181));

	// car_two_png
	this.instance_8 = new lib.Symbol5("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(372.6,145.75,0.9961,0.9961,0,0,0,150.6,93.6);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(59).to({_off:false},0).wait(181));

	// car_three_png
	this.instance_9 = new lib.Symbol6("synched",0,false);
	this.instance_9.parent = this;
	this.instance_9.setTransform(545.3,158,0.9503,0.9503,0,0,0,134.9,92.5);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(59).to({_off:false},0).wait(181));

	// boom
	this.instance_10 = new lib.Symbol17("synched",0,false);
	this.instance_10.parent = this;
	this.instance_10.setTransform(538.1,112.15,1.1171,1.1171,0,0,0,61.2,63.4);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(59).to({_off:false},0).wait(181));

	// smoke_png
	this.instance_11 = new lib.Symbol10("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(580.5,255.7,0.6387,1.0834,0,0,0,189.3,83.4);
	this.instance_11.alpha = 0.25;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(59).to({_off:false},0).to({regX:189.2,regY:83.2,x:509.75,y:181.65,startPosition:42},84).wait(97));

	// bg
	this.instance_12 = new lib.Symbol1("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(383.55,118,0.7255,0.7255,0,0,0,289.5,350.3);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(59).to({_off:false},0).wait(1).to({regX:556.7,regY:254,scaleX:0.7234,scaleY:0.7234,x:574.9,y:48.7},0).wait(1).to({scaleX:0.7212,scaleY:0.7212,x:572.4,y:49.2},0).wait(1).to({scaleX:0.7191,scaleY:0.7191,x:569.85,y:49.7},0).wait(1).to({scaleX:0.7169,scaleY:0.7169,x:567.35,y:50.25},0).wait(1).to({scaleX:0.7147,scaleY:0.7147,x:564.85,y:50.75},0).wait(1).to({scaleX:0.7126,scaleY:0.7126,x:562.3,y:51.3},0).wait(1).to({scaleX:0.7104,scaleY:0.7104,x:559.75,y:51.85},0).wait(1).to({scaleX:0.7082,scaleY:0.7082,x:557.25,y:52.35},0).wait(1).to({scaleX:0.7061,scaleY:0.7061,x:554.7,y:52.9},0).wait(1).to({scaleX:0.7039,scaleY:0.7039,x:552.2,y:53.4},0).wait(1).to({scaleX:0.7017,scaleY:0.7017,x:549.7,y:53.95},0).wait(1).to({scaleX:0.6996,scaleY:0.6996,x:547.2,y:54.45},0).wait(1).to({scaleX:0.6975,scaleY:0.6975,x:544.75,y:54.95},0).wait(1).to({scaleX:0.6954,scaleY:0.6954,x:542.3,y:55.45},0).wait(1).to({scaleX:0.6933,scaleY:0.6933,x:539.85,y:56},0).wait(1).to({scaleX:0.6912,scaleY:0.6912,x:537.45,y:56.45},0).wait(1).to({scaleX:0.6891,scaleY:0.6891,x:535.05,y:57},0).wait(1).to({scaleX:0.6871,scaleY:0.6871,x:532.7,y:57.5},0).wait(1).to({scaleX:0.6851,scaleY:0.6851,x:530.35,y:57.95},0).wait(1).to({scaleX:0.6832,scaleY:0.6832,x:528.05,y:58.4},0).wait(1).to({scaleX:0.6812,scaleY:0.6812,x:525.8,y:58.9},0).wait(1).to({scaleX:0.6793,scaleY:0.6793,x:523.6,y:59.4},0).wait(1).to({scaleX:0.6774,scaleY:0.6774,x:521.4,y:59.8},0).wait(1).to({scaleX:0.6756,scaleY:0.6756,x:519.25,y:60.3},0).wait(1).to({scaleX:0.6738,scaleY:0.6738,x:517.15,y:60.75},0).wait(1).to({scaleX:0.672,scaleY:0.672,x:515.1,y:61.15},0).wait(1).to({scaleX:0.6702,scaleY:0.6702,x:513.05,y:61.6},0).wait(1).to({scaleX:0.6685,scaleY:0.6685,x:511.05,y:62},0).wait(1).to({scaleX:0.6669,scaleY:0.6669,x:509.15,y:62.4},0).wait(1).to({scaleX:0.6652,scaleY:0.6652,x:507.25,y:62.75},0).wait(1).to({scaleX:0.6636,scaleY:0.6636,x:505.35,y:63.15},0).wait(1).to({scaleX:0.6621,scaleY:0.6621,x:503.55,y:63.55},0).wait(1).to({scaleX:0.6605,scaleY:0.6605,x:501.75,y:63.95},0).wait(1).to({scaleX:0.6591,scaleY:0.6591,x:500.05,y:64.3},0).wait(1).to({scaleX:0.6576,scaleY:0.6576,x:498.35,y:64.65},0).wait(1).to({scaleX:0.6562,scaleY:0.6562,x:496.7,y:64.95},0).wait(1).to({scaleX:0.6548,scaleY:0.6548,x:495.1,y:65.3},0).wait(1).to({regX:289.6,regY:350.2,scaleX:0.6535,scaleY:0.6535,x:319,y:128.55},0).wait(1).to({regX:556.7,regY:254,x:493.05,y:65.7},0).wait(1).to({x:492.55},0).wait(1).to({x:492.1},0).wait(1).to({x:491.6},0).wait(1).to({x:491.15,y:65.65},0).wait(1).to({x:490.7},0).wait(1).to({x:490.2},0).wait(1).to({x:489.75},0).wait(1).to({x:489.3},0).wait(1).to({x:488.85,y:65.6},0).wait(1).to({x:488.4},0).wait(1).to({x:487.95},0).wait(1).to({x:487.5},0).wait(1).to({x:487.05,y:65.55},0).wait(1).to({x:486.6},0).wait(1).to({x:486.15},0).wait(1).to({x:485.75},0).wait(1).to({x:485.3},0).wait(1).to({x:484.85,y:65.5},0).wait(1).to({x:484.45},0).wait(1).to({x:484},0).wait(1).to({x:483.6},0).wait(1).to({x:483.2},0).wait(1).to({x:482.75,y:65.45},0).wait(1).to({x:482.35},0).wait(1).to({x:481.95},0).wait(1).to({x:481.55},0).wait(1).to({x:481.1},0).wait(1).to({x:480.7,y:65.4},0).wait(1).to({x:480.3},0).wait(1).to({x:479.9},0).wait(1).to({x:479.55},0).wait(1).to({x:479.15},0).wait(1).to({x:478.75},0).wait(1).to({x:478.35,y:65.35},0).wait(1).to({x:478},0).wait(1).to({x:477.6},0).wait(1).to({x:477.2},0).wait(1).to({x:476.85},0).wait(1).to({x:476.45,y:65.3},0).wait(1).to({x:476.1},0).wait(1).to({x:475.75},0).wait(1).to({x:475.35},0).wait(1).to({x:475},0).wait(1).to({x:474.65},0).wait(1).to({x:474.3,y:65.25},0).wait(1).to({x:473.95},0).wait(1).to({x:473.55},0).wait(1).to({x:473.2},0).wait(1).to({x:472.9},0).wait(1).to({x:472.55},0).wait(1).to({x:472.2,y:65.2},0).wait(1).to({x:471.85},0).wait(1).to({x:471.5},0).wait(1).to({x:471.15},0).wait(1).to({x:470.85},0).wait(1).to({x:470.5},0).wait(1).to({x:470.2},0).wait(1).to({x:469.85,y:65.15},0).wait(1).to({x:469.55},0).wait(1).to({x:469.2},0).wait(1).to({x:468.9},0).wait(1).to({x:468.55},0).wait(1).to({x:468.25},0).wait(1).to({x:467.95,y:65.1},0).wait(1).to({x:467.65},0).wait(1).to({x:467.35},0).wait(1).to({x:467},0).wait(1).to({x:466.7},0).wait(1).to({x:466.4},0).wait(1).to({x:466.1},0).wait(1).to({x:465.85,y:65.05},0).wait(1).to({x:465.55},0).wait(1).to({x:465.25},0).wait(1).to({x:464.95},0).wait(1).to({x:464.65},0).wait(1).to({x:464.4},0).wait(1).to({x:464.1},0).wait(1).to({x:463.8},0).wait(1).to({x:463.55,y:65},0).wait(1).to({x:463.25},0).wait(1).to({x:463},0).wait(1).to({x:462.7},0).wait(1).to({x:462.45},0).wait(1).to({x:462.2},0).wait(1).to({x:461.9},0).wait(1).to({x:461.65},0).wait(1).to({x:461.4,y:64.95},0).wait(1).to({x:461.15},0).wait(1).to({x:460.85},0).wait(1).to({x:460.6},0).wait(1).to({x:460.35},0).wait(1).to({x:460.1},0).wait(1).to({x:459.85},0).wait(1).to({x:459.6},0).wait(1).to({x:459.35,y:64.9},0).wait(1).to({x:459.1},0).wait(1).to({x:458.9},0).wait(1).to({x:458.65},0).wait(1).to({x:458.4},0).wait(1).to({x:458.15},0).wait(1).to({x:457.95},0).wait(1).to({x:457.7},0).wait(1).to({x:457.5},0).wait(1).to({x:457.25,y:64.85},0).wait(1).to({x:457},0).wait(1).to({x:456.8},0).wait(1).to({x:456.6},0).wait(1).to({x:456.35},0).wait(1).to({x:456.15},0).wait(1).to({x:455.9},0).wait(1).to({x:455.7},0).wait(1).to({x:455.5},0).wait(1).to({x:455.3},0).wait(1).to({x:455.1,y:64.8},0).wait(1).to({x:454.85},0).wait(1).to({x:454.65},0).wait(1).to({x:454.45},0).wait(1).to({x:454.25},0).wait(1).to({x:454.05},0).wait(1).to({x:453.85},0).wait(1).to({x:453.65},0).wait(1).to({x:453.45},0).wait(1).to({x:453.3},0).wait(1).to({x:453.1},0).wait(1).to({x:452.9,y:64.75},0).wait(1).to({x:452.7},0).wait(1).to({x:452.5},0).wait(1).to({x:452.35},0).wait(1).to({x:452.15},0).wait(1).to({x:451.95},0).wait(1).to({x:451.8},0).wait(1).to({x:451.6},0).wait(1).to({x:451.45},0).wait(1).to({x:451.25},0).wait(1).to({x:451.1},0).wait(1).to({regX:289.6,regY:350.2,x:276.4,y:127.55},0).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(256.2,-392.7,899.2,803.4);
// library properties:
lib.properties = {
	id: 'A69A19220B8B444183CEAAE9B356C799',
	width: 970,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"index_atlas_P_.png", id:"index_atlas_P_"},
		{src:"index_atlas_NP_.jpg", id:"index_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['A69A19220B8B444183CEAAE9B356C799'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;