<?php
include('../more/connect.php');
if(!$loggedIn) {
	header("Location: /");
}
$RefreshRate = rand(0,100000);

include '../more/filter.php';
$PostID = trim($conn->real_escape_string($_GET['ForumID']));

if(!$PostID || !is_numeric($PostID)) {
    header("Location: /Forum/ShowForum?ForumID=1");
    die();
}else{
    $checkExists = $conn->query("SELECT * FROM `forums` WHERE `id`='$PostID'");
    $exists = mysqli_num_rows($checkExists);
    if($exists == 0) {
        header("Location: /404");
        die();
    }
}

$select = $conn->query("SELECT * FROM forums WHERE id='".$PostID."'");
$fetchuser = mysqli_fetch_object($select);


if ($fetchuser == 0) {
    header("Location: ../");
}

if($fetchuser->username !== $user->username) {
$updateviews = $conn->query("UPDATE `users` SET `profile_views` = `profile_views` + 1 WHERE username = '$fetchuser->username'");
}

$getUviews = $conn->query("SELECT `profile_views` FROM `users` WHERE username = '$fetchuser->username'");

while($row = mysqli_fetch_array($getUviews)) {
    $profileviews = $row['profile_views']; //$db-query("SELECT `profile_views` FROM `users` WHERE username='$fetch_user->username'");
}
?>
<?php require '../more/Default.php'; ?>
<?php require '../more/nav.php'; ?>
<link rel="stylesheet" href="/Forum/api/skins/default/style/default.css" type="text/css"/>
				<div id="Body">
			<table width="100%" cellspacing="0" cellpadding="0" border="0">
				<tr>
					<td>
						</td>
				</tr>
				<tr valign="bottom">
					<td>
						<table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0">
							<tr valign="top">
								<!-- left column -->
								<td>&nbsp; &nbsp; &nbsp;</td>
								<!-- center column -->
								<td id="ctl00_cphRoblox_CenterColumn" width="95%" class="CenterColumn">
									<br>
									<span id="ctl00_cphRoblox_Navigationmenu1">
<table width="100%" cellspacing="1" cellpadding="0">
	<tr>
		<td align="right" valign="middle">
			<a id="ctl00_cphRBXAcer_NavigationMenu2_ctl00_HomeMenu" class="menuTextLink" href="/Forum/Default"><img src="/Forum/api/skins/default/images/icon_mini_home.gif" border="0">Home &nbsp;</a>
			<a id="ctl00_cphRBXAcer_NavigationMenu2_ctl00_SearchMenu" class="menuTextLink" href="/Forum/Search"><img src="/Forum/api/skins/default/images/icon_mini_search.gif" border="0">Search &nbsp;</a>
		</td>
	</tr>
</table>
</span>
									<span id="ctl00_cphRoblox_ThreadView1">
<table cellpadding="0" width="100%">
	<tr>
		<td colspan="2" align="left"><span id="ctl00_cphRoblox_ThreadView1_ctl00_Whereami1" name="Whereami1">
<table cellpadding="0" cellspacing="0" width="100%">
<?php require '../api/getForumHome.php'; ?>
</table>
<span id="ctl00_cphRoblox_ThreadView1_ctl00_Whereami1_ctl00_MenuScript"></span></span></td>
	</tr>
	<tr>
		<td>
			&nbsp;
		</td>
	</tr>
	<tr>
		<td valign="bottom" align="left"><a id="ctl00_cphRoblox_ThreadView1_ctl00_NewThreadLinkTop" href="/Forum/AddTPost?PostID=<?php echo $PostID ; ?>"><img id="ctl00_cphRoblox_ThreadView1_ctl00_NewThreadImageTop" src="/images/forum/newtopic.gif" border="0"/></a></td>
		<td align="right"><span class="normalTextSmallBold">Search 
      this forum: </span>
			<input name="ctl00$cphRoblox$ThreadView1$ctl00$Search" type="text" id="ctl00_cphRoblox_ThreadView1_ctl00_Search"/>
			<input type="submit" name="ctl00$cphRoblox$ThreadView1$ctl00$SearchButton" value=" Go " id="ctl00_cphRoblox_ThreadView1_ctl00_SearchButton"/></td>
	</tr>
	<tr>
		<td valign="top" colspan="2"><table id="ctl00_cphRoblox_ThreadView1_ctl00_ThreadList" class="tableBorder" cellspacing="1" cellpadding="3" border="0" width="100%">
	<tr>
		<th class="tableHeaderText" align="left" colspan="2" height="25">&nbsp;Thread&nbsp;</th><th class="tableHeaderText" align="center" nowrap="nowrap">&nbsp;Started By&nbsp;</th><th class="tableHeaderText" align="center">&nbsp;Replies&nbsp;</th><th class="tableHeaderText" align="center">&nbsp;Views&nbsp;</th><th class="tableHeaderText" align="center" nowrap="nowrap">&nbsp;Last Post&nbsp;</th>
	</tr>
	
<?php
                    $resultsperpage = 15;
                    $check = mysqli_query($conn, "SELECT * FROM topics WHERE `permalink_parent` = '$PostID'");
                    $usercount = mysqli_num_rows($check);

                    $numberofpages = ceil($usercount/$resultsperpage);

                    if(!isset($_GET['page'])) {
                        $page = 1;
                    }else{
                        $page = $_GET['page'];
                    }

                    $thispagefirstresult = ($page-1)*$resultsperpage;

                    $check = mysqli_query($conn, "SELECT * FROM topics WHERE `permalink_parent` = '$PostID' LIMIT ".$thispagefirstresult.",".$resultsperpage);

                    while($row = mysqli_fetch_assoc($check)) {

    $idfor = $row['id'];
    $title = htmlspecialchars($row['title']);
    $content = htmlspecialchars($row['content']);
	$ownername = htmlspecialchars($row['ownername']);
	$authorid = htmlspecialchars($row['author']);

echo"<tr>
        <td class='forumRow' align='center' valign='middle' width='25'><img title='Popular post' src='/images/forum/topic_notread.gif' border='0'/></td><td class='forumRow' height='25'><a class='linkSmallBold' href='/Forum/ShowPost?PostID=$idfor'>$title</a></td><td class='forumRowHighlight' align='left' width='100'>&nbsp;<a class='linkSmall' href='/user/?id=$authorid'>$ownername</a></td><td class='forumRowHighlight' align='center' width='50'><span class='normalTextSmaller'>-</span></td><td class='forumRowHighlight' align='center' width='50'><span class='normalTextSmaller'>869</span></td><td class='forumRowHighlight' align='center' width='140' nowrap='nowrap'><span class='normalTextSmaller'><b>Pinned Post</b><br>by </span><a class='linkSmall' href='/user/?id=$authorid''>$ownername</a><a href='/user/?id=$authorid'><img border='0' src='/Forum/api/skins/default/images/icon_mini_topic.gif'></a></td>
    </tr>";

    $_GET['username'] = $username;
                    }


                        echo "<tr>
	<td class='forumHeaderBackgroundAlternate' colspan='6'>&nbsp;</td>
</tr>
</table><span id='ctl00_cphRoblox_ThreadView1_ctl00_Pager'><table cellspacing='0' cellpadding='0' border='0' width='100%'>
<tr>
	<td><span class='normalTextSmallBold'>Page $page of $numberofpages</span></td><td align='right'><span><span class='normalTextSmallBold'>Goto to page: </span>
";
                    for ($page=1;$page<=$numberofpages;$page++) {

                        echo "<a id='ctl00_cphRoblox_ThreadView1_ctl00_Pager_Page0' class='normalTextSmallBold' href='/Forum/ShowForum?ForumID=$PostID&page=$page'>$page</a> ";
                    }

                    echo "	<span class='normalTextSmallBold'></td>
</tr>
</table></span>";
                    ?>
</td>
	</tr>
	<tr>
		<td colspan="2">
			&nbsp;
		</td>
	</tr>
	<tr>
		<td align="left" valign="top">
			<span id="ctl00_cphRoblox_ThreadView1_ctl00_Whereami2" name="Whereami2">
<table cellpadding="0" cellspacing="0" width="100%">
<?php require '../api/getForumHome.php'; ?>
</table>
<span id="ctl00_cphRoblox_ThreadView1_ctl00_Whereami2_ctl00_MenuScript"></span></span>
		</td>
		<td align="right">
			<span class="normalTextSmallBold">Display threads for: </span><select name="ctl00$cphRoblox$ThreadView1$ctl00$DisplayByDays" id="ctl00_cphRoblox_ThreadView1_ctl00_DisplayByDays">
	<option selected="selected" value="0">All Days</option>
	<option value="1">Today</option>
	<option value="3">Past 3 Days</option>
	<option value="7">Past Week</option>
	<option value="14">Past 2 Weeks</option>
	<option value="30">Past Month</option>
	<option value="90">Past 3 Months</option>
	<option value="180">Past 6 Months</option>
	<option value="360">Past Year</option>
</select>
			<br>
			<a id="ctl00_cphRoblox_ThreadView1_ctl00_MarkAllRead" class="linkSmallBold" href="javascript:__doPostBack('ctl00$cphRoblox$ThreadView1$ctl00$MarkAllRead','')">Mark all threads as read</a>
			<br>
			<span class="normalTextSmallBold">
			</span>
		</td>
	</tr>
	<tr>
		<td colspan="2">&nbsp;
		</td>
	</tr>
</table>
</span>
								</td>
								<td class="CenterColumn">&nbsp;&nbsp;&nbsp;</td>
								<!-- right margin -->
								<td class="RightColumn">&nbsp;&nbsp;&nbsp;</td>
							</tr>
						</table>
					</td>
				</tr>
				</table>
				</div>
<?php require '../more/footer.php'; ?>
</body>
</html>