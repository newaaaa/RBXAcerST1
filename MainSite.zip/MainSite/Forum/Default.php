<?php
include('../more/connect.php');
if(!$loggedIn) {
	header("Location: /");
}
?>
<?php require '../more/Default.php'; ?>
<?php require '../more/nav.php'; ?>
<link rel="stylesheet" href="/Forum/api/skins/default/style/default.css" type="text/css"/>
				<div id="Body">
			<table width="100%" cellspacing="0" cellpadding="0" border="0">
				<tr>
					<td>
					</td>
				</tr>
				<tr valign="bottom">
					<td>
						<table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0">
							<tr valign="top">
								<!-- left column -->
								<td class="LeftColumn">&nbsp;&nbsp;&nbsp;</td>
								<td id="ctl00_cphRBXAcer_LeftColumn" nowrap="nowrap" width="180" class="LeftColumn">
									<p>
										<span id="ctl00_cphRBXAcer_SearchRedirect">
<table class="tableBorder" cellspacing="1" cellpadding="3" width="100%">
  <tr>
    <th class="tableHeaderText" align="left" colspan="2">
      &nbsp;Search RBXAcer Forums
    </th>
  </tr>
  <tr>
    <td class="forumRow" align="left" valign="top" colspan="2">
      <table cellspacing="1" border="0" cellpadding="2">
        <tr>
          <td>
            <input name="ctl00$cphRBXAcer$SearchRedirect$ctl00$SearchText" type="text" maxlength="50" id="ctl00_cphRBXAcer_SearchRedirect_ctl00_SearchText" size="10"/>
          </td>
          <td align="right" colspan="2">
            <input type="submit" name="ctl00$cphRBXAcer$SearchRedirect$ctl00$SearchButton" value="Search" id="ctl00_cphRBXAcer_SearchRedirect_ctl00_SearchButton"/>
          </td>
        </tr>
      </table>
      <span class="normalTextSmall">
      <br>
      <a href="Forum/Search/default.html">More search options</a>
      </span>
    </td>
  </tr>
</table>
</span>
</p>
								</td>
								<td class="LeftColumn">&nbsp;&nbsp;&nbsp;</td>
								<!-- center column -->
								<td class="CenterColumn">&nbsp;&nbsp;&nbsp;</td>
								<td id="ctl00_cphRBXAcer_CenterColumn" width="95%" class="CenterColumn">
									<span id="ctl00_cphRBXAcer_NavigationMenu2">
<table width="100%" cellspacing="1" cellpadding="0">
	<tr>
		<td align="right" valign="middle">
			<a id="ctl00_cphRBXAcer_NavigationMenu2_ctl00_HomeMenu" class="menuTextLink" href="/Forum/Default"><img src="/Forum/api/skins/default/images/icon_mini_home.gif" border="0">Home &nbsp;</a>
			<a id="ctl00_cphRBXAcer_NavigationMenu2_ctl00_SearchMenu" class="menuTextLink" href="/Forum/Search"><img src="/Forum/api/skins/default/images/icon_mini_search.gif" border="0">Search &nbsp;</a>
		</td>
	</tr>
</table>
</span>
									<br>
									<table cellpadding="0" cellspacing="2" width="100%">
										<tr>
											<td align="left">
												<?php echo"<span class='normalTextSmallBold'>Current time: </span><span class='normalTextSmall'>".$dateforum."</span>"; ?>
<?php
date_default_timezone_set('Europe/Brussels');
$dateforum = date('m/d/Y h:i:s a', time());
?>
											</td>
											<td align="right">
											</td>
										</tr>
									</table>
									<table cellpadding="2" cellspacing="1" border="0" width="100%" class="tableBorder"><tr>
	<th class="tableHeaderText" colspan="2" height="20">Forum</th><th class="tableHeaderText" width="50" nowrap="nowrap">&nbsp;&nbsp;Threads&nbsp;&nbsp;</th><th class="tableHeaderText" width="50" nowrap="nowrap">&nbsp;&nbsp;Posts&nbsp;&nbsp;</th><th class="tableHeaderText" width="135" nowrap="nowrap">&nbsp;Last Post&nbsp;</th>
</tr><tr id="ctl00_cphRBXAcer_ForumGroupRepeater1_ctl01_ForumGroup">
	<td class="forumHeaderBackgroundAlternate" colspan="5" height="20"><a id="ctl00_cphRBXAcer_ForumGroupRepeater1_ctl01_GroupTitle" class="forumTitle" href="/Forum/Default">RBXAcer</a></td>
</tr><tr>
	<td class="forumRow" align="center" valign="top" width="34" nowrap="nowrap"><img src="/Forum/api/skins/default/images/forum_status.gif" width="34" border="0"/></td><td class="forumRow" width="80%"><a class="forumTitle" href="/Forum/ShowForum?ForumID=1">General Discussion</a><span class="normalTextSmall"><br>This is the place for conversation about all things RBXAcer.  Posts not pertaining to RBXAcer will be mercilessly pruned by our crack squad of moderators.</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller">-</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller">-</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller"><span><b>Today @ 07:33 AM</b></span></span><br><span class="normalTextSmaller">by <a href="/user/?id=1">Admin</a><a href="/user/?id=1"><img border="0" src="/Forum/api/skins/default/images/icon_mini_topic.gif"></a></span></td>
</tr><tr>
	<td class="forumRow" align="center" valign="top" width="34" nowrap="nowrap"><img src="/Forum/api/skins/default/images/forum_status.gif" width="34" border="0"/></td><td class="forumRow" width="80%"><a class="forumTitle" href="/Forum/ShowForum?ForumID=2">Creations Gallery</a><span class="normalTextSmall"><br>Discuss your RBXAcer creations and share the secrets of your success.  Post requests for help building and scripting here.</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller">-</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller">-</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller"><span><b>Today @ 07:33 AM</b></span></span><br><span class="normalTextSmaller">by <a href="/user/?id=1">Admin</a><a href="/user/?id=1"><img border="0" src="/Forum/api/skins/default/images/icon_mini_topic.gif"></a></span></td>
</tr><tr>
	<td class="forumRow" align="center" valign="top" width="34" nowrap="nowrap"><img src="/Forum/api/skins/default/images/forum_status.gif" width="34" border="0"/></td><td class="forumRow" width="80%"><a class="forumTitle" href="/Forum/ShowForum?ForumID=3">Suggestions, Feedback, and Ideas</a><span class="normalTextSmall"><br>Do you have a suggestion for how to make RBXAcer better? Share your feedback here.</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller">-</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller">-</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller"><span><b>Today @ 07:33 AM</b></span></span><br><span class="normalTextSmaller">by <a href="/user/?id=1">Admin</a><a href="/user/?id=1"><img border="0" src="/Forum/api/skins/default/images/icon_mini_topic.gif"></a></span></td>
</tr><tr>
		<td class="forumRow" align="center" valign="top" width="34" nowrap="nowrap"><img src="/Forum/api/skins/default/images/forum_status.gif" width="34" border="0"/></td><td class="forumRow" width="80%"><a class="forumTitle" href="/Forum/ShowForum?ForumID=4">Off Topic</a><span class="normalTextSmall"><br>Feel like talking about stuff other than RBXAcer?  Post here.</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller">-</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller">-</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller"><span><b>Today @ 07:33 AM</b></span></span><br><span class="normalTextSmaller">by <a href="/user/?id=1">Admin</a><a href="/user/?id=1"><img border="0" src="/Forum/api/skins/default/images/icon_mini_topic.gif"></a></span></td>
</tr><tr><tr id="ctl00_cphRBXAcer_ForumGroupRepeater1_ctl02_ForumGroup">
	<td class="forumHeaderBackgroundAlternate" colspan="5" height="20"><a id="ctl00_cphRBXAcer_ForumGroupRepeater1_ctl02_GroupTitle" class="forumTitle" href="/Forum/Default">Help Center</a></td>
</tr><tr>
		<td class="forumRow" align="center" valign="top" width="34" nowrap="nowrap"><img src="/Forum/api/skins/default/images/forum_status.gif" width="34" border="0"/></td><td class="forumRow" width="80%"><a class="forumTitle" href="/Forum/ShowForum?ForumID=5">Building Help</a><span class="normalTextSmall"><br>Learn the ins and outs of building structures in RBXAcer here! Share your techniques with other builders, discuss designs, and draft plans.</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller">-</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller">-</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller"><span><b>Today @ 07:33 AM</b></span></span><br><span class="normalTextSmaller">by <a href="/user/?id=1">Admin</a><a href="/user/?id=1"><img border="0" src="/Forum/api/skins/default/images/icon_mini_topic.gif"></a></span></td>
</tr><tr>
		<td class="forumRow" align="center" valign="top" width="34" nowrap="nowrap"><img src="/Forum/api/skins/default/images/forum_status.gif" width="34" border="0"/></td><td class="forumRow" width="80%"><a class="forumTitle" href="/Forum/ShowForum?ForumID=6">Scripting Help</a><span class="normalTextSmall"><br>Need help with a script you are writing? Need to edit an existing script? Want to share your devious programming skills? For advanced RBXAcer users.</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller">-</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller">-</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller"><span><b>Today @ 07:33 AM</b></span></span><br><span class="normalTextSmaller">by <a href="/user/?id=1">Admin</a><a href="/user/?id=1"><img border="0" src="/Forum/api/skins/default/images/icon_mini_topic.gif"></a></span></td>
</tr><tr>
		<td class="forumRow" align="center" valign="top" width="34" nowrap="nowrap"><img src="/Forum/api/skins/default/images/forum_status.gif" width="34" border="0"/></td><td class="forumRow" width="80%"><a class="forumTitle" href="/Forum/ShowForum?ForumID=7">Technical Problems and Bug Reports</a><span class="normalTextSmall"><br>Are you having trouble installing or upgrading RBXAcer? Account troubles? Website problems? Have you found a bug? Post here!</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller">-</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller">-</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller"><span><b>Today @ 07:33 AM</b></span></span><br><span class="normalTextSmaller">by <a href="/user/?id=1">Admin</a><a href="/user/?id=1"><img border="0" src="/Forum/api/skins/default/images/icon_mini_topic.gif"></a></span></td>
</tr><tr><tr id="ctl00_cphRBXAcer_ForumGroupRepeater1_ctl03_ForumGroup">
	<td class="forumHeaderBackgroundAlternate" colspan="5" height="20"><a id="ctl00_cphRBXAcer_ForumGroupRepeater1_ctl03_GroupTitle" class="forumTitle" href="/Forum/Default">Fun</a></td>
</tr><tr>
		<td class="forumRow" align="center" valign="top" width="34" nowrap="nowrap"><img src="/Forum/api/skins/default/images/forum_status.gif" width="34" border="0"/></td><td class="forumRow" width="80%"><a class="forumTitle" href="/Forum/ShowForum?ForumID=8">Role-Playing</a><span class="normalTextSmall"><br>Does your RBXAcerian want to fly to the moon?  Command a ship?  Lay siege to a castle?  Start a role-playing thread here.</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller">-</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller">-</span></td><td class="forumRowHighlight" align="center"><span class="normalTextSmaller"><span><b>Today @ 07:33 AM</b></span></span><br><span class="normalTextSmaller">by <a href="/user/?id=1">Admin</a><a href="/user/?id=1"><img border="0" src="/Forum/api/skins/default/images/icon_mini_topic.gif"></a></span></td>
</tr>
</table>
									<p></p>
								</td>
								<td class="CenterColumn">&nbsp;&nbsp;&nbsp;</td>
								<!-- right margin -->
								<td class="RightColumn">&nbsp;&nbsp;&nbsp;</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
				</div>
<?php require '../more/footer.php'; ?>
</body>
</html>
