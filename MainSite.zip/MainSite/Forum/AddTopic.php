<?php
include('../more/connect.php');
if(!$loggedIn) {
	header("Location: /");
}
?>
<?php require '../more/Default.php'; ?>
<?php require '../more/nav.php'; ?>
<div id="body">
<br>
<center>
<h2>
<?php
$idpost = $_GET['PostID'];
$name = $user->username;
$title = stripslashes($_REQUEST['NameTopic']);
$userid = mysqli_real_escape_string($conn,$user->id); 
$content = stripslashes($_REQUEST['Content']);
$email = mysqli_real_escape_string($conn,$email);
$query = "INSERT into `topics` (title,content,author,permalink_parent,ownername)
VALUES ('$title', '$content', '$userid', '$idpost', '$name')";
        $result = mysqli_query($conn,$query);
        if($result){
            echo "Posted";
            header("Location: /Forum/AddTPost?ForumID=$idpost");
        }
?>
<center>
</h2>
</div>
<script>window.location.href="/Forum/ShowForum?ForumID=<?php echo $idpost ; ?>"</script>
<?php require '../more/footer.php'; ?>