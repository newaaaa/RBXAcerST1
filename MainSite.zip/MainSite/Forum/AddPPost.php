<?php
include('../more/connect.php');
if(!$loggedIn) {
	header("Location: /");
}
?>
<?php require '../more/Default.php'; ?>
<?php require '../more/nav.php'; ?>
<div id="body">
<br>
<center>
<h2>
<?php
$idpost = $_GET['PostID'];
$name = $user->username;
$userid = mysqli_real_escape_string($conn,$user->id);
$content = stripslashes($_REQUEST['Content']);
$email = mysqli_real_escape_string($conn,$email);
$query = "INSERT into `posts` (content,author,permalink_parent,ownername)
VALUES ('$content', '$userid', '$idpost', '$name')";
        $result = mysqli_query($conn,$query);
        if($result){
            echo "Posted<br>";
            echo "Made by Codex";
            header("Location: /Forum/ShowPost?PostID=$idpost");
        }
?>
<center>
</h2>
</div>
<script>window.location.href="/Forum/ShowPost?PostID=<?php echo $idpost ; ?>"</script>
<?php require '../more/footer.php'; ?>
