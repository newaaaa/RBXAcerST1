<?php
include('../more/connect.php');
if(!$loggedIn) {
	header("Location: /");
}
$RefreshRate = rand(0,100000);

include '../more/filter.php';
$PostID = trim($conn->real_escape_string($_GET['PostID']));

if(!$PostID || !is_numeric($PostID)) {
    header("Location: /Forum/ShowPost?PostID=1");
    die();
}else{
    $checkExists = $conn->query("SELECT * FROM `topics` WHERE `id`='$PostID'");
    $exists = mysqli_num_rows($checkExists);
    if($exists == 0) {
        header("Location: /404");
        die();
    }
}

$select = $conn->query("SELECT * FROM topics WHERE id='".$PostID."'");
$fetchuser = mysqli_fetch_object($select);


if ($fetchuser == 0) {
    header("Location: ../");
}

if($fetchuser->username !== $user->username) {
$updateviews = $conn->query("UPDATE `users` SET `profile_views` = `profile_views` + 1 WHERE username = '$fetchuser->username'");
}

$getUviews = $conn->query("SELECT `profile_views` FROM `users` WHERE username = '$fetchuser->username'");

while($row = mysqli_fetch_array($getUviews)) {
    $profileviews = $row['profile_views']; //$db-query("SELECT `profile_views` FROM `users` WHERE username='$fetch_user->username'");
}
?>
<?php require '../more/Default.php'; ?>
<?php require '../more/nav.php'; ?>
<link rel="stylesheet" href="/Forum/api/skins/default/style/default.css" type="text/css"/>
<div id="Body">
			<table width="100%" cellspacing="0" cellpadding="0" border="0">
				<tr>
					<td>
						</td>
				</tr>
				<tr valign="bottom">
					<td>
						<table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0">
							<tr valign="top">
								<!-- left column -->
								<td>&nbsp; &nbsp; &nbsp;</td>
								<!-- center column -->
								<td id="ctl00_cphRBXAcer_CenterColumn" width="95%" class="CenterColumn">
									<br>
									<span id="ctl00_cphRBXAcer_Navigationmenu1">
<table width="100%" cellspacing="1" cellpadding="0">
	<tr>
		<td align="right" valign="middle">
			<a id="ctl00_cphRBXAcer_NavigationMenu2_ctl00_HomeMenu" class="menuTextLink" href="/Forum/Default"><img src="/Forum/api/skins/default/images/icon_mini_home.gif" border="0">Home &nbsp;</a>
			<a id="ctl00_cphRBXAcer_NavigationMenu2_ctl00_SearchMenu" class="menuTextLink" href="/Forum/Search"><img src="/Forum/api/skins/default/images/icon_mini_search.gif" border="0">Search &nbsp;</a>
		</td>
	</tr>
</table>
</span>
									<span id="ctl00_cphRBXAcer_PostView1">
<table cellpadding="0" width="100%">
  <tr>
    <td align="left" colspan="2"><span id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1" name="Whereami1">
<table cellpadding="0" cellspacing="0" width="100%">
    <tr>
        <td valign="top" align="left" width="1px">
            <nobr>
            </nobr>
        </td>
        <td id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1_ctl00_ForumGroupMenu" class="popupMenuSink" valign="top" align="left" width="1px">
            <nobr>
                <a id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1_ctl00_LinkForumGroup" class="linkMenuSink" href="/Forum/Default">RBXAcer</a>
            </nobr>
        </td>
        <td id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1_ctl00_ForumMenu" class="popupMenuSink" valign="top" align="left" width="1px">
            <nobr>
                <span id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1_ctl00_ForumSeparator" class="normalTextSmallBold">&nbsp;&gt;</span>
                <a id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1_ctl00_LinkForum" class="linkMenuSink" href="/Forum/Default">General Discussion</a>
            </nobr>
        </td>
        <td id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1_ctl00_PostMenu" class="popupMenuSink" valign="top" align="left" width="1px">
            <nobr>
                <span id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1_ctl00_PostSeparator" class="normalTextSmallBold">&nbsp;&gt;</span>
                <a id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1_ctl00_LinkPost" class="linkMenuSink" href="/Forum/ShowPost?PostID=<?php echo $PostID ; ?>"><?php echo $fetchuser->title ; ?></a>
            </nobr>
        </td>
        <td valign="top" align="left" width="*">&nbsp;</td>
    </tr>
</table>
<span id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1_ctl00_MenuScript"></span></span></td>
  </tr>
  <tr>
    <td align="left" colspan="2">&nbsp;
    </td>
  </tr>
  <tr>
    <td valign="top" align="left">
	<span class="normalTextSmallBold"></span>
    </td>
    <td valign="bottom" align="right"><span class="normalTextSmallBold">Display using: </span><select name="ctl00$cphRBXAcer$PostView1$ctl00$DisplayMode" id="ctl00_cphRBXAcer_PostView1_ctl00_DisplayMode">
	<option selected="selected" value="Flat">Flat View</option>
	<option value="Threaded">Threaded View</option>
</select>&nbsp;<select name="ctl00$cphRBXAcer$PostView1$ctl00$SortOrder" id="ctl00_cphRBXAcer_PostView1_ctl00_SortOrder">
	<option selected="selected" value="0">Oldest to newest</option>
	<option value="1">Newest to oldest</option>
</select>
    </td>
  </tr>
  <tr>
    <td colspan="2"><table id="ctl00_cphRBXAcer_PostView1_ctl00_PostList" class="tableBorder" cellspacing="1" cellpadding="0" border="0" width="100%">
	<tr>
		<td class="forumHeaderBackgroundAlternate" colspan="2" height="20"><table cellspacing="0" cellpadding="0" border="0" width="100%">
			<tr>
				<td align="left"></td><td align="right"><a id="ctl00_cphRBXAcer_PostView1_ctl00_PostList_ctl00_PreviousThread" class="linkSmallBold" href="javascript:__doPostBack('ctl00$cphRBXAcer$PostView1$ctl00$PostList$ctl00$PreviousThread','')">Previous Thread</a>&nbsp;<span class="normalTextSmallBold">::</span>&nbsp;<a id="ctl00_cphRBXAcer_PostView1_ctl00_PostList_ctl00_NextThread" class="linkSmallBold" href="javascript:__doPostBack('ctl00$cphRBXAcer$PostView1$ctl00$PostList$ctl00$NextThread','')">Next Thread</a>&nbsp;</td>
			</tr>
		</table></td>
	</tr><tr>
		<th class="tableHeaderText" align="left" height="25" width="100">&nbsp;Author</th><th class="tableHeaderText" align="left" width="85%">&nbsp;Thread: <?php echo $fetchuser->title ; ?></th>
	</tr><tr>
		<td class="forumRow" valign="top" width="150" nowrap="nowrap"><table border="0">
			<tr>
				<td><img src="/Forum/api/skins/default/images/OnlineStatusIndicator_IsOffline.gif" alt="<?php echo $fetchuser->ownername ; ?> is not online." border="0"/>&nbsp;<a class="normalTextSmallBold" href="/user/?id=<?php echo $fetchuser->author ; ?>"><?php echo $fetchuser->ownername ; ?></a><br></td>
			</tr><tr>
				<td><a href="/user/?id=<?php echo $fetchuser->author ; ?>"><iframe height="80" width="70" src="/api/getAvatar.php?id=<?php echo $fetchuser->author ; ?>&amp;size=64" frameborder="0" scrolling="no"></iframe></a></td>
			</tr><tr>
				<td><span class="normalTextSmaller"><b>Developing:</b> Now</span></td>
			</tr>
				<td>&nbsp;</td>
			</tr>
		</table></td><td class="forumRow" valign="top"><table cellspacing="0" cellpadding="3" border="0" width="100%">
			<tr>
				<td class="forumRowHighlight"><span class="normalTextSmallBold"><?php echo htmlspecialchars($fetchuser->title) ; ?><a name="1635040"/></span><br><span class="normalTextSmaller"> Posted: </span><span class="normalTextSmaller"><?php echo $fetchuser->date ; ?></span></td>
			</tr><tr>
				<td colspan="2"><span class="normalTextSmall"><?php echo $fetchuser->content ; ?></td>
			</tr><tr>
				<td colspan="2"><span class="normalTextSmaller"></span></td>
			</tr><tr>
				<td height="2"></td>
			</tr><tr>
				<td colspan="2"><a href="/Forum/AddPost?PostID=<?php echo $PostID ; ?>"><img border="0" src="/Forum/api/skins/default/images/newpost.gif"></a><a href="/report/?id=3389&amp;type=1">Report Abuse</a></td>
			</tr>
		</table></td>
	</tr>
	
	<?php
                    $resultsperpage = 25;
                    $check = mysqli_query($conn, "SELECT * FROM posts WHERE `permalink_parent` = '$PostID'");
                    $usercount = mysqli_num_rows($check);

                    $numberofpages = ceil($usercount/$resultsperpage);

                    if(!isset($_GET['page'])) {
                        $page = 1;
                    }else{
                        $page = $_GET['page'];
                    }

                    $thispagefirstresult = ($page-1)*$resultsperpage;

                    $check = mysqli_query($conn, "SELECT * FROM posts WHERE `permalink_parent` = '$PostID' LIMIT ".$thispagefirstresult.",".$resultsperpage);

                    while($row = mysqli_fetch_assoc($check)) {

    $id = htmlspecialchars($row['id']);
    $content = htmlspecialchars($row['content']);
	$ownername = htmlspecialchars($row['ownername']);
	$date = htmlspecialchars($row['date']);
	$authorid = htmlspecialchars($row['author']);

echo"
<tr>
		<td class='forumRow' valign='top' width='150' nowrap='nowrap'><table border='0'>
			<tr>
				<td><img src='/Forum/api/skins/default/images/OnlineStatusIndicator_IsOffline.gif' alt='$ownername is not online.' border='0'/>&nbsp;<a class='normalTextSmallBold' href='/user/?id=$authorid'>$ownername</a><br></td>
			</tr><tr>
				<td><a href='/user/?id=$authorid'><iframe height='80' width='70' src='/api/getAvatar.php?id=$authorid&amp;size=64' frameborder='0' scrolling='no'></iframe></a></td>
			</tr><tr>
				<td><span class='normalTextSmaller'><b>Developing:</b> Now</span></td>
			</tr>
				<td>&nbsp;</td>
			</tr>
		</table></td><td class='forumRow' valign='top'><table cellspacing='0' cellpadding='3' border='0' width='100%'>
			<tr>
				<td class='forumRowHighlight'><span class='normalTextSmallBold'>Re: $fetchuser->title<a name='1635040'/></span><br><span class='normalTextSmaller'> Posted: </span><span class='normalTextSmaller'>$date</span></td>
			</tr><tr>
				<td colspan='2'><span class='normalTextSmall'>$content</td>
			</tr><tr>
				<td colspan='2'><span class='normalTextSmaller'></span></td>
			</tr><tr>
				<td height='2'></td>
			</tr><tr>
				<td colspan='2'><a href='/Forum/AddPost?PostID=$PostID'><img border='0' src='/Forum/api/skins/default/images/newpost.gif'></a><a>Report Abuse</a></td>
			</tr>
		</table></td>
	</tr>
";

    $_GET['username'] = $username;
                    }

if($numberofpages == 0) {
$pages = 1;
$fixone = 1;
}else{
$pages = $numberofpages;
}

echo "<tr>
	<td class='forumHeaderBackgroundAlternate' colspan='6'>&nbsp;</td>
</tr>
</table><span id='ctl00_cphRoblox_ThreadView1_ctl00_Pager'><table cellspacing='0' cellpadding='0' border='0' width='100%'>
<tr>
	<td><span class='normalTextSmallBold'>Page $page of $pages</span></td><td align='right'><span><span class='normalTextSmallBold'>Goto to page: </span>
";
                    for ($page=1;$page<=$numberofpages;$page++) {

                        echo "<a id='ctl00_cphRoblox_ThreadView1_ctl00_Pager_Page0' class='normalTextSmallBold' href='/Forum/ShowPost?PostID=$PostID&page=$page'>$page</a> ";
                    }
                    if($fixone == 1) {
                    echo"<a id='ctl00_cphRoblox_ThreadView1_ctl00_Pager_Page0' class='normalTextSmallBold' href='/Forum/ShowPost?PostID=$PostID&page=1'>1</a>";
                    }
                    echo "	<span class='normalTextSmallBold'></td>
</tr>
</table></span>";

                    ?>
                    </td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td align="left" colspan="2">
    </td>
  </tr>
  <tr>
    <td align="left" colspan="2">
      <span id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami2" name="Whereami2">
<table cellpadding="0" cellspacing="0" width="100%">
    <tr>
        <td valign="top" align="left" width="1px">
            <nobr>
            </nobr>
        </td>
        <td id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1_ctl00_ForumGroupMenu" class="popupMenuSink" valign="top" align="left" width="1px">
            <nobr>
                <a id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1_ctl00_LinkForumGroup" class="linkMenuSink" href="/Forum/Default">RBXAcer</a>
            </nobr>
        </td>
        <td id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1_ctl00_ForumMenu" class="popupMenuSink" valign="top" align="left" width="1px">
            <nobr>
                <span id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1_ctl00_ForumSeparator" class="normalTextSmallBold">&nbsp;&gt;</span>
                <a id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1_ctl00_LinkForum" class="linkMenuSink" href="/Forum/Default">General Discussion</a>
            </nobr>
        </td>
        <td id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1_ctl00_PostMenu" class="popupMenuSink" valign="top" align="left" width="1px">
            <nobr>
                <span id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1_ctl00_PostSeparator" class="normalTextSmallBold">&nbsp;&gt;</span>
                <a id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami1_ctl00_LinkPost" class="linkMenuSink" href="/Forum/ShowPost?PostID=<?php echo $PostID ; ?>"><?php echo $fetchuser->title ; ?></a>
            </nobr>
        </td>
        <td valign="top" align="left" width="*">&nbsp;</td>
    </tr>
</table>
<span id="ctl00_cphRBXAcer_PostView1_ctl00_Whereami2_ctl00_MenuScript"></span></span>
    </td>
  </tr>
</table>
</span>
								</td>
								<td class="CenterColumn">&nbsp;&nbsp;&nbsp;</td>
								<!-- right margin -->
								<td class="RightColumn">&nbsp;&nbsp;&nbsp;</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
				</div>
<?php require '../more/footer.php'; ?>