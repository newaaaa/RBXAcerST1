<?php
include('../more/connect.php');
if(!$loggedIn) {
	header("Location: /");
}
?>
<?php require '../more/Default.php'; ?>
<?php require '../more/nav.php'; ?>
<?php 
$idtest = $_GET['PostID'];
?>
<link rel="stylesheet" href="/Forum/api/skins/default/style/default.css" type="text/css"/>
<div id="Body">
    <span>
    <table width="100%" cellspacing="1" cellpadding="0">
	<tr>
		<td align="right" valign="middle">
			<a id="ctl00_cphRBXAcer_NavigationMenu2_ctl00_HomeMenu" class="menuTextLink" href="/Forum/Default"><img src="/Forum/api/skins/default/images/icon_mini_home.gif" border="0">Home &nbsp;</a>
			<a id="ctl00_cphRBXAcer_NavigationMenu2_ctl00_SearchMenu" class="menuTextLink" href="/Forum/Search"><img src="/Forum/api/skins/default/images/icon_mini_search.gif" border="0">Search &nbsp;</a>
		</td>
	</tr>
</table>
</span>
	<form action="/Forum/AddTopic?PostID=<?php echo $idtest ; ?>" method="POST">
	<table width="100%" cellspacing="0" cellpadding="0" border="0">
	  <tbody><tr>
	    <td>
	    </td>
	  </tr>
	                <tr>
	                  <td>&nbsp;</td>
	                </tr>
	                <tr>
	                  <td valign="top" colspan="2">
	                  	<table class="tableBorder" cellspacing="1" cellpadding="3" width="100%" align="left">
											  <tbody>
											    <tr>
											      <th class="tableHeaderText" align="left" height="25">&nbsp;Post a New Message</th>
											    </tr>
											    											    <tr>
											      <td class="forumRow">
											        <table cellspacing="1" cellpadding="3">
											          <tbody>
											            <tr>
											              <td valign="top" nowrap="" align="right"><span class="normalTextSmallBold">Author: </span></td>
											              <td valign="top" align="left" colspan="2"><span class="normalTextSmall"><span id="PostAuthor"><?php echo $user->username ; ?></span>
											                </span>
											              </td>
											            </tr>
											            											            <tr>
											              <td valign="center" nowrap="" align="right"><span class="normalTextSmallBold">Subject: </span></td>
											              <td valign="top" align="left"><input type="text" name="NameTopic" id="PostSubject" cols="55" style="width: 340px;"></td>
											            </tr>
											            											            <tr>
											              <td valign="top" nowrap="" align="right"><span class="normalTextSmallBold">Message: </span>
											              </td>
											              <td valign="top" align="left">
											                <textarea name="Content" cols="33" id="PostBody" rows="2" style="height: 236px; margin: 0px; width: 804px;"></textarea>
											              </td>
											            </tr>
											            <tr>
											              <td valign="top" align="right" colspan="2">
<input type="submit" name="Postsr" value="Post">
											              </td>
											            </tr>
											           
											          </tbody>
											        </table>
											      </td>
											    </tr>
											  												  </tbody>
											</table>
	                  </td>
	                </tr>
	                <tr>
	                  <td colspan="2">&nbsp;
	                  </td>
	                </tr>
	              </tbody></table>
	            </span>
	          </td>
	          <td class="CenterColumn">&nbsp;&nbsp;&nbsp;</td>
	          <!-- right margin -->
	          <td class="RightColumn">&nbsp;&nbsp;&nbsp;</td>
	        </tr>
	      </tbody></table>
	    </td>
	  </tr>
	</tbody></table>
</form>
<?php require '../more/footer.php'; ?>
</div>