<?php
include '../more/connect.php';
if(!$loggedIn) {
	header("Location: /");
}
$RefreshRate = rand(0,100000);

include '../more/filter.php';
$id = trim($conn->real_escape_string($_GET['id']));

if(!$id || !is_numeric($id)) {
    header("Location: /user/?id=1");
    die();
}else{
    $checkExists = $conn->query("SELECT * FROM `users` WHERE `id`='$id'");
    $exists = mysqli_num_rows($checkExists);
    if($exists == 0) {
        header("Location: /404");
        die();
    }
}

$select = $conn->query("SELECT * FROM users WHERE id='".$id."'");
$fetchuser = mysqli_fetch_object($select);


if ($fetchuser == 0) {
    header("Location: ../");
}

if($fetchuser->username !== $user->username) {
$updateviews = $conn->query("UPDATE `users` SET `profile_views` = `profile_views` + 1 WHERE username = '$fetchuser->username'");
}

$getUviews = $conn->query("SELECT `profile_views` FROM `users` WHERE username = '$fetchuser->username'");

while($row = mysqli_fetch_array($getUviews)) {
    $profileviews = $row['profile_views']; //$db-query("SELECT `profile_views` FROM `users` WHERE username='$fetch_user->username'");
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" id="www-roblox-com">
	<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>
    RBXAcer: A FREE Virtual World-Building Game with Avatar Chat, 3D Environments, and Physics
</title><link id="ctl00_Imports" rel="stylesheet" type="text/css" href="/CSS/AllCSS.ashx.css"/><link id="ctl00_Favicon" rel="Shortcut Icon" type="image/ico" href="/favicon.ico"/><meta name="author" content="RBXAcer Corporation"/><meta name="description" content="RBXAcer is SAFE for kids! RBXAcer is a FREE casual virtual world with fully constructible/desctructible 3D environments and immersive physics. Build, battle, chat, or just hang out."/><meta name="keywords" content="game, video game, building game, construction game, online game, LEGO game, LEGO, MMO, MMORPG, virtual world, avatar chat."/></head>
    <body>
			<div id="Container">
<div id="AdvertisingLeaderboard">
</div>
<?php require '../more/nav.php'; ?>
<div id="Body">
    <script>
	function SendFriend()
	{
		window.location = '/my/friends/send/?to=<?php echo $id ; ?>';
	}
</script>
	<div id="UserContainer">
		<div id="LeftBank">
			<div id="ProfilePane">

<table width="100%" bgcolor="lightsteelblue" cellpadding="6" cellspacing="0">
    <tbody><tr>
        <td>
            <span id="ctl00_cphRoblox_rbxUserPane_lUserName" class="Title"><?php echo "".$fetchuser->username.""; ?></span><br>
            <?php
      if($badge == $user->id){
      echo'<span class="UserOnlineMessage">[ Online: Website ]</span>';
      }
      else{
      echo'<span class="UserOfflineMessage">[ Offline ]</span>';
      }
      ?>
        </td>
    </tr>
    <tr>
        <td>
            <span id="ctl00_cphRoblox_rbxUserPane_lUserRobloxURL"><?php echo "".$fetchuser->username.""; ?>'s RBXAcer:</span><br>
            <a href="/user/?id=<?php echo $badge ; ?>">http://coolblox.net/user/?id=<?php echo $badge ; ?></a><br>
            <br>
            <div style="left: 0px; float: left; position: relative; top: 0px">
<iframe height="220" width="200" src="/api/getAvatar.php?id=<?php echo $fetchuser->id ; ?>" frameborder="0" scrolling="no"></iframe>
                <div id="ctl00_cphRoblox_rbxUserPane_AbuseReportButton1_AbuseReportPanel" class="ReportAbusePanel">

    <span class="AbuseIcon"><a id="ctl00_cphRoblox_rbxUserPane_AbuseReportButton1_ReportAbuseIconHyperLink"><img src="/images/abuse.gif" alt="Report Abuse" border="0"></a></span>
    <span class="AbuseButton"><a id="ctl00_cphRoblox_rbxUserPane_AbuseReportButton1_ReportAbuseTextHyperLink" href="#">Report Abuse</a></span>

</div>
            </div><p><a href="/">Send Message (Developing)</a></p>
						<?php $check = $conn->query("SELECT * FROM friends WHERE uid='$user->id' AND friendid='$id'");
						$CheckEnd = mysqli_num_rows($check);
						if($CheckEnd == 0) {
						echo"<p><a onclick='SendFriend();' style='color:blue'>Send Friend Request</a></p>";
						}else{
						}
						?>
<p><span id="ctl00_cphRoblox_rbxUserPane_rbxPublicUser_lBlurb">
      <?php
if($fetchuser->banned == 1){
header("Location: /404");
}
if($fetchuser->banned == 1){
echo "BANNED";
}else{
echo "".$fetchuser->description."";
}
?>
</span></p>
        </td>
    </tr>
</tbody></table>

			</div>
			<div id="UserBadgesPane">


<div id="UserBadges">
	<h4><a id="ctl00_cphRoblox_rbxUserBadgesPane_hlHeader">Badges</a></h4>
	<table id="ctl00_cphRoblox_rbxUserBadgesPane_dlBadges" cellspacing="0" align="Center" border="0">
	<tbody><tr>
		<td>
      <?php
if($badge == "622"){
echo "<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_iBadge' src='/images/Badges/BetaTester-75x75.png' alt='The beta-tester.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_HyperLink1'>Beta Tester</a></div>
			</div>
		</td>";
}
elseif($badge == "691"){
echo "		<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_iBadge' src='/images/Badges/BuildersClub-75x75.png' alt='Members of the illustrious Builders Club display this badge proudly. The Builders Club is a paid premium service. Members receive several benefits: they get ten places on their account instead of one, they earn a daily income of 15 ROBUX, they can sell their creations to others in the RBXAcer Catalog, they get the ability to browse the web site without external ads, and they receive the exclusive Builders Club construction hat.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_HyperLink1'>Builders Club</a></div>
			</div>
		</td>";
}
elseif($badge == "13"){
echo "<tr>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_iBadge' src='/images/Badges/CombatInitiation-75x75.jpg' alt='This badge is given to any player who has proven his or her combat abilities by accumulating 10 victories in battle. Players who have this badge are not complete newbies and probably know how to handle their weapons.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_HyperLink1'>Combat Initiation</a></div>
			</div>
		</td>
<td>
<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_hlHeader''><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_iBadge' src='/images/Badges/Homestead-70x75.jpg' alt='The homestead badge is earned by having your personal place visited 100 times. Players who achieve this have demonstrated their ability to build cool things that other Robloxians were interested enough in to check out. Get a jump-start on earning this reward by inviting people to come visit your place.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_HyperLink1'>Homestead</a></div>
			</div></td><td>
<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_iBadge' src='/images/Badges/Administrator_75x75.png' alt='This badge identifies an account as belonging to a RBXAcer Administrator_75x75. Only official RBXAcer Administrator_75x75s will possess this badge. If someone claims to be an admin, but does not have this badge, they are potentially trying to mislead you. If this happens, please report abuse and we will delete the imposter's account.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_HyperLink1'>Administrator</a></div>
			</div></td>
			<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_iBadge' src='/images/Badges/Bricksmith-54x75.jpg' alt='The Bricksmith badge is earned by having a popular personal place. Once your place has been visited 1000 times, you will receive this award. Robloxians with Bricksmith badges are accomplished builders who were able to create a place that people wanted to explore a thousand times. They no doubt know a thing or two about putting bricks together.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_HyperLink1'>Bricksmith</a></div>
			</div>
		</td><tr><tr>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_iBadge' src='/images/Badges/Friendship-75x75.jpg' alt='This badge is given to players who have embraced the RBXAcer community and have made at least 20 friends. People who have this badge are good people to know and can probably help you out if you are having trouble.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_HyperLink1'>Friendship</a></div>
			</div>
		</td>
		<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_iBadge' src='/images/Badges/BuildersClub-75x75.png' alt='Members of the illustrious Builders Club display this badge proudly. The Builders Club is a paid premium service. Members receive several benefits: they get ten places on their account instead of one, they earn a daily income of 15 ROBUX, they can sell their creations to others in the RBXAcer Catalog, they get the ability to browse the web site without external ads, and they receive the exclusive Builders Club construction hat.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_HyperLink1'>Builders Club</a></div>
			</div>
		</td>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_iBadge' src='/images/Badges/Bloxxer-75x75.jpg' alt='Anyone who has earned this badge is a very dangerous player indeed. Those Robloxians who excel at combat can one day hope to achieve this honor, the Bloxxer Badge. It is given to the warrior who has bloxxed at least 250 enemies and who has tasted victory more times than he or she has suffered defeat. Salute!' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_HyperLink1'>Bloxxer</a></div>
			</div>
		</td>
<td>
					<div class='Badge'>
						<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_iBadge' src='/images/Badges/Warrior-75x75.jpg' alt='This badge is given to the warriors of Robloxia, who have time and time again overwhelmed their foes in battle. To earn this badge, you must rack up 100 knockouts. Anyone with this badge knows what to do in a fight!' height='75' border='0'></a></div>
						<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_HyperLink1'>Warrior</a></div>
					</div>
</td>
</tr>";
}
elseif($badge == "1"){
echo "<tr>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_iBadge' src='/images/Badges/CombatInitiation-75x75.jpg' alt='This badge is given to any player who has proven his or her combat abilities by accumulating 10 victories in battle. Players who have this badge are not complete newbies and probably know how to handle their weapons.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_HyperLink1'>Combat Initiation</a></div>
			</div>
		</td>
<td>
<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_hlHeader''><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_iBadge' src='/images/Badges/Homestead-70x75.jpg' alt='The homestead badge is earned by having your personal place visited 100 times. Players who achieve this have demonstrated their ability to build cool things that other Robloxians were interested enough in to check out. Get a jump-start on earning this reward by inviting people to come visit your place.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_HyperLink1'>Homestead</a></div>
			</div></td><td>
<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_iBadge' src='/images/Badges/Administrator_75x75.png' alt='This badge identifies an account as belonging to a RBXAcer Administrator_75x75. Only official RBXAcer Administrator_75x75s will possess this badge. If someone claims to be an admin, but does not have this badge, they are potentially trying to mislead you. If this happens, please report abuse and we will delete the imposter's account.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_HyperLink1'>Administrator</a></div>
			</div></td>
			<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_iBadge' src='/images/Badges/Bricksmith-54x75.jpg' alt='The Bricksmith badge is earned by having a popular personal place. Once your place has been visited 1000 times, you will receive this award. Robloxians with Bricksmith badges are accomplished builders who were able to create a place that people wanted to explore a thousand times. They no doubt know a thing or two about putting bricks together.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_HyperLink1'>Bricksmith</a></div>
			</div>
		</td><tr><tr>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_iBadge' src='/images/Badges/Friendship-75x75.jpg' alt='This badge is given to players who have embraced the RBXAcer community and have made at least 20 friends. People who have this badge are good people to know and can probably help you out if you are having trouble.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_HyperLink1'>monke</a></div>
			</div>
		</td>
		<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_iBadge' src='/images/Badges/BuildersClub-75x75.png' alt='Members of the illustrious Builders Club display this badge proudly. The Builders Club is a paid premium service. Members receive several benefits: they get ten places on their account instead of one, they earn a daily income of 15 ROBUX, they can sell their creations to others in the RBXAcer Catalog, they get the ability to browse the web site without external ads, and they receive the exclusive Builders Club construction hat.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_HyperLink1'>Builders Club</a></div>
			</div>
		</td>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_iBadge' src='/images/Badges/Bloxxer-75x75.jpg' alt='Anyone who has earned this badge is a very dangerous player indeed. Those Robloxians who excel at combat can one day hope to achieve this honor, the Bloxxer Badge. It is given to the warrior who has bloxxed at least 250 enemies and who has tasted victory more times than he or she has suffered defeat. Salute!' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_HyperLink1'>Bloxxer</a></div>
			</div>
		</td>
<td>
					<div class='Badge'>
						<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_iBadge' src='/images/Badges/Warrior-75x75.jpg' alt='This badge is given to the warriors of Robloxia, who have time and time again overwhelmed their foes in battle. To earn this badge, you must rack up 100 knockouts. Anyone with this badge knows what to do in a fight!' height='75' border='0'></a></div>
						<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_HyperLink1'>Warrior</a></div>
					</div>
</td>
</tr>";
}
elseif($badge == "21"){
echo "<tr>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_iBadge' src='/images/Badges/CombatInitiation-75x75.jpg' alt='This badge is given to any player who has proven his or her combat abilities by accumulating 10 victories in battle. Players who have this badge are not complete newbies and probably know how to handle their weapons.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_HyperLink1'>Combat Initiation</a></div>
			</div>
		</td>
<td>
<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_hlHeader''><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_iBadge' src='/images/Badges/Homestead-70x75.jpg' alt='The homestead badge is earned by having your personal place visited 100 times. Players who achieve this have demonstrated their ability to build cool things that other Robloxians were interested enough in to check out. Get a jump-start on earning this reward by inviting people to come visit your place.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_HyperLink1'>Homestead</a></div>
			</div></td><td>
<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_iBadge' src='/images/Badges/Administrator_75x75.png' alt='This badge identifies an account as belonging to a RBXAcer Administrator_75x75. Only official RBXAcer Administrator_75x75s will possess this badge. If someone claims to be an admin, but does not have this badge, they are potentially trying to mislead you. If this happens, please report abuse and we will delete the imposter's account.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_HyperLink1'>Administrator</a></div>
			</div></td>
			<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_iBadge' src='/images/Badges/Bricksmith-54x75.jpg' alt='The Bricksmith badge is earned by having a popular personal place. Once your place has been visited 1000 times, you will receive this award. Robloxians with Bricksmith badges are accomplished builders who were able to create a place that people wanted to explore a thousand times. They no doubt know a thing or two about putting bricks together.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_HyperLink1'>Bricksmith</a></div>
			</div>
		</td><tr><tr>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_iBadge' src='/images/Badges/Friendship-75x75.jpg' alt='This badge is given to players who have embraced the RBXAcer community and have made at least 20 friends. People who have this badge are good people to know and can probably help you out if you are having trouble.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_HyperLink1'>Friendship</a></div>
			</div>
		</td>
		<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_iBadge' src='/images/Badges/BuildersClub-75x75.png' alt='Members of the illustrious Builders Club display this badge proudly. The Builders Club is a paid premium service. Members receive several benefits: they get ten places on their account instead of one, they earn a daily income of 15 ROBUX, they can sell their creations to others in the RBXAcer Catalog, they get the ability to browse the web site without external ads, and they receive the exclusive Builders Club construction hat.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_HyperLink1'>Builders Club</a></div>
			</div>
		</td>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_iBadge' src='/images/Badges/Bloxxer-75x75.jpg' alt='Anyone who has earned this badge is a very dangerous player indeed. Those Robloxians who excel at combat can one day hope to achieve this honor, the Bloxxer Badge. It is given to the warrior who has bloxxed at least 250 enemies and who has tasted victory more times than he or she has suffered defeat. Salute!' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_HyperLink1'>Bloxxer</a></div>
			</div>
		</td>
<td>
					<div class='Badge'>
						<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_iBadge' src='/images/Badges/Warrior-75x75.jpg' alt='This badge is given to the warriors of Robloxia, who have time and time again overwhelmed their foes in battle. To earn this badge, you must rack up 100 knockouts. Anyone with this badge knows what to do in a fight!' height='75' border='0'></a></div>
						<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_HyperLink1'>Warrior</a></div>
					</div>
</td>
</tr>";
}
elseif($badge == "156"){
echo "<div class='Badge'>
    <div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_iBadge' src='/badges/NitroBadge.png' alt='This badge identifies an account as belonging to a RBXAcer Nitro Booster. Only RBXAcer Nitro Booster will possess this badge.' height='75' border='0'></a></div>
    <div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_HyperLink1'>Nitro Booster</a></div>
  </div>";
}
  elseif($badge == "149"){
echo "<div class='Badge'>
    <div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_iBadge' src='/badges/NitroBadge.png' alt='This badge identifies an account as belonging to a RBXAcer Nitro Booster. Only RBXAcer Nitro Booster will possess this badge.' height='75' border='0'></a></div>
    <div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_HyperLink1'>Nitro Booster</a></div>
  </div>";
}
else{
echo "This user has no badges";
}
?>
		</td>
	</tr>
</tbody></table>

</div>
			</div>
      <div id="UserStatisticsPane">
  					<div id="UserStatistics">
  						<div id="StatisticsPanel" style="transition: height 0.5s ease-out 0s; overflow: hidden; height: 200px;">
  							<div class="Header">
  								<h4>Statistics</h4>
  								<span class="PanelToggle"></span>
  							</div>
  							<div style="margin: 10px 10px 150px 10px;" id="Results">
  								<div class="Statistic">
  								    <?php $check = $conn->query("SELECT * FROM friends WHERE uid='$id' OR friendid='$id'");
		$Friend = mysqli_num_rows($check);
		?>
  									<div class="Label"><acronym title="The number of this user's friends.">Friends</acronym>:</div>
  									<div class="Value"><span><?php echo $Friend ; ?></span></div>
  								</div>
  																<div class="Statistic">
  									<div class="Label"><acronym title="The number of posts this user has made to the RBXAcer forum.">Forum Posts</acronym>:</div>
  									<div class="Value"><span>0</span></div>
  								</div>
  								<div class="Statistic">
  									<div class="Label"><acronym title="The number of times this user's profile has been viewed.">Profile Views</acronym>:</div>
  									<div class="Value"><span><?php echo "".$fetchuser->profile_views.""; ?></span></div>
  								</div>
  								<div class="Statistic">
  									<div class="Label"><acronym title="The number of times this user's place has been visited.">Place Visits</acronym>:</div>
  									<div class="Value"><span>0</span></div>
  								</div>
  								<div class="Statistic">
  									<div class="Label"><acronym title="The number of times this user's models have been viewed - unfinished.">Model Views</acronym>:</div>
  									<div class="Value"><span>0</span></div>
  								</div>
  								<div class="Statistic">
  									<div class="Label"><acronym title="The number of times this user's character has destroyed another user's character in-game.">Knockouts</acronym>:</div>
  									<div class="Value"><span>0</span></div>
  								</div>
  								<div class="Statistic">
  									<div class="Label"><acronym title="The number of times this user's character has been destroyed in-game.">Wipeouts</acronym>:</div>
  									<div class="Value"><span>0</span></div>
                  </div>
  							</div>
  						</div>
  					</div>
  				</div>
		</div>
		<div id="RightBank">
<div id='UserPlacesPane'>
				 <p style='padding: 10px 10px 10px 10px;'>This person doesn't have any RBXAcer places.</p> 			</div>
      <div id="FriendsPane">
					<div id="Friends">
						<style>
						body {
						font: normal 8pt/normal 'Comic Sans MS',Verdana,sans-serif;
						margin-top: 0;
						text-transform: none;
						text-decoration: none;
				}
				</style>
				<?php $check = $conn->query("SELECT * FROM friends WHERE uid='$id' OR friendid='$id'");
		$CheckEnd = mysqli_num_rows($check);
		?>
				<?php
				if($fetchuser->uid == $id){
						$FriendId = $fetchuser->uid;
						$FriendName = $fetchuser->uname;
				} else {
						$FriendId = $fetchuser->friendid;
						$FriendName = $fetchuser->friendname;
				}
				?>
<table cellspacing="0" align="Center" border="0" style="border-collapse:collapse;">
					<tbody><tr>
												<h4><?php echo "".$fetchuser->username.""; ?>'s friends 
												
	<?php $check = $conn->query("SELECT * FROM friends WHERE uid='$id' OR friendid='$id'");
		$CheckEnd = mysqli_num_rows($check);
		if($CheckEnd !== 0) {
					    echo"<a href='/friends/?of=$id'>See all $CheckEnd</a>";
		}
					    ?>
					    </h4>
												<?php $check = $conn->query("SELECT * FROM friends WHERE uid='$id' OR friendid='$id'");
		$CheckEnd = mysqli_num_rows($check);
		if($CheckEnd == 0) {
					    echo"<p style='padding: 10px 10px 10px 10px;'>This person doesn't have any RBXAcer Friends.</p>";
		}
					    ?>
												<?php
																						$resultsperpage = 3;
																						$check = mysqli_query($conn, "SELECT * FROM friends");
																						$usercount = mysqli_num_rows($check);

																						$numberofpages = ceil($usercount/$resultsperpage);

																						if(!isset($_GET['page'])) {
																								$page = 1;
																						}else{
																								$page = $_GET['page'];
																						}

																						$thispagefirstresult = ($page-1)*$resultsperpage;

																						$check = mysqli_query($conn, "SELECT * FROM friends WHERE uid='$id' OR friendid='$id' LIMIT ".$thispagefirstresult.",".$resultsperpage);

																						while($result = mysqli_fetch_array($check)) {

																if($result['uid'] == $id){
																		$FriendId = $result['friendid'];
																		$FriendName = $result['friendname'];
																} else {
																		$FriendId = $result['uid'];
																		$FriendName = $result['uname'];
																}
																if(!empty($FriendId)){
																echo"<td><div class='Friend'>
																																<div class='Avatar'>
																																		<a title='$FriendName' href='/user/?id=$FriendId' style='display:inline-block;max-height:100px;max-width:100px;cursor:pointer;'>
												<iframe height='100' width='100' src='/api/getAvatar.php?id=$FriendId&amp;size=85' frameborder='0' scrolling='no'></iframe>
																																		</a>
																																</div>
																																<div class='Summary'>
																																																								<span class='OnlineStatus'>
																																				<img src='/images/OnlineStatusIndicator_IsOffline.gif' alt='Pixel' style='border-width:0px;'></span>
																																																								<span class='Name'><a href='/user/?id=$FriendId'>$FriendName</a></span>
																																</div>
																														</div></td>";
																						}
														else{

																						}
																						}
												?>
												</tr><tr>
												<?php
																						$resultsperpage = 3;
																						$check = mysqli_query($conn, "SELECT * FROM friends");
																						$usercount = mysqli_num_rows($check);

																						$numberofpages = ceil($usercount/$resultsperpage);

																						if(!isset($_GET['page'])) {
																								$page = 2;
																						}else{
																								$page = $_GET['page'];
																						}

																						$thispagefirstresult = ($page-1)*$resultsperpage;

																						$check = mysqli_query($conn, "SELECT * FROM friends WHERE uid='$id' OR friendid='$id' LIMIT ".$thispagefirstresult.",".$resultsperpage);

																						while($result = mysqli_fetch_array($check)) {

																if($result['uid'] == $id){
																		$FriendId = $result['friendid'];
																		$FriendName = $result['friendname'];
																} else {
																		$FriendId = $result['uid'];
																		$FriendName = $result['uname'];
																}
																if(!empty($FriendId)){
																echo"<td><div class='Friend'>
																																<div class='Avatar'>
																																		<a title='$FriendName' href='/user/?id=$FriendId' style='display:inline-block;max-height:100px;max-width:100px;cursor:pointer;'>
												<iframe height='100' width='100' src='/api/getAvatar.php?id=$FriendId&amp;size=85' frameborder='0' scrolling='no'></iframe>
																																		</a>
																																</div>
																																<div class='Summary'>
																																																								<span class='OnlineStatus'>
																																				<img src='/images/OnlineStatusIndicator_IsOffline.gif' alt='Pixel' style='border-width:0px;'></span>
																																																								<span class='Name'><a href='/user/?id=$FriendId'>$FriendName</a></span>
																																</div>
																														</div></td>";
																						}
														else{

																						}
																						}
												?>
												</tr>
				</tbody></table>
											</div>
				</div>
        <div id="FavoritesPane" style="clear: right; margin: 10px 0 0 0; border: solid 1px #000;">
  					<div>
  			            <style>
  			                #FavoritesPane #Favorites h4
  			                {
  		                        background-color: #ccc;
  		                        border-bottom: solid 1px #000;
  		                        color: #333;
  		                        font-family: Comic Sans MS,Verdana,Sans-Serif;
  		                        margin: 0;
  		                        text-align: center;
  		                    }
  		                    #Favorites .PanelFooter
  		                    {
  							    background-color: #fff;
  							    border-top: solid 1px #000;
  							    color: #333;
  							    font-family: Verdana,Sans-Serif;
  							    margin: 0;
  							    padding: 3px;
  							    text-align: center;
  							}
  							#UserContainer #AssetsContent .HeaderPager, #UserContainer #FavoritesContent .HeaderPager
  							{
  							    margin-bottom: 10px;
  							}
  							#UserContainer #AssetsContent .HeaderPager, #UserContainer #FavoritesContent .HeaderPager, #UserContainer #AssetsContent .FooterPager, #UserContainer #FavoritesContent .FooterPager {
  							    margin: 0 12px 0 10px;
  							    padding: 2px 0;
  							    text-align: center;
  							}
  		                </style>
  						<div id="Favorites">
  							<h4>Favorites</h4>
  							<div id="FavoritesContent">This user does not have any favorites for this type</div>
  							<div class="PanelFooter">
  								Category:&nbsp;
  								<select id="FavCategories">
  									<option value="7">Heads</option>
  									<option value="8">Faces</option>
  									<option value="2">T-Shirts</option>
  									<option value="5">Shirts</option>
  									<option value="6">Pants</option>
  									<option value="1">Hats</option>
  									<option value="4">Decals</option>
  									<option value="3">Models</option>
  									<option selected="selected" value="0">Places</option>
  								</select>
  							</div>
  						</div>
  					</div>
  				</div>
		</div>
	</div>

<div style="clear:both;"></div>
<center>
<?php require '../more/footer.php'; ?>
</center>
				</div>
