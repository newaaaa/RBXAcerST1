<?php
include '../../more/connect.php';
if(!$loggedIn) {
	header("Location: /");
}
?>
<?php require '../../more/Default.php'; ?>
<link id="ctl00_Favicon" rel="Shortcut Icon" type="image/ico" href="/favicon.ico"/>
<link id="ctl00_Imports" rel="stylesheet" type="text/css" href="/CSS/CSS.css"/>
<?php require '../../more/nav.php'; ?>
<div id="Body">
	<div id="UserContainer">
	<div id="LeftBank">
		<div>
			<div id="ProfilePane">
				<table width="100%" bgcolor="lightsteelblue" cellpadding="6" cellspacing="0">
					<tbody><tr>
						<td>
							<font face="Verdana"><span class="Title">Welcome, <?php echo $username ; ?>!</span><br></font>
						</td>
					</tr>
					<tr>
						<td>
						<font face="Verdana">
							<span>Your RBXAcer:</span><br>
							<a href="/user/?id=<?php echo $user->id ; ?>">https://coolblox.net/user/?id=<?php echo $user->id ; ?></a>
							<br>
							<br>
							<div style="left: 0px; float: left; position: relative; top: 0px;margin-top:67px;margin-left:10px">
								<a disabled="disabled" title="<?php echo $username ; ?>" onclick="return false" style="display:inline-block;height:220px;width:180px;">
									<iframe height="220" width="200" src="/api/getAvatar.php?id=<?php echo $user->id ; ?>" frameborder="0" scrolling="no"></iframe>
								</a>
								<br>
							</div>
						<div style="float:right;text-align:left;width:210px;"><font face="Verdana">
							<p><a href="/my/messages/inbox">Inbox</a>&nbsp;</p>
							<p><a href="/my/character/Hats/?page=1">Change Character</a></p>
							<p><a href="/my/settings">Edit Profile</a></p>
							<p><a href="/my/accountbalance">Account Balance</a></p>
							<p><a href="/user/?id=<?php echo $user->id ; ?>">View Public Profile</a></p>
							<p>
																<a href="/my/create/">Create New Place</a>							</p>
							<p><a href="/info/terms">Terms, Conditions, and Rules</a></p>
							</font>
							</div>
						</font></td>
					</tr>
				</tbody></table>
							</div>
		</div>
		<div>	<div id="UserBadgesPane">
				<div id="UserBadges">
					<h4><a>Badges</a></h4>
<table id="ctl00_cphRoblox_rbxUserBadgesPane_dlBadges" cellspacing="0" align="Center" border="0">
	<tbody>				
<?php		
if($user->id == "622"){
echo "<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_iBadge' src='/images/Badges/BetaTester-75x75.png' alt='The beta-tester.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_HyperLink1'>Beta Tester</a></div>
			</div>
		</td>";
}
elseif($user->id == "691"){
echo "		<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_iBadge' src='/images/Badges/BuildersClub-75x75.png' alt='Members of the illustrious Builders Club display this badge proudly. The Builders Club is a paid premium service. Members receive several benefits: they get ten places on their account instead of one, they earn a daily income of 15 ROBUX, they can sell their creations to others in the RBXAcer Catalog, they get the ability to browse the web site without external ads, and they receive the exclusive Builders Club construction hat.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_HyperLink1'>Builders Club</a></div>
			</div>
		</td>";
}
elseif($user->id == "149"){
echo "<div class='Badge'>
    <div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_iBadge' src='/badges/NitroBadge.png' alt='This badge identifies an account as belonging to a RBXAcer Nitro Booster. Only RBXAcer Nitro Booster will possess this badge.' height='75' border='0'></a></div>
    <div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_HyperLink1'>Nitro Booster</a></div>
  </div>";
}
 elseif($badge == "156"){
echo "<div class='Badge'>
    <div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_iBadge' src='/badges/NitroBadge.png' alt='This badge identifies an account as belonging to a RBXAcer Nitro Booster. Only RBXAcer Nitro Booster will possess this badge.' height='75' border='0'></a></div>
    <div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_HyperLink1'>Nitro Booster</a></div>
  </div>";
}
elseif($user->id == 1){
echo "<tr>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_iBadge' src='/images/Badges/CombatInitiation-75x75.jpg' alt='This badge is given to any player who has proven his or her combat abilities by accumulating 10 victories in battle. Players who have this badge are not complete newbies and probably know how to handle their weapons.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_HyperLink1'>Combat Initiation</a></div>
			</div>
		</td>
<td>
<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_hlHeader''><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_iBadge' src='/images/Badges/Homestead-70x75.jpg' alt='The homestead badge is earned by having your personal place visited 100 times. Players who achieve this have demonstrated their ability to build cool things that other Robloxians were interested enough in to check out. Get a jump-start on earning this reward by inviting people to come visit your place.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_HyperLink1'>Homestead</a></div>
			</div></td><td>
<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_iBadge' src='/images/Badges/Administrator_75x75.png' alt='This badge identifies an account as belonging to a RBXAcer Administrator_75x75. Only official RBXAcer Administrator_75x75s will possess this badge. If someone claims to be an admin, but does not have this badge, they are potentially trying to mislead you. If this happens, please report abuse and we will delete the imposter's account.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_HyperLink1'>Administrator</a></div>
			</div></td>
			<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_iBadge' src='/images/Badges/Bricksmith-54x75.jpg' alt='The Bricksmith badge is earned by having a popular personal place. Once your place has been visited 1000 times, you will receive this award. Robloxians with Bricksmith badges are accomplished builders who were able to create a place that people wanted to explore a thousand times. They no doubt know a thing or two about putting bricks together.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_HyperLink1'>Bricksmith</a></div>
			</div>
		</td><tr><tr>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_iBadge' src='/images/Badges/Friendship-75x75.jpg' alt='This badge is given to players who have embraced the RBXAcer community and have made at least 20 friends. People who have this badge are good people to know and can probably help you out if you are having trouble.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_HyperLink1'>Friendship</a></div>
			</div>
		</td>
		<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_iBadge' src='/images/Badges/BuildersClub-75x75.png' alt='Members of the illustrious Builders Club display this badge proudly. The Builders Club is a paid premium service. Members receive several benefits: they get ten places on their account instead of one, they earn a daily income of 15 ROBUX, they can sell their creations to others in the RBXAcer Catalog, they get the ability to browse the web site without external ads, and they receive the exclusive Builders Club construction hat.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_HyperLink1'>Builders Club</a></div>
			</div>
		</td>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_iBadge' src='/images/Badges/Bloxxer-75x75.jpg' alt='Anyone who has earned this badge is a very dangerous player indeed. Those Robloxians who excel at combat can one day hope to achieve this honor, the Bloxxer Badge. It is given to the warrior who has bloxxed at least 250 enemies and who has tasted victory more times than he or she has suffered defeat. Salute!' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_HyperLink1'>Bloxxer</a></div>
			</div>
		</td>
<td>
					<div class='Badge'>
						<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_iBadge' src='/images/Badges/Warrior-75x75.jpg' alt='This badge is given to the warriors of Robloxia, who have time and time again overwhelmed their foes in battle. To earn this badge, you must rack up 100 knockouts. Anyone with this badge knows what to do in a fight!' height='75' border='0'></a></div>
						<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_HyperLink1'>Warrior</a></div>
					</div>
</td>
</tr>";
}
elseif($user->id == 21){
echo "<tr>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_iBadge' src='/images/Badges/CombatInitiation-75x75.jpg' alt='This badge is given to any player who has proven his or her combat abilities by accumulating 10 victories in battle. Players who have this badge are not complete newbies and probably know how to handle their weapons.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_HyperLink1'>Combat Initiation</a></div>
			</div>
		</td>
<td>
<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_hlHeader''><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_iBadge' src='/images/Badges/Homestead-70x75.jpg' alt='The homestead badge is earned by having your personal place visited 100 times. Players who achieve this have demonstrated their ability to build cool things that other Robloxians were interested enough in to check out. Get a jump-start on earning this reward by inviting people to come visit your place.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_HyperLink1'>Homestead</a></div>
			</div></td><td>
<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_iBadge' src='/images/Badges/Administrator_75x75.png' alt='This badge identifies an account as belonging to a RBXAcer Administrator_75x75. Only official RBXAcer Administrator_75x75s will possess this badge. If someone claims to be an admin, but does not have this badge, they are potentially trying to mislead you. If this happens, please report abuse and we will delete the imposter's account.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_HyperLink1'>Administrator</a></div>
			</div></td>
			<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_iBadge' src='/images/Badges/Bricksmith-54x75.jpg' alt='The Bricksmith badge is earned by having a popular personal place. Once your place has been visited 1000 times, you will receive this award. Robloxians with Bricksmith badges are accomplished builders who were able to create a place that people wanted to explore a thousand times. They no doubt know a thing or two about putting bricks together.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_HyperLink1'>Bricksmith</a></div>
			</div>
		</td><tr><tr>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_iBadge' src='/images/Badges/Friendship-75x75.jpg' alt='This badge is given to players who have embraced the RBXAcer community and have made at least 20 friends. People who have this badge are good people to know and can probably help you out if you are having trouble.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_HyperLink1'>Friendship</a></div>
			</div>
		</td>
		<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_iBadge' src='/images/Badges/BuildersClub-75x75.png' alt='Members of the illustrious Builders Club display this badge proudly. The Builders Club is a paid premium service. Members receive several benefits: they get ten places on their account instead of one, they earn a daily income of 15 ROBUX, they can sell their creations to others in the RBXAcer Catalog, they get the ability to browse the web site without external ads, and they receive the exclusive Builders Club construction hat.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_HyperLink1'>Builders Club</a></div>
			</div>
		</td>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_iBadge' src='/images/Badges/Bloxxer-75x75.jpg' alt='Anyone who has earned this badge is a very dangerous player indeed. Those Robloxians who excel at combat can one day hope to achieve this honor, the Bloxxer Badge. It is given to the warrior who has bloxxed at least 250 enemies and who has tasted victory more times than he or she has suffered defeat. Salute!' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_HyperLink1'>Bloxxer</a></div>
			</div>
		</td>
<td>
					<div class='Badge'>
						<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_iBadge' src='/images/Badges/Warrior-75x75.jpg' alt='This badge is given to the warriors of Robloxia, who have time and time again overwhelmed their foes in battle. To earn this badge, you must rack up 100 knockouts. Anyone with this badge knows what to do in a fight!' height='75' border='0'></a></div>
						<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_HyperLink1'>Warrior</a></div>
					</div>
</td>
</tr>";
}
elseif($user->id == 13){
echo "<tr>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_iBadge' src='/images/Badges/CombatInitiation-75x75.jpg' alt='This badge is given to any player who has proven his or her combat abilities by accumulating 10 victories in battle. Players who have this badge are not complete newbies and probably know how to handle their weapons.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_HyperLink1'>Combat Initiation</a></div>
			</div>
		</td>
<td>
<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_hlHeader''><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_iBadge' src='/images/Badges/Homestead-70x75.jpg' alt='The homestead badge is earned by having your personal place visited 100 times. Players who achieve this have demonstrated their ability to build cool things that other Robloxians were interested enough in to check out. Get a jump-start on earning this reward by inviting people to come visit your place.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_HyperLink1'>Homestead</a></div>
			</div></td><td>
<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_iBadge' src='/images/Badges/Administrator_75x75.png' alt='This badge identifies an account as belonging to a RBXAcer Administrator_75x75. Only official RBXAcer Administrator_75x75s will possess this badge. If someone claims to be an admin, but does not have this badge, they are potentially trying to mislead you. If this happens, please report abuse and we will delete the imposter's account.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl00_HyperLink1'>Administrator</a></div>
			</div></td>
			<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_iBadge' src='/images/Badges/Bricksmith-54x75.jpg' alt='The Bricksmith badge is earned by having a popular personal place. Once your place has been visited 1000 times, you will receive this award. Robloxians with Bricksmith badges are accomplished builders who were able to create a place that people wanted to explore a thousand times. They no doubt know a thing or two about putting bricks together.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl01_HyperLink1'>Bricksmith</a></div>
			</div>
		</td><tr><tr>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_iBadge' src='/images/Badges/Friendship-75x75.jpg' alt='This badge is given to players who have embraced the RBXAcer community and have made at least 20 friends. People who have this badge are good people to know and can probably help you out if you are having trouble.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl05_HyperLink1'>Friendship</a></div>
			</div>
		</td>
		<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_iBadge' src='/images/Badges/BuildersClub-75x75.png' alt='Members of the illustrious Builders Club display this badge proudly. The Builders Club is a paid premium service. Members receive several benefits: they get ten places on their account instead of one, they earn a daily income of 15 ROBUX, they can sell their creations to others in the RBXAcer Catalog, they get the ability to browse the web site without external ads, and they receive the exclusive Builders Club construction hat.' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl06_HyperLink1'>Builders Club</a></div>
			</div>
		</td>
<td>
			<div class='Badge'>
				<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_iBadge' src='/images/Badges/Bloxxer-75x75.jpg' alt='Anyone who has earned this badge is a very dangerous player indeed. Those Robloxians who excel at combat can one day hope to achieve this honor, the Bloxxer Badge. It is given to the warrior who has bloxxed at least 250 enemies and who has tasted victory more times than he or she has suffered defeat. Salute!' height='75' border='0'></a></div>
				<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl07_HyperLink1'>Bloxxer</a></div>
			</div>
		</td>
<td>
					<div class='Badge'>
						<div class='BadgeImage'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_hlHeader'><img id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_iBadge' src='/images/Badges/Warrior-75x75.jpg' alt='This badge is given to the warriors of Robloxia, who have time and time again overwhelmed their foes in battle. To earn this badge, you must rack up 100 knockouts. Anyone with this badge knows what to do in a fight!' height='75' border='0'></a></div>
						<div class='BadgeLabel'><a id='ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl04_HyperLink1'>Warrior</a></div>
					</div>
</td>
</tr>";
}
else{
 echo "<a>You have no badges</a>";
}
?>	</tbody>
					</table>
				</div>
			</div>
		</div>
		<div>
		<div id="UserStatisticsPane">
					<div id="UserStatistics">
						<div id="StatisticsPanel" style="transition: height 0.5s ease-out 0s; overflow: hidden; height: 200px;">
							<div class="Header">
								<h4>Statistics</h4>
								<span class="PanelToggle"></span>
							</div>
							<div style="margin: 10px 10px 150px 10px;" id="Results">
								<div class="Statistic">
								    <?php $check = $conn->query("SELECT * FROM friends WHERE uid='$user->id' OR friendid='$user->id'");
$friends = mysqli_num_rows($check); ?>
									<div class="Label"><acronym title="The number of this user's friends.">Friends</acronym>:</div>
									<div class="Value"><span><?php echo"$friends"; ?></span></div>
								</div>
																<div class="Statistic">
									<div class="Label"><acronym title="The number of times this user's profile has been viewed.">Profile Views</acronym>:</div>
									<div class="Value"><span><?php echo $user->profile_views ; ?></span></div>
								</div>
								<div class="Statistic">
									<div class="Label"><acronym title="The number of times this user's place has been visited.">Place Visits</acronym>:</div>
									<div class="Value"><span>0</span></div>
								</div>
								<div class="Statistic">
									<div class="Label"><acronym title="The number of times this user's models have been viewed - unfinished.">Model Views</acronym>:</div>
									<div class="Value"><span>0</span></div>
								</div>
								<div class="Statistic">
									<div class="Label"><acronym title="The number of times this user's character has destroyed another user's character in-game.">Knockouts</acronym>:</div>
									<div class="Value"><span>0</span></div>
								</div>
								<div class="Statistic">
									<div class="Label"><acronym title="The number of times this user's character has been destroyed in-game.">Wipeouts</acronym>:</div>
									<div class="Value"><span>0</span></div>
								</div>
							</div>
						</div>
					</div>
				</div>
</div>
			</div>
		</div>
	</div>
	<style>
	#RightBankTest {
    float: right;
    text-align: center;
    width: 444px;
    margin-bottom: 20px;
}
</style>
	<div id="RightBankTest">
		<div>
			<div id="UserPlacesPane">
				 <p style="padding: 10px 10px 10px 10px;">You don't have any RBXAcer places.</p> 			</div>
			<div id="FriendsPane">
				<div id="Friends">
										<font face="Verdana"><?php $check = $conn->query("SELECT * FROM friends WHERE uid='$user->id' OR friendid='$user->id'");
$CheckEnd = mysqli_num_rows($check);
if($CheckEnd == 0) {
echo"<h4>My friends</h4>";
}else{
    echo"<h4>My friends <a href='/friends/?of=$user->id'>See all ";
$check = $conn->query("SELECT * FROM friends WHERE uid='$user->id' OR friendid='$user->id'");
$CheckEnd = mysqli_num_rows($check);
echo"$CheckEnd";
echo"</a>
													(<a href='/my/friends/edit'>Edit</a>)
						</h4>";
}
?>
					</font>
<center>
<?php
                    $resultsperpage = 3;
                    $check = mysqli_query($conn, "SELECT * FROM friends");
                    $usercount = mysqli_num_rows($check);

                    $numberofpages = ceil($usercount/$resultsperpage);

                    if(!isset($_GET['page'])) {
                        $page = 1;
                    }else{
                        $page = $_GET['page'];
                    }

                    $thispagefirstresult = ($page-1)*$resultsperpage;

                    $check = mysqli_query($conn, "SELECT * FROM friends WHERE uid='$user->id' OR friendid='$user->id' LIMIT ".$thispagefirstresult.",".$resultsperpage);

                    while($result = mysqli_fetch_array($check)) {

        if($result['uid'] == $user->id){
            $FriendId = $result['friendid'];
            $FriendName = $result['friendname'];
        } else {
            $FriendId = $result['uid'];
            $FriendName = $result['uname'];
        }
        if(!empty($FriendId)){
        echo"<fix><div class='Friend'>
                                        <div class='Avatar'>
                                            <a title='$FriendName' href='/user/?id=$FriendId' style='display:inline-block;max-height:100px;max-width:100px;cursor:pointer;'>
<iframe height='100' width='100' src='/api/getAvatar.php?id=$FriendId&amp;size=85' frameborder='0' scrolling='no'></iframe>
                                            </a>
                                        </div>
                                        <div class='Summary'>
                                                                                        <span class='OnlineStatus'>
                                                <img src='/images/OnlineStatusIndicator_IsOffline.gif' alt='$FriendName' style='border-width:0px;'></span>
                                                                                        <span class='Name'><a href='/user/?id=$FriendId'>$FriendName</a></span>
                                        </div>
                                    </div></fix>";
                    }
    else{

                    }
                    }
?>
</center>
<?php $check = $conn->query("SELECT * FROM friends WHERE uid='$user->id' OR friendid='$user->id'");
$CheckEnd = mysqli_num_rows($check);
if($CheckEnd == 0) {
echo"<p style='padding: 10px 10px 10px 10px;'>You don't have any RBXAcer friends.</p>";
}else{
}
?>
<style>
fix {
    display: table-cell;
    vertical-align: inherit;
}
</style></div>
			</div>
			<div id="FavoritesPane" style="clear: right; margin: 10px 0 0 0; border: solid 1px #000;">
				<div>
	            <style>
	                #FavoritesPane #Favorites h4
	                {
                        background-color: #ccc;
                        border-bottom: solid 1px #000;
                        color: #333;
                        font-family: Comic Sans MS,Verdana,Sans-Serif;
                        margin: 0;
                        text-align: center;
                    }
                    #Favorites .PanelFooter
                    {
					    background-color: #fff;
					    border-top: solid 1px #000;
					    color: #333;
					    font-family: Verdana,Sans-Serif;
					    margin: 0;
					    padding: 3px;
					    text-align: center;
					}
					#UserContainer #AssetsContent .HeaderPager, #UserContainer #FavoritesContent .HeaderPager
					{
					    margin-bottom: 10px;
					}
					#UserContainer #AssetsContent .HeaderPager, #UserContainer #FavoritesContent .HeaderPager, #UserContainer #AssetsContent .FooterPager, #UserContainer #FavoritesContent .FooterPager {
					    margin: 0 12px 0 10px;
					    padding: 2px 0;
					    text-align: center;
					}
                </style>
                <script>
                    function getFavs(type,page)
                    {
                    	if(page == undefined){ page = 1; }
                        $.post("https://error", {uid:5657,type:type,page:page}, function(data)
                        {
                        	$("#FavoritesContent").empty();
                            $("#FavoritesContent").html(data);
                        })
                        .fail(function()
                        {
                            $("#FavoritesContent").html("Failed to get favourites");
                        });
                    }
                    $(function()
                    {
                        $("#FavCategories").on("change", function()
                        {
                            getFavs(this.value);
                        });
                        getFavs(0);
                    });
                </script>
				<div id="Favorites">
					<h4>Favorites</h4>
					<div id="FavoritesContent">This user does not have any favorites for this type</div>
					<div class="PanelFooter">
						Category:&nbsp;
						<select id="FavCategories">
							<option value="7">Heads</option>
							<option value="8">Faces</option>
							<option value="2">T-Shirts</option>
							<option value="5">Shirts</option>
							<option value="6">Pants</option>
							<option value="1">Hats</option>
							<option value="4">Decals</option>
							<option value="3">Models</option>
							<option selected="selected" value="0">Places</option>
						</select>
					</div>
				</div>
			</div>
		</div>
	</div>
<font face="Verdana">
		<br>
	<div id="FriendRequestsPane">
		<div id="FriendRequests">
			<span id="FriendRequestsHeaderLabel">
				<h4>My Requests</h4>
			</span>
			<table cellspacing="0" border="0" style="border-collapse:collapse;">
				<tbody><tr>
				    <?php
                    $resultsperpage = 3;
                    $check = mysqli_query($conn, "SELECT * FROM friendsrequest");
                    $usercount = mysqli_num_rows($check);

                    $numberofpages = ceil($usercount/$resultsperpage);

                    if(!isset($_GET['page'])) {
                        $page = 1;
                    }else{
                        $page = $_GET['page'];
                    }

                    $thispagefirstresult = ($page-1)*$resultsperpage;

                    $check = mysqli_query($conn, "SELECT * FROM friendsrequest WHERE friendid='$user->id' LIMIT ".$thispagefirstresult.",".$resultsperpage);

                    while($row = mysqli_fetch_assoc($check)) {

    $id = htmlspecialchars($row['uid']);
    $fid = htmlspecialchars($row['id']);
    $name = htmlspecialchars($row['uname']);
echo"
<td>
<div>
									<script>
function get$fid() {
window.location.href='/my/friends/send/acceptfriend.php?to=$fid'
}
function delete$fid() {
window.location.href='/my/friends/send/delete.php?id=$fid'
}
									</script>
</div>
						<div class='Friend'>
							<div class='Avatar'>
								<a title='$name' href='/my/friends/read?id=19566' style='display:inline-block;height:100px;width:100px;cursor:pointer;'>
<iframe height='100' width='100' src='/api/getAvatar.php?id=$id&amp;size=85' frameborder='0' scrolling='no'></iframe>
								</a>
							</div>
							<div class='Summary'>
								<span class='OnlineStatus'>
									<img src='/images/OnlineStatusIndicator_IsOffline.gif' alt='$name' style='border-width:0px;'></span>
								<span class='Name'>
									<a title='Click to view this invitation' href='/user/?id=$id'>$name</a><br>    <br>
									<input type='submit' class='Button' value='Accept' onclick='get$fid();'><br>  <br><button class='Button' onclick='delete$fid();' name='decallfrs'>Decline</button>
								</span>
							</div>
						</div>
					</td>
";

    $_GET['username'] = $username;
                    }


                        echo "";


                    for ($page=1;$page<=$numberofpages;$page++) {

                        echo "";
                    }

                    echo "";
                    ?>
                    <?php $check = $conn->query("SELECT * FROM friendsrequest WHERE friendid='$user->id'");
$CheckEnd = mysqli_num_rows($check);
if($CheckEnd == 0) {
echo"<p style='padding: 10px 10px 10px 10px;'>You don't have any RBXAcer Requests.</p>";
}else{
}
?>
								</tr>
			</tbody></table>
		</div>
	</div>
		<div>
	</div>
</font>
</div>


<div>
</div>
</div>
<div style="clear:both;"></div>
<center>
<?php require '../../more/footer.php'; ?>
</center>
</div>
