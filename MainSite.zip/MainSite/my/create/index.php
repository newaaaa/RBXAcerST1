<?php
include('../../more/connect.php');
if(!$loggedIn) {
	header("Location: /");
}
?>
<?php require '../../more/Default.php'; ?>
<?php require '../../more/nav.php'; ?>
<div id="Body">
    <style>
    Style Attribute {
    color: #003399;
    background-color: White;
}
    </style>
	<span style="font-size:24px; margin: 270px; text-align: center;">Select Your Starter Template</span>
<br>
<br>
<span style="font-size:16px; text-align: center; margin: 280px;">This will be used to create your new Place.</span>
<br><form action="/my/placeitem" method="post">
<table id="PlaceSelections" cellspacing="0" cellpadding="10" align="Center" border="0" style="border-collapse:collapse;">
		<tbody><tr>
			<td align="center" valign="middle" style="color:#003399;background-color:White;">
				<a supportsalphachannel="false" title="Happy Home in Robloxia" style="display:inline-block;height:140px;width:240px;cursor:pointer;">
					<button href="/placeitem" type="submit" name="new" value="0" style="all: unset;"><img src="/images/HappyHomeBig.png" width="240" height="140" border="0" id="img" alt="Happy Home in Robloxia"></button>
				</a>
				<br>
				<span href="/placeitem" style="font-size: 14px;">Happy Home in Robloxia(click picture)</span>
				<a href="/my/placeitem2" style="font-size: 14px;">|  Happy Home in Robloxia (2014 game)</a>
			</td>
		</tr>
		<tr>
			
			<td>
			</td>
		</tr>
</tbody></table>
</form>
</div>