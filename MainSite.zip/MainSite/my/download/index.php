<?php
include '../more/connect.php';
if($loggedIn) {
	header("Location: /download/Installer/RBXAcer.exe");
}
else {
    header("Location: /");
}
?>