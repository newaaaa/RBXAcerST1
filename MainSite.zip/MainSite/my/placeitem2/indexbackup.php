<?php
include('../../more/connect.php');
if(!$loggedIn) {
	header("Location: /");
}
?>
<?php require '../../more/Default.php'; ?>
<?php require '../../more/nav.php'; ?>
<div id="Body">
<br>
<center><h1>Developing..</h1></center>
</div>