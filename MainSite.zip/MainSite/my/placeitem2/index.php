<?php
include('../../more/connect.php');
if(!$loggedIn) {
	header("Location: /");
}
?>
<?php require '../../more/Default.php'; ?>
<?php require '../../more/nav.php'; ?>
<div id="Body">
	<form action="updategame.php" method="post">
	<div id="EditItemContainer">
		<h2>Configure Place</h2>
		
		<div id="ItemName">
			<span style="font-weight: bold;">Name:</span><br>
			<input name="name" type="text" value="<?php echo $user->username ; ?>'s Place" maxlength="35" class="TextBox">
			<span style="color:Red;visibility:hidden;">A Name is Required</span>
		</div>
		<div class="GameThumbnail" style="text-align:center;">
			<a title="Brick Battle" style="cursor:pointer;"><img style="max-width:420px;border-color:black;" src="/images/HappyHomeBig.png" border="1" id="img" alt="CoolBloxCreatorCodex's Place"></a>
		</div>
		<div id="ItemDescription">
			<span style="font-weight: bold;">Description:</span><br>
			<textarea type="text" name="map" maxlength="200" rows="2" cols="20" class="TextBox" style="height:150px;width: 410px;padding: 5px;"></textarea>
		</div>
		<div id="Comments">
			<fieldset title="Max Players">
				<legend>Enter Port</legend>
				<div class="Suggestion">
					Please Enter port for your game
				</div>
				<div class="EnableCommentsRow" style="padding: 10px 4px 10px 4px;text-align: right;width:auto;">
					<input type="text" name="port" value="53640" class="TextBox" min="1" max="20">
				</div>
			</fieldset>
		</div>
		<div id="Comments">
			<fieldset title="Max Players">
				<legend>Please Enter ip</legend>
				<div class="Suggestion">
					Enter Radmin ip for your game
				</div>
				<div class="EnableCommentsRow" style="padding: 10px 4px 10px 4px;text-align: right;width:auto;">
					<input type="text" name="ip" class="TextBox" min="1" max="20" value=<?php print $_SERVER['REMOTE_ADDR']; ?>>
				</div>
			</fieldset>
		</div>
		<div class="Buttons">
			<input name="updateall" tabindex="4" class="Button" type="submit" value="Create">&nbsp;
			<a id="Cancel" tabindex="5" class="Button" href="/my/home">Cancel</a>
		</div>
	</div>
</form>
</div>