<?php
include '../../../more/connect.php';
if(!$loggedIn) {
	header("Location: /");
}
?>
<?php
if(empty($error)){
  if(isset($_POST['send']))
{
    $sql = "INSERT INTO wall (username, user_id, message, datee)
    VALUES ('".$username."','".$user->id."','".$_POST["message"]."', '".date("Y/m/d")."')";

    $result = mysqli_query($conn,$sql);
}
}

/*if(strlen($message) < 3 || strlen($message) > 200) {
        $error = '
        <div style="height: 0px;"></div>
       <div class="alert alert-primary" style="margin-bottom: 10px;" role="alert">
            Message needs to be between 3 and 200 characters.
        </div>';
    }*/

?>
<?php require '../../../more/Default.php'; ?>
<?php require '../../../more/nav.php'; ?>
        <div id="Body">

        	<div id="InboxContainer" style="float:left;">
        		<div id="InboxPane">
        			<h2>Inbox</h2>
        			<div id="Inbox" style="border: 0px;">
        				<div style="border: 1px solid; padding: 10px 10px 10px 10px;">
        					You have no messages in your inbox.
        				</div>
        				<div style="clear: both;"></div>
        				<div class="Buttons">
        					<a id="ctl00_cphRoblox_CancelHyperLink" class="Button" href="/my/home">Cancel</a>
        				</div>
        				<div style="clear: both;"></div>
        			</div>
        			<div style="clear: both;"></div>
        		</div>
        	</div>
        <div style="clear: both;">
        </div>
        </div>



      </div>
    </div>
  </div>
</div>
</div>
</div>
