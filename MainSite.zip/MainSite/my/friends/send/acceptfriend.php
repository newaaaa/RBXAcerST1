<?php
// $user->id this is current loggined use id
include '../../../more/connect.php';
if(!$loggedIn) {
    header("Location: /");
}
$id = trim($conn->real_escape_string($_GET['to']));

$select = $conn->query("SELECT * FROM friendsrequest WHERE id='$id'");
$item = mysqli_fetch_object($select);

if(!$id || !is_numeric($id)) {
    header("Location: /item/?id=1");
    die();
}else{
    $checkExists = $conn->query("SELECT * FROM friendsrequest WHERE id='$id'");
    $exists = mysqli_num_rows($checkExists);
    if($exists == 0) {
        header("Location: /404");
        die();
    }
}
// Test, buy script is easy, i need only make working check owned script. Help
if (mysqli_connect_errno())
{
    printf("Connect failed: %s\n", mysqli_connect_error());
}


if($item->friendid !== $user->id) {
    echo"FATAL ERROR";
}else{
$uid = mysqli_real_escape_string($conn,$user->id);
$uname = mysqli_real_escape_string($conn,$user->username);
$friendid = mysqli_real_escape_string($conn,$item->uid);
$friendname = mysqli_real_escape_string($conn,$item->uname);

$sql="INSERT INTO friends (uname, friendname, uid, friendid)

VALUES

('$uname', '$friendname', '$uid', '$friendid')";

if (!$conn->query($sql))
{
  printf("Error: %s\n", $conn->error);
}

$delsql="";

$conn->close();
header("Location: /my/friends/send/delete.php?id=$item->uid");
}
?>
