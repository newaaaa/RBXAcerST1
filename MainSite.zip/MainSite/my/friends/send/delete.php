<?php
include '../../../more/connect.php';
$RefreshRate = rand(0,100000);

include '../../../more/filter.php';
$id = trim($conn->real_escape_string($_GET['id']));

$select = $conn->query("SELECT * FROM friendsrequest WHERE friendid='".$user->id."'");
$item = mysqli_fetch_object($select);
?>
<?php
if($item->friendid = $user->id) {
if (mysqli_connect_errno())
{
    printf("Connect failed: %s\n", mysqli_connect_error());
}

$delsql="DELETE FROM friendsrequest WHERE friendid = $user->id AND uid = $item->uid";

$resultdel=$conn->query($delsql);
if (!$resultdel)
{
  printf("Error: %s\n", $conn->error);
}
$conn->close();
}else{
echo"error"; 
}
?>
<?php
header("Location: /my/home");
?>
