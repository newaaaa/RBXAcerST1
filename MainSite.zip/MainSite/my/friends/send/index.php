<?php
// $user->id this is current loggined use id
include '../../../more/connect.php';
if(!$loggedIn) {
    header("Location: /");
}
$id = trim($conn->real_escape_string($_GET['to']));

$checknew2 = $conn->query("SELECT * FROM friends WHERE uid='$user->id' AND friendid='$id'");
$CheckNew = mysqli_num_rows($checknew2);
if ($CheckNew > 0) {
 $sended = 1;
}
else {
 $sended = 0;
}

$select = $conn->query("SELECT * FROM users WHERE id='$id'");
$item = mysqli_fetch_object($select);

// Strange, this is work
$check = $conn->query("SELECT * FROM friendsrequest WHERE uid='$user->id' AND friendid='$id'");
$checkre = $conn->query("SELECT * FROM friendsrequest WHERE uid='$id' AND friendid='$user->id'");
$CheckNewf = mysqli_num_rows($checkre);
$CheckEnd = mysqli_num_rows($check);
if ($CheckEnd > 0) {
 $sender = 1;
}
else {
 $sender = 0;
}

if ($CheckNewf > 0) {
 $send = 1;
}
else {
 $send = 0;
}

if($send == 1) {
header("Location: /user/?id=$id");
}else{

if($sender == 1) {
header("Location: /user/?id=$id");
}else{
if(!$id || !is_numeric($id)) {
    header("Location: /");
    die();
}else{
    $checkExists = $conn->query("SELECT * FROM users WHERE id='$id'");
    $exists = mysqli_num_rows($checkExists);
    if($exists == 0) {
        header("Location: /404");
        die();
    }
}

if (mysqli_connect_errno())
{
    printf("Connect failed: %s\n", mysqli_connect_error());
}

if($user->id == $item->id) {
    $sended = 1;
}

if($sended == 0) {
$namefixed = mysqli_real_escape_string($conn,$_POST['name']);
$uid = mysqli_real_escape_string($conn,$user->id);
$uname = mysqli_real_escape_string($conn,$user->username);
$friendid = mysqli_real_escape_string($conn,$item->id);
$friendname = mysqli_real_escape_string($conn,$item->username);
$sql="INSERT INTO friendsrequest (uname, friendname, uid, friendid)

VALUES

('$uname', '$friendname', '$uid', '$friendid')";

if (!$conn->query($sql))
{
  printf("Error: %s\n", $con->error);
}

header("Location: /user/?id=$id");
$conn->close();
}
if($sended == 1) {
header("Location: /user/?id=$id");
}
}
}
?>