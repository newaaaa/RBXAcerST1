<?php
include '../../../more/connect.php';
if(!$loggedIn) {
	header("Location: /");
}
?>
<?php
if(empty($error)){
  if(isset($_POST['send']))
{
    $sql = "INSERT INTO wall (username, user_id, message, datee)
    VALUES ('".$username."','".$user->id."','".$_POST["message"]."', '".date("Y/m/d")."')";

    $result = mysqli_query($conn,$sql);
}
}
?>
<?php require '../../../more/Default.php'; ?>
<link id="ctl00_Favicon" rel="Shortcut Icon" type="image/ico" href="/favicon.ico"/>
<?php require '../../../more/nav.php'; ?>
<div id="Body">
  <style>
  body {
  font: normal 8pt/normal 'Comic Sans MS',Verdana,sans-serif;
  margin-top: 0;
  text-transform: none;
  text-decoration: none;
}
</style>
<div id="friendsContainer">
    <div id="friends">
        <?php $check = $conn->query("SELECT * FROM friends WHERE uid='$user->id' OR friendid='$user->id'");
$CheckEnd = mysqli_num_rows($check);
?>
        <h4>My friends (<?php echo $CheckEnd ; ?>)</h4>
		<div align='center'>
		    		<?php $check = $conn->query("SELECT * FROM friends WHERE uid='$user->id' OR friendid='$user->id'");
		$CheckEnd = mysqli_num_rows($check);
		if($CheckEnd == 0) {
		echo"<p style='padding: 10px 10px 10px 10px;'>You don't have any RBXAcer Friends.</p>";
		}else{
		}
		?>
					</div>
        <style>
    h4 {
    font-size: 10pt;
    font-weight: bold;
    line-height: 1em;
    margin-bottom: 5px;
    margin-top: 5px;
    }
        </style>
        <table cellspacing="0" align="Center" border="0">
            <tbody><tr>
              <?php
                                  $resultsperpage = 5;
                                  $check = mysqli_query($conn, "SELECT * FROM friends");
                                  $usercount = mysqli_num_rows($check);

                                  $numberofpages = ceil($usercount/$resultsperpage);

                                  if(!isset($_GET['page'])) {
                                      $page = 1;
                                  }else{
                                      $page = $_GET['page'];
                                  }

                                  $thispagefirstresult = ($page-1)*$resultsperpage;

                                  $check = mysqli_query($conn, "SELECT * FROM friends WHERE uid='$user->id' OR friendid='$user->id' LIMIT ".$thispagefirstresult.",".$resultsperpage);

                                  while($result = mysqli_fetch_array($check)) {

                      if($result['uid'] == $user->id){
                          $FriendId = $result['friendid'];
                          $FriendName = $result['friendname'];
                      } else {
                          $FriendId = $result['uid'];
                          $FriendName = $result['uname'];
                      }
                      if(!empty($FriendId)){
                      echo"<td>
                      <div>
							<div>
							<script>
										   function delete$FriendId() {

	       window.location.href='/my/friends/delete/?id=$FriendId'
	   }
									</script></div></div>
                      <div class='Friend' onmouseover='this.style.borderStyle='outset';this.style.margin='6px'' onmouseout='this.style.borderStyle='none';this.style.margin='10px'' style='border-style: none; margin: 10px;'>
                      <div class='Avatar'><a title='builderman' href='/user/?id=$Friendid' style='display:inline-block;cursor:pointer;'><iframe height='100' width='100' src='/api/getAvatar.php?id=$FriendId&amp;size=85' frameborder='0' scrolling='no'></iframe></a></div>
                      <div class='Summary'>
                      <span class='OnlineStatus'><img src='/images/OnlineStatusIndicator_IsOffline.gif' border='0'></span>
                      <span class='Name'><a href='/user/?id=$FriendId'>$FriendName</a></span>
                      </div>
                      <div class='Options'>
                      <input class='Button' name='Delete' onclick='delete$FriendId();' type='submit' value='Delete'>
                      </div>
                      </div>
                      </td>";
                                  }
                  else{

                                  }
                                  }
              ?>
                            </tr>
                            <tr>
              <?php
                                  $resultsperpage = 5;
                                  $check = mysqli_query($conn, "SELECT * FROM friends");
                                  $usercount = mysqli_num_rows($check);

                                  $numberofpages = ceil($usercount/$resultsperpage);

                                  if(!isset($_GET['page'])) {
                                      $page = 2;
                                  }else{
                                      $page = $_GET['page'];
                                  }

                                  $thispagefirstresult = ($page-1)*$resultsperpage;

                                  $check = mysqli_query($conn, "SELECT * FROM friends WHERE uid='$user->id' OR friendid='$user->id' LIMIT ".$thispagefirstresult.",".$resultsperpage);

                                  while($result = mysqli_fetch_array($check)) {

                      if($result['uid'] == $user->id){
                          $FriendId = $result['friendid'];
                          $FriendName = $result['friendname'];
                      } else {
                          $FriendId = $result['uid'];
                          $FriendName = $result['uname'];
                      }
                      if(!empty($FriendId)){
                      echo"<td>
                      <div>
							<div>
							<script>
										   function delete$FriendId() {

	       window.location.href='/my/friends/delete/?id=$FriendId'
	   }
									</script></div></div>
                      <div class='Friend' onmouseover='this.style.borderStyle='outset';this.style.margin='6px'' onmouseout='this.style.borderStyle='none';this.style.margin='10px'' style='border-style: none; margin: 10px;'>
                      <div class='Avatar'><a title='builderman' href='/user/?id=$Friendid' style='display:inline-block;cursor:pointer;'><iframe height='100' width='100' src='/api/getAvatar.php?id=$FriendId&amp;size=85' frameborder='0' scrolling='no'></iframe></a></div>
                      <div class='Summary'>
                      <span class='OnlineStatus'><img src='/images/OnlineStatusIndicator_IsOffline.gif' border='0'></span>
                      <span class='Name'><a href='/user/?id=$FriendId'>$FriendName</a></span>
                      </div>
                      <div class='Options'>
                      <input class='Button' name='Delete' onclick='delete$FriendId();' type='submit' value='Delete'>
                      </div>
                      </div>
                      </td>";
                                  }
                  else{

                                  }
                                  }
              ?>
                            </tr>
                            <tr>
              <?php
                                  $resultsperpage = 5;
                                  $check = mysqli_query($conn, "SELECT * FROM friends");
                                  $usercount = mysqli_num_rows($check);

                                  $numberofpages = ceil($usercount/$resultsperpage);

                                  if(!isset($_GET['page'])) {
                                      $page = 3;
                                  }else{
                                      $page = $_GET['page'];
                                  }

                                  $thispagefirstresult = ($page-1)*$resultsperpage;

                                  $check = mysqli_query($conn, "SELECT * FROM friends WHERE uid='$user->id' OR friendid='$user->id' LIMIT ".$thispagefirstresult.",".$resultsperpage);

                                  while($result = mysqli_fetch_array($check)) {

                      if($result['uid'] == $user->id){
                          $FriendId = $result['friendid'];
                          $FriendName = $result['friendname'];
                      } else {
                          $FriendId = $result['uid'];
                          $FriendName = $result['uname'];
                      }
                      if(!empty($FriendId)){
                      echo"<td>
                      <div>
							<div>
							<script>
										   function delete$FriendId() {

	       window.location.href='/my/friends/delete/?id=$FriendId'
	   }
									</script></div></div>
                      <div class='Friend' onmouseover='this.style.borderStyle='outset';this.style.margin='6px'' onmouseout='this.style.borderStyle='none';this.style.margin='10px'' style='border-style: none; margin: 10px;'>
                      <div class='Avatar'><a title='builderman' href='/user/?id=$Friendid' style='display:inline-block;cursor:pointer;'><iframe height='100' width='100' src='/api/getAvatar.php?id=$FriendId&amp;size=85' frameborder='0' scrolling='no'></iframe></a></div>
                      <div class='Summary'>
                      <span class='OnlineStatus'><img src='/images/OnlineStatusIndicator_IsOffline.gif' border='0'></span>
                      <span class='Name'><a href='/user/?id=$FriendId'>$FriendName</a></span>
                      </div>
                      <div class='Options'>
                      <input class='Button' name='Delete' onclick='delete$FriendId();' type='submit' value='Delete'>
                      </div>
                      </div>
                      </td>";
                                  }
                  else{

                                  }
                                  }
              ?>
                            </tr>
                            <tr>
              <?php
                                  $resultsperpage = 5;
                                  $check = mysqli_query($conn, "SELECT * FROM friends");
                                  $usercount = mysqli_num_rows($check);

                                  $numberofpages = ceil($usercount/$resultsperpage);

                                  if(!isset($_GET['page'])) {
                                      $page = 4;
                                  }else{
                                      $page = $_GET['page'];
                                  }

                                  $thispagefirstresult = ($page-1)*$resultsperpage;

                                  $check = mysqli_query($conn, "SELECT * FROM friends WHERE uid='$user->id' OR friendid='$user->id' LIMIT ".$thispagefirstresult.",".$resultsperpage);

                                  while($result = mysqli_fetch_array($check)) {

                      if($result['uid'] == $user->id){
                          $FriendId = $result['friendid'];
                          $FriendName = $result['friendname'];
                      } else {
                          $FriendId = $result['uid'];
                          $FriendName = $result['uname'];
                      }
                      if(!empty($FriendId)){
                      echo"<td>
                      <div>
							<div>
							<script>
										   function delete$FriendId() {

	       window.location.href='/my/friends/delete/?id=$FriendId'
	   }
									</script></div></div>
                      <div class='Friend' onmouseover='this.style.borderStyle='outset';this.style.margin='6px'' onmouseout='this.style.borderStyle='none';this.style.margin='10px'' style='border-style: none; margin: 10px;'>
                      <div class='Avatar'><a title='builderman' href='/user/?id=$Friendid' style='display:inline-block;cursor:pointer;'><iframe height='100' width='100' src='/api/getAvatar.php?id=$FriendId&amp;size=85' frameborder='0' scrolling='no'></iframe></a></div>
                      <div class='Summary'>
                      <span class='OnlineStatus'><img src='/images/OnlineStatusIndicator_IsOffline.gif' border='0'></span>
                      <span class='Name'><a href='/user/?id=$FriendId'>$FriendName</a></span>
                      </div>
                      <div class='Options'>
                      <input class='Button' name='Delete' onclick='delete$FriendId();' type='submit' value='Delete'>
                      </div>
                      </div>
                      </td>";
                                  }
                  else{

                                  }
                                  }
              ?>
                            </tr>
                            <tr>
              <?php
                                  $resultsperpage = 5;
                                  $check = mysqli_query($conn, "SELECT * FROM friends");
                                  $usercount = mysqli_num_rows($check);

                                  $numberofpages = ceil($usercount/$resultsperpage);

                                  if(!isset($_GET['page'])) {
                                      $page = 5;
                                  }else{
                                      $page = $_GET['page'];
                                  }

                                  $thispagefirstresult = ($page-1)*$resultsperpage;

                                  $check = mysqli_query($conn, "SELECT * FROM friends WHERE uid='$user->id' OR friendid='$user->id' LIMIT ".$thispagefirstresult.",".$resultsperpage);

                                  while($result = mysqli_fetch_array($check)) {

                      if($result['uid'] == $user->id){
                          $FriendId = $result['friendid'];
                          $FriendName = $result['friendname'];
                      } else {
                          $FriendId = $result['uid'];
                          $FriendName = $result['uname'];
                      }
                      if(!empty($FriendId)){
                      echo"<td>
                      <div>
							<div>
							<script>
										   function delete$FriendId() {

	       window.location.href='/my/friends/delete/?id=$FriendId'
	   }
									</script></div></div>
                      <div class='Friend' onmouseover='this.style.borderStyle='outset';this.style.margin='6px'' onmouseout='this.style.borderStyle='none';this.style.margin='10px'' style='border-style: none; margin: 10px;'>
                      <div class='Avatar'><a title='builderman' href='/user/?id=$Friendid' style='display:inline-block;cursor:pointer;'><iframe height='100' width='100' src='/api/getAvatar.php?id=$FriendId&amp;size=85' frameborder='0' scrolling='no'></iframe></a></div>
                      <div class='Summary'>
                      <span class='OnlineStatus'><img src='/images/OnlineStatusIndicator_IsOffline.gif' border='0'></span>
                      <span class='Name'><a href='/user/?id=$FriendId'>$FriendName</a></span>
                      </div>
                      <div class='Options'>
                      <input class='Button' name='Delete' onclick='delete$FriendId();' type='submit' value='Delete'>
                      </div>
                      </div>
                      </td>";
                                  }
                  else{

                                  }
                                  }
              ?>
                            </tr>
        </tbody></table>
    </div>
</div>
				</div>
        <?php require '../../../more/footer.php'; ?>
