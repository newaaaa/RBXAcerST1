<?php
include '../../../more/connect.php';
$RefreshRate = rand(0,100000);

include '../../../more/filter.php';
$id = trim($conn->real_escape_string($_GET['id']));
?>

<?php
if (mysqli_connect_errno())
{
    printf("Connect failed: %s\n", mysqli_connect_error());
}

if($fetchuser->friendid == $user->id){
$delsql="DELETE FROM friends WHERE friendid = $user->id AND uid = $id";
}else{
$delsql="DELETE FROM friends WHERE friendid = $id AND uid = $user->id";
}
$resultdel=$conn->query($delsql);
if (!$resultdel)
{
  printf("Error: %s\n", $conn->error);
}

$conn->close();
?>
<?php
header("Location: /my/home");
?>