<?php
	header("Location: /my/character/Hats");
?>
