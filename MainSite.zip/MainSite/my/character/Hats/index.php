<?php
include '../../../more/connect.php';
if(!$loggedIn) {
	header("Location: /");
}
?>
<?php
if(empty($error)){
  if(isset($_POST['send']))
{
    $sql = "INSERT INTO wall (username, user_id, message, datee)
    VALUES ('".$username."','".$user->id."','".$_POST["message"]."', '".date("Y/m/d")."')";

    $result = mysqli_query($conn,$sql);
}
}

/*if(strlen($message) < 3 || strlen($message) > 200) {
        $error = '
        <div style="height: 0px;"></div>
       <div class="alert alert-primary" style="margin-bottom: 10px;" role="alert">
            Message needs to be between 3 and 200 characters.
        </div>';
    }*/

?>
<?php require '../../../more/Default.php'; ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<?php require '../../../more/nav.php'; ?>
<div id="Body">
	<style>
	.clothe
	{
		width:110px;
		/*height: 200px;*/
		margin: 10px;
		text-align: left;

		vertical-align: top;
		display: inline-block;
		display: -moz-inline-stack;
		*display: inline;
	}
	.clothe .name {
		font-weight: bold;
	}
	.nocl
	{
		font-family: Verdana;
		font-weight: bold;
		text-align: center;
	}
	.img{
		border:none;
		height: 100%;
	}
	.imgc
	{
		border:1px solid black;
		width: 110px;
		height: 110px;
		text-align: center;
		padding: 10px;
		position: relative;
	}
	.fixed
	{
		position:absolute;
		right:0;
		top:0;
		background-color: #EEEEEE;
		border: 1px solid #555555;
		color: blue;
		font-family: Verdana;
		font-size: 10px;
		font-weight: lighter;
	}
	#left{
		width: 69%;
		float: left;
	}
	#right{
		width: 30%;
		float: right;
	}
	#Body table
	{
		border: 1px black solid;
	}
	.tablehead
	{
		font-size:16px; font-weight: bold; border-bottom:black 1px solid; width: 100%; background-color: #CCCCCC; color: #222222;
	}
	.tablebody
	{
		font-weight: lighter; background-color: transparent;font-family: Verdana;
	}
	.margin{
		margin:10px;
	}
	.clickable, .clickable3, .clickable2
	{
		border: none;
		margin:1px;
	}
	.clickable{
		width:50px;
		height: 50px;
	}
	.clickablesm{
		width:40px;
		height:40px;
		margin:5px;
	}
	.clickable2{
		width:47px;
		height: 100px;
	}
	.clickable3{
		width:100px;
		height: 100px;
	}
	.nonsbtn
	{
		font-weight:normal;
	}
	#col{
		position: fixed;
		top: 50%;
		left: 50%;
		margin-top: -105px;
		margin-left: -205px;
		width: 410px;
		height: 210px;
		z-index: 498;
		background-color: white;
		text-align: center;
		vertical-align: center;
	}
	.tablebody a {
	    color:blue;
	}
	.tablebody a:hover {
	    cursor:pointer;
	}
</style>
<div id="infoa"></div>
<div id="left">
	<table cellspacing="0px" width="100%" style="margin-bottom:10px;">
		<tbody><tr>
		    <th class="tablehead">My Wardrobe</th>
		</tr>
		<tr>
		    <td class="tablebody" style="font-size:12px; text-align: center; border-bottom: 1px solid black;">
		        <a id="btn2" href="../T-Shirts">T-Shirts</a>
		        |
		        <a id="btn5" href="../Shirts">Shirts</a>
		        |
		        <a id="btn6" href="../bodyp">Body Packages</a>
		        |
		        <a id="btn6" href="../Pants">Pants</a>
		        |
		        <a id="btn1" href="../Hats/?page=1" style="font-weight: bold;">Hats</a>
		        <br>
		        <a href="/catalog/Hats/?tr=Past Week">Shop</a>
		    </td>
		</tr>
		<tr>
		    <td class="tablebody">
		        <div id="wardrobe" style="padding-left:13px;">
							<?php
							                    $resultsperpage = 4;
							                    $check = mysqli_query($conn, "SELECT * FROM ownedhats WHERE creatorid='$user->id'");
							                    $usercount = mysqli_num_rows($check);

							                    $numberofpages = ceil($usercount/$resultsperpage);

							                    if(!isset($_GET['page'])) {
							                        $page = 1;
							                    }else{
							                        $page = $_GET['page'];
							                    }

							                    $thispagefirstresult = ($page-1)*$resultsperpage;

							                    $check = mysqli_query($conn, "SELECT * FROM ownedhats WHERE creatorid='$user->id' LIMIT ".$thispagefirstresult.",".$resultsperpage);

							                    while($row = mysqli_fetch_assoc($check)) {

							    $id = htmlspecialchars($row['itemid']);
							    $name = htmlspecialchars($row['creatorname']);

if($id !== "1001") {
									if($user->Hat == $id){
									echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
													<div id='$name' class='imgc' style='cursor:pointer;'><img class='img' src='/images/catalog/hats/id=$id.png'>
														<div class='fixed'><a href='/api/scripts/remove.php?id=$id'>[ remove ]</a></div>
													</div>
													<a class='name' href='/item/?id=$id'>$name</a><br>
													Type: Hat<br>
													Creator: <a href='/user/?id=13'>Codex</a>
												</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
									}else{
									echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
													<div id='$name' class='imgc' style='cursor:pointer;'><img class='img' src='/images/catalog/hats/id=$id.png'>
														<div class='fixed'><a href='/api/scripts/wear.php?id=$id'>[ wear ]</a></div>
													</div>
													<a class='name' href='/item/?id=$id'>$name</a><br>
													Type: Hat<br>
													Creator: <a href='/user/?id=13'>Codex</a>
												</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
							}
}else{
 									if($user->Hat == $id){
									echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
													<div id='$name' class='imgc' style='cursor:pointer;'><img class='img' src='/images/catalog/hats/id=$id.png'>
														<div class='fixed'><a href='/api/scripts/removef.php?id=$id'>[ remove ]</a></div>
													</div>
													<a class='name' href='/item/?id=$id'>$name</a><br>
													Type: Hat<br>
													Creator: <a href='/user/?id=13'>Codex</a>
												</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
									}else{
									echo"<div class='clothe' style='font-size:10.85px; display:inline-block; *display:inline; margin:5px; display: inline-block; display: -moz-inline-stack; *display: inline; vertial-align:top;'>
													<div id='$name' class='imgc' style='cursor:pointer;'><img class='img' src='/images/catalog/hats/id=$id.png'>
														<div class='fixed'><a href='/api/scripts/wearf.php?id=$id'>[ wear ]</a></div>
													</div>
													<a class='name' href='/item/?id=$id'>$name</a><br>
													Type: Hat<br>
													Creator: <a href='/user/?id=13'>Codex</a>
												</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
							}   
}

							    $_GET['username'] = $username;
							                    }


							                        echo "";


							                    for ($page=1;$page<=$numberofpages;$page++) {

							                        echo "";
							                    }

							                    echo "";
							                    ?>
																	<?php $checkt = $conn->query("SELECT * FROM ownedhats WHERE creatorid='$user->id'");
																	$CheckEnd = mysqli_num_rows($checkt);
																	if($CheckEnd == 0) {
																	echo"<tr>
		    <td class='tablebody'>
		        <div id='wardrobe' style='padding-left:13px;'>No Hats have been found.</div>
				<div style='clear:both;'></div>
			</td>
		</tr>";
																	}else{
																	    $test = $_GET['page'];
																		echo"<br>

																		<div class='tablebody' style='font-size:12px; text-align: center; border-top: 1px solid black; padding: 5px 0;'>
																		<a style='color:black;font-weight:bold;' href='/my/character/Hats/?page=1'>First</a>
										";
										if($test == "1") {
										echo"
																		<a style='color:black;font-weight:bold;' disabled=''>Previous</a>
																		<a style='color:black;font-weight:bold;' href='/my/character/Hats/?page=2'>Next</a>&nbsp;";
										}
										if($test == "2") {
										echo"
																		<a style='color:black;font-weight:bold;'  href='/my/character/Hats/?page=1'>Previous</a>

																		<a style='color:black;font-weight:bold;' disabled=''>Next</a>&nbsp;";
										}
										echo"<a style='color:black;font-weight:bold;' href='/my/character/Hats/?page=$numberofpages'>Last</a></div>";
																	}

																	?>
						</div>
				<div style="clear:both;"></div>
			</td>
		</tr>
	</tbody></table><div class="seperator"></div>
	<table cellspacing="0px" width="100%">
		<tbody><tr>
		    <th class="tablehead">Currently Wearing</th>
		</tr>
		<tr>
		    <td class="tablebody">
		        <div id="wearing" style="padding-left:13px;">
		          <?php require '../../../api/getWear.php'; ?>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
			</td>
		</tr>
	</tbody></table>
</div>
<div id="right">
	<table cellspacing="0px" width="100%">
		<tbody><tr><th class="tablehead">My Character</th></tr>
		<tr><th class="tablebody">
		<iframe height="220" width="200" src="/api/getAvatar.php?id=<?php echo $user->id ; ?>" frameborder="0" scrolling="no"></iframe>
		<img class="margin" id="uimg" src=""><br>Something wrong with your Avatar? Click <a href="/my/character/Hats/?page=1">here</a> to redraw it!</th></tr>
	</tbody></table>
</div>
<div style="clear:both;"></div>

<?php require '../../../more/footer.php'; ?>
</div>
