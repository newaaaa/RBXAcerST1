<?php
include('../../more/connect.php');
if(!$loggedIn) {
	header("Location: /");
}
?>
<?php require '../../more/Default.php'; ?>
<?php require '../../more/nav.php'; ?>
<?php
if (mysqli_connect_errno()) 
{
    printf("Connect failed: %s\n", mysqli_connect_error());
}

$namefixed = mysqli_real_escape_string($conn,$_POST['name']);
$player = mysqli_real_escape_string($conn,$user->id);
$playername = mysqli_real_escape_string($conn,$user->username);
$ipcrypt = base64_encode($_POST['ip']);
$sql="INSERT INTO gamesuser (name, map, ip, port, creatorname, creatorid)

VALUES

('$namefixed','$_POST[map]','$ipcrypt','$_POST[port]','$playername', '$player')";

if (!$conn->query($sql))
{
  printf("Error: %s\n", $con->error);
}

$conn->close();

$port=$_POST['port'];
$playerlimit=$_POST['playerlimit'];
?>
<script>window.location.href='/my/home'</script>