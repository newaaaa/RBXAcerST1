<?php
include '../../more/connect.php';
include '../../more/filter.php';
if(!$loggedIn) {
	header("Location: /");
}

$update = trim($conn->real_escape_string($_POST['update']));
if ($update) {
    $description = strip_tags($_POST['description']);
    $description = trim($conn->real_escape_string($description));
    $description = htmlentities($description);

    $conn->query("UPDATE users SET description='$description' WHERE id='$user->id'");

    $error = "<div style='color:red; text-align:center;'><center>Description updated.</center></div>";
}
?>
<?php require '../../more/Default.php'; ?>
<?php require '../../more/nav.php'; ?>
<div id="Body">
	<style>
	#EditProfileContainer {
    background-color: #eeeeee;
    border: 1px solid #000;
    color: #555;
    margin: 0 auto;
    width: 620px;
}
fieldset {
    font-size: 1.2em;
    margin: 15px 0 0 0;
}
</style>
	<form method="post" action="">
	<div id="EditProfileContainer">
		<h2>Edit Profile</h2>
		<div><span id="WrongOldPW" style="color:Red;"><br><?php
        if(!empty($error)){
            echo $error;
        }
        ?></span></div>
        <div id="ResetPassword">
			<fieldset title="Reset your password">
				<legend>Change your password</legend>
				<div class="Suggestion">Click the button below to change your password.</div>
				<div class="ResetPasswordRow">
					&nbsp;<a href="/Login/ChangePassword/">Change Password</a>
		    	</div>
			</fieldset>
		</div>
		<div id="Blurb">
			<fieldset title="Update your personal blurb">
				<legend>Update your personal blurb</legend>
				<div class="Suggestion">
					Describe yourself here (max. 100 characters).  Make sure not to provide any details that can be used to identify you outside RBXAcer.
				</div>
				<div class="Validators">

				</div>
				<div class="BlurbRow">
					<textarea maxlength="100" rows="8" name="description" cols="2" id="Blurb" tabindex="3" class="MultilineTextBox"></textarea>
				</div>
			</fieldset>
		</div>
		<div class="Buttons">
			<input name="csrf_token" value="48fa78a109e559b2d74d5a377d7f40d1" style="display:none;">
			<input id="Submit" tabindex="4" class="Button" type="submit" name="update" value="Update">&nbsp;<a id="Cancel" tabindex="5" class="Button" href="/my/home">Cancel</a>
		</div>
	</div>
</form>
<?php require '../../more/footer.php'; ?>
</div>
