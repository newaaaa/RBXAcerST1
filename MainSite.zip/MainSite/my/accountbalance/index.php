<?php
include '../../more/connect.php';
if(!$loggedIn) {
	header("Location: /");
}
?>
<?php
if(empty($error)){
  if(isset($_POST['send']))
{
    $sql = "INSERT INTO wall (username, user_id, message, datee)
    VALUES ('".$username."','".$user->id."','".$_POST["message"]."', '".date("Y/m/d")."')";

    $result = mysqli_query($conn,$sql);
}
}

/*if(strlen($message) < 3 || strlen($message) > 200) {
        $error = '
        <div style="height: 0px;"></div>
       <div class="alert alert-primary" style="margin-bottom: 10px;" role="alert">
            Message needs to be between 3 and 200 characters.
        </div>';
    }*/

?>
<?php require '../../more/Default.php'; ?>
<?php require '../../more/nav.php'; ?>
<div id="Body">
<div id="MyAccountBalanceContainer">
	<h2>My Account Balance</h2>
	<div id="AboutRobux">


		<h3>What are Robux?</h3>
		<p>Robux are the principle currency of RBXAcer. Citizens in the Builders Club receive a daily allowance of Robux to help them live a comfortable life of leisure. For this and other benefits, consider joining <a href="#">Builders Club (Only for Vip-Members)</a>! Alternately, you can <a href="#">get Robux</a> if you wish by wait for Robux and tix.</p>
		<h3>What are Tickets?</h3>
		<p>RBXAcern Tickets are similar to tickets you win in an arcade. You play the game, get tickets, and are rewarded with fabulous prizes. Tickets are granted to citizens who are helping to expand and improve RBXAcer. The primary way to get tickets is to make a cool place, and then get people to visit it. You can also get the daily login bonus, just by showing up!</p>
		<h3>Where do I buy things?</h3>
		<p>Browse the <a id="ctl00_cphRoblox_CatalogHyperLink" href="/catalog">RBXAcer Catalog</a></p>
	</div>
	<div id="Earnings">
		<h3>Earnings</h3>
		<div>
      <br>
			<div class="Label"></div>
			<div class="Field"><img id="ctl00_cphRoblox_RobuxIcon" src="/images/Robux.png" alt="Robux" style="border-width:0px;"></div>
			<div class="Field"><img id="ctl00_cphRoblox_TicketsIcon" src="/images/Tickets.png" alt="Tickets" style="border-width:0px;"></div>
		</div>
		<div class="Earnings_Period">
			<h4>Past Day</h4>
			<div class="Earnings_LoginAward">
				<div class="Label">Login Award</div>
				<div class="Field">0</div>
				<div class="Field">0</div>
			</div>
			<div class="Earnings_PlaceTrafficAward">
				<div class="Label">Place Traffic Award</div>
				<div class="Field">0</div>
				<div class="Field">0</div>
			</div>
			<div class="Earnings_SaleOfRobux">
				<div class="Label">?</div>
				<div class="Field">0</div>
				<div class="Field">0</div>
			</div>
			<div class="Earnings_SaleOfRobux">
				<div class="Label"></div>
				<div class="Field">0</div>
				<div class="Field">0</div>
			</div>
			<div class="Earnings_PeriodTotal">
				<div class="Label">Total:</div>
				<div class="Field">0</div>
				<div class="Field">0</div>
			</div>
		</div>
		<div class="Earnings_Period">
			<h4>All Time</h4>
			<div class="Earnings_LoginAward">
				<div class="Label">Login Award</div>
				<div class="Field">0</div>
				<div class="Field">20</div>
			</div>
			<div class="Earnings_PlaceTrafficAward">
				<div class="Label">Place Traffic Award</div>
				<div class="Field">0</div>
				<div class="Field">0</div>
			</div>
			<div class="Earnings_SaleOfRobux">
				<div class="Label"><br></div>
				<div class="Field">0</div>
				<div class="Field">0</div>
			</div>
			<div class="Earnings_SaleOfRobux">
				<div class="Label"><br></div>
				<div class="Field">0</div>
				<div class="Field">0</div>
			</div>
			<div class="Earnings_PeriodTotal">
				<div class="Label">Total:</div>
				<div class="Field"><?php echo $user->tokens ; ?></div>
				<div class="Field"><?php echo $user->coins ; ?></div>
			</div>
		</div>
	</div>
</div>
<div style="clear:both;"></div>
<?php require '../../more/footer.php'; ?>
</div>
