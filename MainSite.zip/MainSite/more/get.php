<div id='VerifyPurchaseTix' style='margin: 1.5em; display: block;'>
				<h3>Purchase Item:</h3><br>
				<p>Would you like to purchase Hat $fetchuser->username from RBXAcer for $fetchuser->tixrobuxsell?</p>
				<p>Your balance Tix: $tix.</p>
				<p>Your balance Robux: $user->tokens.</p>
				<br>
				<input type='submit' value='Buy Now!' onclick='getHat()' class='MediumButton' style='width:100%;'>
				<br><br>
				<input type='submit' name='oof' value='Cancel' onclick='$(&#39;#itemPurchaseFade&#39;).hide();' class='MediumButton' style='width:100%;'>
			</div>