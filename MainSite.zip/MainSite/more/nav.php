<div id="Header">
		<div id="Banner">
			<div id="Options">
				<div id="Authentication">
					<span><a id="ctl00_lsLoginStatus"><span>Logged in as <?php echo $username ; ?>&nbsp;<strong>|</strong>&nbsp;<a href="/../logout.php">Logout</a></span></a></span>
				</div>
				<div id="Settings">
<span>Age: 13+, Safety Mode: Filter</span>
				</div>
			</div>
			<div id="Logo"><a id="ctl00_rbxImage_Logo" title="RBXAcer" href="/" style="display:inline-block;cursor:pointer;"><img src="/../images/RBXAcer_Logo.png" border="0" id="img" alt="RBXAcer " blankurl="http://t2.RBXAcer.com:80/blank-267x70.gif"/></a>
			</div>
			<div id="Alerts">
		<table style="width:123%;height:101%">
			<tbody><tr>
				<td valign="middle">

					<div>
						<div id="AlertSpace">
							<div>
								<div id="TicketsAlert">
									<a class="TicketsAlertIcon"><img src="/images/Tickets.png" style="border-width:0px;"></a>&nbsp;
									<a class="TicketsAlertCaption"><?php echo $user->coins ; ?> Currency1</a>
								</div>
								<div id="RobuxAlert">
									<a class="TicketsAlertIcon"><img src="/images/Robux.png" style="border-width:0px;"></a>&nbsp;
									<a class="TicketsAlertCaption"><?php echo $user->tokens ; ?> Currency2</a>
								</div>
				</div>
						</div>
					</div>
				</td>
						</tr>
					</tbody></table>
				</div>
					</div>
<div class="Navigation">
  <span><a id="ctl00_hlMyRBXAcer" class="MenuItem" href="/">My RBXAcer</a></span>
  <span class="Separator">&nbsp;|&nbsp;</span>
  <span><a id="ctl00_hlGames" class="MenuItem" href="/games?tr=Past%20Day&m=Most%20Popular">Games</a></span>
  <span class="Separator">&nbsp;|&nbsp;</span>
  <span><a id="ctl00_hlCatalog" class="MenuItem" href="/catalog/Hats/?tr=Past Week">Catalog</a></span>
  <span class="Separator">&nbsp;|&nbsp;</span>
  <span><a id="ctl00_hlBrowse" class="MenuItem" href="/browse">Browse</a></span>
  <span class="Separator">&nbsp;|&nbsp;</span>
    <span><a id="ctl00_hlForum" class="MenuItem" href="/Forum/Default">Forum</a></span>
  <span class="Separator">&nbsp;|&nbsp;</span>
  <span><a id="ctl00_hlNews" class="MenuItem" href="https://blog.coolblox.net/" target="_blank">News</a>&nbsp;<a id="ctl00_hlNewsFeed" href="https://blog.coolblox.net/" target="_blank"><img src="/../images/feed-icons/feed-icon-14x14.png" alt="RSS" border="0"/></a></span>
</div>
<style>
body {
    font: normal 8pt/normal 'Comic Sans MS',Verdana,sans-serif;
}
.SystemAlert {
    background-color: #FFF;
    text-align: center;
    color: #FFF;
    border: 2px solid #000;
    font: normal 8pt/normal 'Comic Sans MS' , Verdana, sans-serif;
    padding: 1px;
    border-top: 1.9px black solid;
}
.SystemAlertText {
    font: normal 8pt/normal 'Comic Sans MS' , Verdana, sans-serif;
    font-size: 16px;
    font-weight: bold;
    padding: 2px;
}
.Exclamation {
    background: url(/images/exclamation.png) no-repeat;
    font: normal 8pt/normal 'Comic Sans MS' , Verdana, sans-serif;
    height: 16px;
    width: 16px;
    float: left;
}
.right-content {
    float: left;
    width: 792px;
    margin-left: -1px;
    padding-left: 20px;
    z-index: 1;
    position: relative;
}
.divider-left {
    border-left: 1px solid #ccc;
}
</style>
<div class="SystemAlert">
					<div class="SystemAlertText" style="background-color: #FFA200">
						<div class="Exclamation">
						</div>
						<div>Maintenance is currently active. Expect site to go down often.</div>
					</div>
				</div>
<div class="SystemAlert">
					<div class="SystemAlertText" style="background-color: #6696f0">
						<div class="Exclamation">
						</div>
						<div>Welcome to SiteTest1!</div>
					</div>
				</div>
<div class="SystemAlert">
					<div class="SystemAlertText" style="background-color: red">
						<div class="Exclamation">
						</div>
						<div>Install RBXAcer: <a href="https://sitetest1.rbxacerlabs.ga/install">link lol</a></div>
					</div>
				</div>
</div>
<body>