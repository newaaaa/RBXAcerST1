<div id="Footer">
<hr/>
<p class="Legalese">
RBXAcer, "Online Building Toy", characters, logos, names, and all related indicia
are trademarks of
<a>RBXAcer Corporation</a>,
©2020<br/>
RBXAcer Corp. is not affliated with Lego, MegaBloks, Bionicle, Pokemon, Nintendo, Lincoln Logs, Yu Gi Oh, K'nex, Tinkertoys, Erector Set, or the Pirates of the Caribbean. ARrrr!<br/>
Use of this site signifies your acceptance of the <a href="/info/terms">Terms and Conditions</a>.
			 <br><a href="/info/privacy">Privacy Policy</a>
        &nbsp;|&nbsp; <a href="/info/about">About Us</a>
        &nbsp;|&nbsp; <a href="https://discord.gg/VnR6pZ3fEJ">Discord</a>
</div>
