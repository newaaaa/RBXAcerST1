<?php
$host = "localhost";
$user = "kmcd102_rbxacerlabs";
$pass = "~}Xpp6a5fB3#";
$name = "kmcd102_sitetest1r";



$conn = new MySQLi($host, $user, $pass, $name);

if ($conn->connect_errno) {
    die("ERROR : -> " . $conn->connect_error);
}
/* Not needed.
 if(!$conn) {
	die("Database Error");
}
*/

	if ($_SERVER['SERVER_PORT'] == 80) {
		header("Location: https://sitetest1.rbxacerlabs.ga ".$_SERVER['REQUEST_URI']);
		exit;
	}
	
	if ($_SERVER['HTTP_HOST'] != "sitetest1.rbxacerlabs.ga") {
		header("Location: https://sitetest1.rbxacerlabs.ga".$_SERVER['REQUEST_URI']);
		exit;
	}
	
if(session_status() == PHP_SESSION_NONE) {
	session_name("RBXAcer");
	session_start();
}

$loggedIn = isset($_SESSION['id']);

$query = $conn->query("SELECT * FROM users WHERE id=" . $_SESSION['id']);
$userRow = mysqli_fetch_array($query);

$CurrentUser = $conn->query("SELECT * FROM users WHERE id='".$userRow['id']."'");
$user = mysqli_fetch_object($CurrentUser);
?>
