<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" id="www-coolblox-net">
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<title>
	RBXAcer: A FREE Virtual World-Building Game with Avatar Chat, 3D Environments, and Physics
</title>
<link id="ctl00_Imports" rel="stylesheet" type="text/css" href="/CSS/AllCSS.ashx.css"/><link id="ctl00_Favicon" rel="Shortcut Icon" type="image/ico" href="/favicon.ico"/><meta name="author" content="RBXAcer Corporation"/><meta name="description" content="RBXAcer is SAFE for kids! RBXAcer is a FREE casual virtual world with fully constructible/desctructible 3D environments and immersive physics. Build, battle, chat, or just hang out."/><meta name="keywords" content="game, video game, building game, construction game, online game, LEGO game, LEGO, MMO, MMORPG, virtual world, avatar chat."/></head>
	<body>
<div id="Container">
<div id="AdvertisingLeaderboard">
</div>