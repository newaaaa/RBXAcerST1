<?php
include 'catalogconnect.php';
if(!$loggedIn) {
	header("Location: /");
}
$RefreshRate = rand(0,100000);

include '../more/filter.php';
$id = trim($conn->real_escape_string($_GET['id']));

if(!$id || !is_numeric($id)) {
    header("Location: /more/test.php?id=1");
    die();
}else{
    $checkExists = $conn->query("SELECT * FROM `catalog` WHERE `id`='$id'");
    $exists = mysqli_num_rows($checkExists);
    if($exists == 0) {
        header("Location: /404");
        die();
    }
}

$select = $conn->query("SELECT * FROM catalog WHERE id='".$id."'");
$fetchuser = mysqli_fetch_object($select);


if ($fetchuser == 0) {
    header("Location: ../");
}

if($fetchuser->username !== $user->username) {
$updateviews = $conn->query("UPDATE `users` SET `profile_views` = `profile_views` + 1 WHERE username = '$fetchuser->username'");
}

$getUviews = $conn->query("SELECT `profile_views` FROM `users` WHERE username = '$fetchuser->username'");

while($row = mysqli_fetch_array($getUviews)) {
    $profileviews = $row['profile_views']; //$db-query("SELECT `profile_views` FROM `users` WHERE username='$fetch_user->username'");
}

?>
<?php
if($fetchuser->id == "1") {
if ("10" > $user->coins) {
  echo "I fixed free hat!";
  }
  else {
        $Coinsdelete = time();
if ($tix == $fetchuser->Face) {
    echo "This glitch for free gear fixed, go away!";
}
else {
if ($Coinsdelete) {
    $testsmall = $Coinsdelete + 86400;
    if($user->membership == 'Admin') {
        $inven = 0;
        $CoinsToDel = $fetchuser->value;
    }else{
        $inven = 0001;
        $CoinsToDel = $fetchuser->value;
    if($badge == 1) { 
    $inventoryid1 = "100$badge";
    }
    else { 
    $inventoryid1 = 0;
    }
    if($badge == 2) { 
    $inventoryid2 = "100$badge";
    }
    else { 
    $inventoryid2 = 0;
    }
    $inventorytest = $inventoryid1 + $inventoryid2;
    }
    $conn->query("UPDATE `users` SET `power` = power + ".$inventorytest." WHERE `users`.`id` = '$user->id'");
    $conn->query("UPDATE users SET $fetchuser->valute = $fetchuser->valute - ".$CoinsToDel." WHERE id = '$user->id'");
    $conn->query("UPDATE users SET gettc = '$testsmall' WHERE id ='$user->id'");
  }
  }
  header("Location: /item/?id=$badge");
  }
}
        ?>
<?php
if($fetchuser->id == "2") {
if ($user->tokens < "4") {
  echo "I fixed free hat!";
  }
  else {
        $Coinsdelete = time();
if ($tix == $fetchuser->Face) {
    echo "This glitch for free gear fixed, go away!";
}
else {
if ($Coinsdelete) {
    $testsmall = $Coinsdelete + 86400;
    if($user->membership == 'Admin') {
        $inven = 0;
        $CoinsToDel = $fetchuser->value;
    }else{
        $inven = 0001;
        $CoinsToDel = $fetchuser->value;
    if($badge == 1) { 
    $inventoryid1 = 1001;
    }
    else { 
    $inventoryid1 = 0;
    }
    if($badge == 2) { 
    $inventoryid2 = 1002;
    }
    else { 
    $inventoryid2 = 0;
    }
    $inventorytest = $inventoryid1 + $inventoryid2;
    }
    $conn->query("UPDATE `users` SET `power` = power + ".$inventorytest." WHERE `users`.`id` = '$user->id'");
    $conn->query("UPDATE users SET $fetchuser->valute = $fetchuser->valute - ".$CoinsToDel." WHERE id = '$user->id'");
    $conn->query("UPDATE users SET gettc = '$testsmall' WHERE id ='$user->id'");
  }
  }
  header("Location: /item/?id=$badge");
  }
}
        ?>