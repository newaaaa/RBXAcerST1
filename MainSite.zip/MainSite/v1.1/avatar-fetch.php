<?php
include '../more/connect.php';
$RefreshRate = rand(0,100000);

include '../more/filter.php';
$id = trim($conn->real_escape_string($_GET['id']));

if(!$id || !is_numeric($id)) {
    header("Location: /api/getAvatar.php?id=1");
    die();
}else{
    $checkExists = $conn->query("SELECT * FROM `users` WHERE `id`='$id'");
    $exists = mysqli_num_rows($checkExists);
    if($exists == 0) {
        echo"<img src='/images/ERROR.png'>";
    }
}

$select = $conn->query("SELECT * FROM users WHERE id='".$id."'");
$fetchuser = mysqli_fetch_object($select);

if($fetchuser->username !== $user->username) {
$updateviews = $conn->query("UPDATE `users` SET `profile_views` = `profile_views` + 1 WHERE username = '$fetchuser->username'");
}

$getUviews = $conn->query("SELECT `profile_views` FROM `users` WHERE username = '$fetchuser->username'");

while($row = mysqli_fetch_array($getUviews)) {
    $profileviews = $row['profile_views']; //$db-query("SELECT `profile_views` FROM `users` WHERE username='$fetch_user->username'");
}
?>
<?php
echo"http://rbxacer.ga/Game/shirts/21324321545243.rbxm;";
				        if($fetchuser->Hat == "1"){
				        echo"http://www.areblok.cf/asset/?id=200;";
				        }
				        if($fetchuser->Hat == "2"){
				        echo"http://www.areblok.cf/asset/?id=205;";
				        }
				        if($fetchuser->Hat == "3"){
				        echo"http://www.areblok.cf/asset/?id=203;";
				        }
				        if($fetchuser->tshirt == "1"){
				        echo"http://www.areblok.cf/asset/?id=1028595;";
				        }
				        if($fetchuser->Hat == "4"){
				        echo"http://www.areblok.cf/asset/?id=1285307;";
				        }
				        if($fetchuser->Hat == "5"){
				        echo"http://www.areblok.cf/asset/?id=1483632;";
				        }
				        if($fetchuser->Hat == "6"){
				        echo"http://www.areblok.cf/asset/?id=1081366;";
				        }
				        if($fetchuser->Hat == "7"){
				        echo"http://www.areblok.cf/asset/?id=1029025;";
				        }
				        if($fetchuser->id == "13"){
				        echo"http://rbxacer.ga/Game/hats/teapot/teapotnew.rbxm;";
				        }
								if($fetchuser->shirt == "1"){
				        echo"http://www.areblok.cf/asset/?id=207;";
								}
								if($fetchuser->shirt == "2"){
				        echo"http://www.areblok.cf/asset/?id=209;";
				        }
				        if($fetchuser->shirt == "3"){
				        echo"http://www.areblok.cf/asset/?id=211;";
				        }
								if($fetchuser->power == "1"){
				        echo"http://www.areblok.cf/asset/?id=213;";
				        }
								if($fetchuser->power == "2"){
				        echo"http://www.areblok.cf/asset/?id=215;";
				        }
								if($fetchuser->power == "3"){
				        echo"http://www.areblok.cf/asset/?id=217;";
				        }
				        if($fetchuser->power == "4"){
				        echo"http://www.areblok.cf/asset/?id=144076760;";
				        }
				        if($fetchuser->Hat == "6"){
				        echo"";
				        }
				        if($fetchuser->bodyp == "1"){
				        echo"http://www.reblok.xyz/asset/?id=1059;";
				        }
				        if($fetchuser->bodyp == "2"){
				        echo"http://www.areblok.cf/asset/?id=218;";
				        }
				        if($fetchuser->necka == "1"){
				        echo"http://www.areblok.cf/asset/?id=206;";
				        }
				        if($fetchuser->Hat == "8"){
				        echo"http://www.areblok.cf/asset/?id=1080951;";
				        }
				        if($fetchuser->Hat == "9"){
				        echo"http://www.areblok.cf/asset/?id=63690008;";
				        }
				        if($fetchuser->shirt == "4"){
				        echo"http://www.areblok.cf/asset/?id=144076358;";
				        }
