<?php
include '../more/connect.php';
include '../more/filter.php';

if(isset($_POST['sign_up'])){
$username = strip_tags($_POST['username']);
$username = trim($conn->real_escape_string($username));
$username = htmlentities($username);
$username = filter($username);

$password = strip_tags($_POST['password']);
$password = trim($conn->real_escape_string($password));
$password = htmlentities($password);

$passwordCon = strip_tags($_POST['passwordCon']);
$passwordCon = trim($conn->real_escape_string($passwordCon));
$passwordCon = htmlentities($passwordCon);

$key = strip_tags($_POST['invitekey']);

$email = strip_tags($_POST['email']);
$email = trim($conn->real_escape_string($email));
$email = htmlentities($email);    $ip = $_SERVER['REMOTE_ADDR'];

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

  if(strlen($username) < 3 || strlen($username) > 25) {
        $error = '
        <div style="color:red; text-align:center;"><center>Your username needs to be between 3 & 25 Characters!</center></div>';
    }

 if(preg_match("/∞([%$#*]+)/", $username)) {
	$error = '<div style="color:red; text-align:center;"><center>Dont put symbols in the username.
        </center>
  ';
  }

  if(preg_match("jayer", $username)) {
  $error = '<div style="color:red; text-align:center;"><center>
          Dont put symbols in the username.
        </center></div>
  ';
  }

    if(substr($username,-1) == " " || substr($username,0,1) == " ") {
        $error = '<div style="color:red; text-align:center;"><center>Dont put spaces at the beggining or end of the username.
        </center></div>
        ';
    }

    $email = mysqli_real_escape_string($conn,$_POST['email']);
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			$error = '<div style="color:red; text-align:center;"><center>
          Invalid email.
        </center></div>
      ';
		}

    if($password !== $passwordCon){
        $error = '
            <div style="color:red; text-align:center;"><center>
          Two passwords do not match. They must be the same.
        </center></div>
        ';
    }
    
    $vkey = 'st1key';
    if($key !== $vkey){
        $error = '
            <div style="color:red; text-align:center;"><center>
          Invalid Admin Key.
        </center></div>
        ';
    }

    $checkUsernameQ = "SELECT * FROM users WHERE username = '$username'";
    $checkUsername = $conn->query($checkUsernameQ);

    if($checkUsername->num_rows > 0){
        $error = '
            <div style="color:red; text-align:center;"><center>
          That username is already taken! Try with another one.
        </div>
        ';
    }


    if(empty($error)){
	$timeD = time();
        $create = "INSERT INTO users (username, password, email, coins, power, description, verified, status, Ip, gettc, lastflood, membership, theme, profile_views, join_date, now) VALUES ('$username','$hashed_password','$email','10','0','','0','[STATUS]','$ip','0','0','none','default','0', '$timeD','0')";
        $createUser = $conn->query($create);
        $error = '
            <div style="color:red; text-align:center;"><center>
          Success!
          </center></div>
        ';
    }
}
?>
<style type="text/css">
body {
  margin-top:0 !important;
  padding-top:0 !important;
  /*min-width:800px !important;*/
}
</style>
<?php require '../more/Default.php'; ?>
				<div id="Header">
					<div id="Banner">
						<div id="Options">
					<div style="top: 0px; left: 0px; padding: 4px; position: absolute;">
						<span><a href="/Login">Login</a></span>
					</div>
				</div>
						<div id="Logo"><a id="ctl00_Image1" title="RBXAcer" href="/" style="display:inline-block;cursor:hand;"><img src="/images/RBXAcer_Logo.png" border="0" id="img" blankurl="http://t2.roblox.com:80/blank-267x70.gif"></a></div>
					</div>
				</div>
				<div id="Body">
	
          <?php
                  if(!empty($error)){
                      echo $error;
                  }
                  ?>
<form method="POST" action="">
		<div id="Registration">
			<div id="ctl00_cphRoblox_upAccountRegistration">

					<h2>Sign Up and Play</h2>
					<h3>Step 1 of 1: Create Account</h3>
					<div id="EnterUsername">
						<fieldset title="Choose a name for your RBXAcer character">
							<legend>Choose a name for your RBXAcer character</legend>
							<div class="Suggestion">
								Use 3-20 alphanumeric characters: A-Z, a-z, 0-9, no spaces
							</div>
							<div class="Validators">
								<div></div>
								<div></div>
								<div></div>
								<div></div>
								<div></div>
							</div>
							<div class="UsernameRow">
								<label for="ctl00_cphRoblox_UserName" id="ctl00_cphRoblox_UserNameLabel" class="Label">Character Name:</label>&nbsp;<input type="text" name="username" tabindex="1" class="TextBox">
							</div>
						</fieldset>
					</div>
					<div id="EnterPassword">
						<fieldset title="Choose your RBXAcer password">
							<legend>Choose your RBXAcer password</legend>
							<div class="Suggestion">
								4-10 characters, no spaces
							</div>
							<div class="Validators">
								<div></div>
								<div></div>
								<div></div>
								<div></div>
							</div>
							<div class="PasswordRow">
								<label for="ctl00_cphRoblox_Password" id="ctl00_cphRoblox_LabelPassword" class="Label">Password:</label>&nbsp;<input type="password" name="password" id="ctl00_cphRoblox_Password" tabindex="2" class="TextBox">
							</div>
							<div class="ConfirmPasswordRow">
								<label for="ctl00_cphRoblox_TextBoxPasswordConfirm" id="ctl00_cphRoblox_LabelPasswordConfirm" class="Label">Confirm Password:</label>&nbsp;<input type="password" name="passwordCon" id="ctl00_cphRoblox_TextBoxPasswordConfirm" tabindex="3" class="TextBox">
							</div>
						</fieldset>
					</div>
          <div id="EnterInviteKey">
						<fieldset title="Provide your Invite Key">
							<legend>Provide your Invite Key</legend>
							<div class="Suggestion">
								Enter Invite Key
							</div>
							<div class="Validators">
								<div></div>
								<div></div>
								<div></div>
								<div></div>
							</div>
							<div class="EmailRow">
								<label for="ctl00_cphInviteKey" id="ctl00_cphRoblox_LabelInviteKey" class="Label">Admin Key:</label>&nbsp;<input type="text" name="invitekey" id="ctl00_cphinvitekey" tabindex="2" class="TextBox">
							</div>
						</fieldset>
					</div>
					<div id="EnterEmail">
						<fieldset title="Provide your email address">
							<legend>Provide your email address</legend>
							<div class="Suggestion">
								We need to verify you.
							</div>
							<div class="Validators">
								<div></div>
								<div></div>
							</div>
							<div class="EmailRow">
								<label for="ctl00_cphRoblox_TextBoxEMail" id="ctl00_cphRoblox_LabelEmail" class="Label">Your Email:</label>&nbsp;<input type="text" name="email" id="ctl00_cphRoblox_TextBoxEMail" tabindex="4" class="TextBox">
							</div>
						</fieldset>
					</div>
					<div class="Confirm">
						<input href="#" type="submit" name="sign_up" value="Register" class="BigButton">
					</div>

</div>
		</div>
  </form>
		<div id="Sidebars">
			<div id="AlreadyRegistered">
				<h3>Already Registered?</h3>
				<p>If you just need to login, go to the <a id="ctl00_cphRoblox_HyperLinkLogin" href="/Login">Login</a> page.</p>
				<p>If you have already registered but you still need to download the game installer, go directly to <a id="ctl00_cphRoblox_HyperLinkDownload" href="/install/RBXAcer.exe">download</a>.</p>
			</div>
			<div id="TermsAndConditions">
				<h3>Terms &amp; Conditions</h3>
				<p>Registration does not provide any guarantees of service. See our <a>Terms of Service</a> and <a>Licensing Agreement</a> for details.</p>
				<p>RBXAcer will not share your email address with 3rd parties. See our <a>Privacy Policy</a> for details.</p>
			</div>
		</div>
		<div id="ctl00_cphRoblox_ie6_peekaboo" style="clear: both"></div>

				</div>
				<?php require '../more/footer.php'; ?>
			</div>


        <script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>

        <script type="text/javascript">_uacct="UA-486632-1"; _udn="coolblox.net"; urchinTracker(); __utmSetVar('Visitor/Anonymous');</script>




<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEWDALL+oj3DwLJkK28AQLIkK28AQLG/4fSDQKE6ZusCALXpOCmBAKSpqybAwL+hoiUBwKa1tDYBwK3uZGsCQKEhOyWAwLm0ND0CGXCOx8sBzG++DWJChg75+Pd38gO">

<script type="text/javascript">
<!--
Roblox.Controls.Image.IE6Hack($get('ctl00_Image1'));Sys.Application.initialize();
// -->
</script>
</body></html>