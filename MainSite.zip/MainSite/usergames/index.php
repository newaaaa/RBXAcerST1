<?php
if($test = "") {
    header("Location: /games/?tr=Past%20Day&m=Most%20Popular");
}
$test = $_GET['tr']
?>
<?php
if($m = "") {
    header("Location: /games/?tr=Past%20Day&m=Most%20Popular");
}
$m = $_GET['m']
?>
<?php
include('../more/connect.php');
if(!$loggedIn) {
	header("Location: /");
}
?>
<?php require '../more/Default.php'; ?>
<?php require '../more/nav.php'; ?>
<div id="Body">


    <div id="GamesContainer">

<div id="ctl00_cphRoblox_rbxGames_GamesContainerPanel">

    <div class="DisplayFilters">
	    <h2>Games&nbsp;<a id="ctl00_cphRoblox_rbxGames_hlNewsFeed"><img src="/images/feed-icon-14x14.png" alt="RSS" border="0"></a></h2>
	    <div id="BrowseMode">
		    <h4>Browse</h4>
		    <ul>
			    <?php require './cat.php'; ?>
		    </ul>
	    </div>
<?php require './more/cat.php'; ?>
    </div>
    <div id="Games">
        <span id="ctl00_cphRoblox_rbxGames_lGamesDisplaySet" class="GamesDisplaySet"><?php echo $m ; ?> (<?php echo $test ; ?>)</span>
        <div id="ctl00_cphRoblox_rbxGames_HeaderPagerPanel" class="HeaderPager">

	        <span id="ctl00_cphRoblox_rbxGames_FooterPagerLabel">Page 1 of 1</span>
	    </div>
        <table id="ctl00_cphRoblox_rbxGames_dlGames" cellspacing="0" align="Center" border="0" width="550">
		<tbody>
		    <tr>
<?php
$resultsperpage = 3;
                    $check = mysqli_query($conn, "SELECT * FROM gamesuser");
                    $usercount = mysqli_num_rows($check);

                    $numberofpages = ceil($usercount/$resultsperpage);

                    if(!isset($_GET['page'])) {
                        $page = 1;
                    }else{
                        $page = $_GET['page'];
                    }

                    $thispagefirstresult = ($page-1)*$resultsperpage;

                    $check = mysqli_query($conn, "SELECT * FROM gamesuser LIMIT ".$thispagefirstresult.",".$resultsperpage);

                    while($row = mysqli_fetch_assoc($check)) {

    $username = htmlspecialchars($row['creatorname']);
    $userid = htmlspecialchars($row['creatorid']);
    $id = htmlspecialchars($row['id']);
    $name = htmlspecialchars($row['name']);
    $views = htmlspecialchars($row['views']);
    $date = htmlspecialchars($row['date']);

           echo "<td class='Game' valign='top'>
	        <div style='padding-bottom:5px'>
		        <div class='GameThumbnail'>
			        <a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_ciGame' title='$name' style='display:inline-block;cursor:pointer;'><img src='/games/2012/thing' border='0' alt='$name' href='/usergame?id=$id'></a>
		        </div>
		        <div class='GameDetails'>
			        <div class='GameName'><a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_hlGameName' href='/usergame?id=$id'>$name</a></div>
			        <div class='GameLastUpdate'><span class='Label'>Updated:</span> <span class='Detail'>$date</span></div>
			        <div class='GameCreator'><span class='Label'>Creator:</span> <span class='Detail'><a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_hlGameCreator' href='/user/?id=$userid'>$username</a></span></div>
			        <div class='AssetFavorites'><span class='Label'>Views:</span> <span class='Detail'>$views</span></div>
			        <div id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_pGameCurrentPlayers'>

				        <div class='GameCurrentPlayers'><span class='DetailHighlighted'>0 players online</span></div>

			</div>
		        </div>
		    </div>
	        </td>";

    $_GET['username'] = $username;
                    }
                    
echo"<tr></tr>";
                    
                    $resultsperpage = 3;
                    $check = mysqli_query($conn, "SELECT * FROM gamesuser");
                    $usercount = mysqli_num_rows($check);

                    $numberofpages = ceil($usercount/$resultsperpage);

                    if(!isset($_GET['page'])) {
                        $page = 2;
                    }else{
                        $page = $_GET['page'];
                    }

                    $thispagefirstresult = ($page-1)*$resultsperpage;

                    $check = mysqli_query($conn, "SELECT * FROM gamesuser LIMIT ".$thispagefirstresult.",".$resultsperpage);

                    while($row = mysqli_fetch_assoc($check)) {

    $username = htmlspecialchars($row['creatorname']);
    $userid = htmlspecialchars($row['creatorid']);
    $id = htmlspecialchars($row['id']);
    $name = htmlspecialchars($row['name']);
    $views = htmlspecialchars($row['views']);
    $date = htmlspecialchars($row['date']);

           echo "<td class='Game' valign='top'>
	        <div style='padding-bottom:5px'>
		        <div class='GameThumbnail'>
			        <a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_ciGame' title='$name' style='display:inline-block;cursor:pointer;'><img src='/games/2012/thing' border='0' alt='$name' href='/usergame?id=$id'></a>
		        </div>
		        <div class='GameDetails'>
			        <div class='GameName'><a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_hlGameName' href='/usergame?id=$id'>$name</a></div>
			        <div class='GameLastUpdate'><span class='Label'>Updated:</span> <span class='Detail'>$date</span></div>
			        <div class='GameCreator'><span class='Label'>Creator:</span> <span class='Detail'><a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_hlGameCreator' href='/user/?id=$userid'>$username</a></span></div>
			        <div class='AssetFavorites'><span class='Label'>Views:</span> <span class='Detail'>$views</span></div>
			        <div id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_pGameCurrentPlayers'>

				        <div class='GameCurrentPlayers'><span class='DetailHighlighted'>0 players online</span></div>

			</div>
		        </div>
		    </div>
	        </td>";

    $_GET['username'] = $username;
                    }
echo"</tr><tr>";
                    $resultsperpage = 3;
                    $check = mysqli_query($conn, "SELECT * FROM gamesuser");
                    $usercount = mysqli_num_rows($check);

                    $numberofpages = ceil($usercount/$resultsperpage);

                    if(!isset($_GET['page'])) {
                        $page = 3;
                    }else{
                        $page = $_GET['page'];
                    }

                    $thispagefirstresult = ($page-1)*$resultsperpage;

                    $check = mysqli_query($conn, "SELECT * FROM gamesuser LIMIT ".$thispagefirstresult.",".$resultsperpage);

                    while($row = mysqli_fetch_assoc($check)) {

    $username = htmlspecialchars($row['creatorname']);
    $userid = htmlspecialchars($row['creatorid']);
    $id = htmlspecialchars($row['id']);
    $name = htmlspecialchars($row['name']);
    $views = htmlspecialchars($row['views']);
    $date = htmlspecialchars($row['date']);

           echo "<td class='Game' valign='top'>
	        <div style='padding-bottom:5px'>
		        <div class='GameThumbnail'>
			        <a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_ciGame' title='$name' style='display:inline-block;cursor:pointer;'><img src='/games/2012/thing' border='0' alt='$name' href='/usergame?id=$id'></a>
		        </div>
		        <div class='GameDetails'>
			        <div class='GameName'><a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_hlGameName' href='/usergame?id=$id'>$name</a></div>
			        <div class='GameLastUpdate'><span class='Label'>Updated:</span> <span class='Detail'>$date</span></div>
			        <div class='GameCreator'><span class='Label'>Creator:</span> <span class='Detail'><a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_hlGameCreator' href='/user/?id=$userid'>$username</a></span></div>
			        <div class='AssetFavorites'><span class='Label'>Views:</span> <span class='Detail'>$views</span></div>
			        <div id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_pGameCurrentPlayers'>

				        <div class='GameCurrentPlayers'><span class='DetailHighlighted'>0 players online</span></div>

			</div>
		        </div>
		    </div>
	        </td>";

    $_GET['username'] = $username;
                    }
echo"</tr><tr>";
                    $resultsperpage = 3;
                    $check = mysqli_query($conn, "SELECT * FROM gamesuser");
                    $usercount = mysqli_num_rows($check);

                    $numberofpages = ceil($usercount/$resultsperpage);

                    if(!isset($_GET['page'])) {
                        $page = 4;
                    }else{
                        $page = $_GET['page'];
                    }

                    $thispagefirstresult = ($page-1)*$resultsperpage;

                    $check = mysqli_query($conn, "SELECT * FROM gamesuser LIMIT ".$thispagefirstresult.",".$resultsperpage);

                    while($row = mysqli_fetch_assoc($check)) {

    $username = htmlspecialchars($row['creatorname']);
    $userid = htmlspecialchars($row['creatorid']);
    $id = htmlspecialchars($row['id']);
    $name = htmlspecialchars($row['name']);
    $views = htmlspecialchars($row['views']);
    $date = htmlspecialchars($row['date']);

           echo "<td class='Game' valign='top'>
	        <div style='padding-bottom:5px'>
		        <div class='GameThumbnail'>
			        <a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_ciGame' title='$name' style='display:inline-block;cursor:pointer;'><img src='/games/2012/thing' border='0' alt='$name' href='/usergame?id=$id'></a>
		        </div>
		        <div class='GameDetails'>
			        <div class='GameName'><a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_hlGameName' href='/usergame?id=$id'>$name</a></div>
			        <div class='GameLastUpdate'><span class='Label'>Updated:</span> <span class='Detail'>$date</span></div>
			        <div class='GameCreator'><span class='Label'>Creator:</span> <span class='Detail'><a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_hlGameCreator' href='/user/?id=$userid'>$username</a></span></div>
			        <div class='AssetFavorites'><span class='Label'>Views:</span> <span class='Detail'>$views</span></div>
			        <div id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_pGameCurrentPlayers'>

				        <div class='GameCurrentPlayers'><span class='DetailHighlighted'>0 players online</span></div>

			</div>
		        </div>
		    </div>
	        </td>";

    $_GET['username'] = $username;
                    }
echo"</tr><tr>";
                    $resultsperpage = 3;
                    $check = mysqli_query($conn, "SELECT * FROM gamesuser");
                    $usercount = mysqli_num_rows($check);

                    $numberofpages = ceil($usercount/$resultsperpage);

                    if(!isset($_GET['page'])) {
                        $page = 5;
                    }else{
                        $page = $_GET['page'];
                    }

                    $thispagefirstresult = ($page-1)*$resultsperpage;

                    $check = mysqli_query($conn, "SELECT * FROM gamesuser LIMIT ".$thispagefirstresult.",".$resultsperpage);

                    while($row = mysqli_fetch_assoc($check)) {

    $username = htmlspecialchars($row['creatorname']);
    $userid = htmlspecialchars($row['creatorid']);
    $id = htmlspecialchars($row['id']);
    $name = htmlspecialchars($row['name']);
    $views = htmlspecialchars($row['views']);
    $date = htmlspecialchars($row['date']);

           echo "<td class='Game' valign='top'>
	        <div style='padding-bottom:5px'>
		        <div class='GameThumbnail'>
			        <a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_ciGame' title='$name' style='display:inline-block;cursor:pointer;'><img src='/games/2012/thing' border='0' alt='$name' href='/usergame?id=$id'></a>
		        </div>
		        <div class='GameDetails'>
			        <div class='GameName'><a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_hlGameName' href='/usergame?id=$id'>$name</a></div>
			        <div class='GameLastUpdate'><span class='Label'>Updated:</span> <span class='Detail'>$date</span></div>
			        <div class='GameCreator'><span class='Label'>Creator:</span> <span class='Detail'><a id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_hlGameCreator' href='/user/?id=$userid'>$username</a></span></div>
			        <div class='AssetFavorites'><span class='Label'>Views:</span> <span class='Detail'>$views</span></div>
			        <div id='ctl00_cphRoblox_rbxGames_dlGames_ctl00_pGameCurrentPlayers'>

				        <div class='GameCurrentPlayers'><span class='DetailHighlighted'>0 players online</span></div>

			</div>
		        </div>
		    </div>
	        </td>";

    $_GET['username'] = $username;
                    }
                    ?>
		    </tr>
	</tbody></table>
        <div id="ctl00_cphRoblox_rbxGames_FooterPagerPanel" class="HeaderPager">

            <span id="ctl00_cphRoblox_rbxGames_FooterPagerLabel">Page 1 of 1</span>
        </div>
    </div>

</div>
        <style>.BanishButtonOverlay {
    background-color: #eee;
    border: solid 1px #444;
    font-size: .8em;
    padding: 1px 3px 2px;
    position: absolute;
    text-align: center;
    top: 0;
    right: 0;
}</style>
<div class="Ads_WideSkyscraper">
		<div class="AdPanel">
	<a title="hauntedHouseAd" href="/adredirect/b3102ed17e4da6f783b80a981ee1a23a" style="display:inline-block;cursor:pointer;"><img src="/images/ads/2" border="0" alt="hauntedHouseAd" blankurl="http://t2-cf.roblox.com/blank-728x90.gif"></a>
</div>	</div>

        <div style="clear: both;"></div>
    </div>
<?php require '../more/footer.php'; ?>
				</div>
